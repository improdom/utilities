using System;

public class QueryExecutionLog
{
    public int ExecutionId { get; set; }
    public int QueryId { get; set; }
    public DateTime ExecutionTime { get; set; }
    public bool Success { get; set; }
    public string Message { get; set; }

    public QueryReadiness Query { get; set; }
}