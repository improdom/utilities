using System;
using System.Collections.Generic;

public class QueryReadiness
{
    public int QueryId { get; set; }
    public string QueryName { get; set; }
    public string TargetNodeName { get; set; }
    public string TargetNodeLevel { get; set; }
    public DateTime CreatedAt { get; set; }

    public ICollection<ReadinessStatus> ReadinessStatuses { get; set; }
    public ICollection<QueryExecutionLog> ExecutionLogs { get; set; }
}