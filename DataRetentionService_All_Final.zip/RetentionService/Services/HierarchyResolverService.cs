using System;
using System.Collections.Generic;
using System.Linq;

public class HierarchyResolverService
{
    private readonly List<BusinessHierarchyRow> _hierarchyRows;

    public HierarchyResolverService(List<BusinessHierarchyRow> hierarchyRows)
    {
        _hierarchyRows = hierarchyRows ?? throw new ArgumentNullException(nameof(hierarchyRows));
    }

    public List<string> GetSubDesksForNode(string level, string value)
    {
        if (string.IsNullOrEmpty(level) || string.IsNullOrEmpty(value))
            return new List<string>();

        IEnumerable<BusinessHierarchyRow> filtered = level switch
        {
            "Business Group" => _hierarchyRows.Where(h => h.BusinessGroup == value),
            "Business Unit" => _hierarchyRows.Where(h => h.BusinessUnit == value),
            "Business Area" => _hierarchyRows.Where(h => h.BusinessArea == value),
            "Sector" => _hierarchyRows.Where(h => h.Sector == value),
            "Desk" => _hierarchyRows.Where(h => h.Desk == value),
            "Sub-Desk" => _hierarchyRows.Where(h => h.SubDesk == value),
            _ => Enumerable.Empty<BusinessHierarchyRow>()
        };

        return filtered
            .Select(h => h.SubDesk)
            .Where(sd => !string.IsNullOrEmpty(sd))
            .Distinct()
            .ToList();
    }
}