using Microsoft.AnalysisServices.AdomdClient;
using System.Collections.Generic;

public class PowerBIHierarchyLoader
{
    private readonly string _connectionString;

    public PowerBIHierarchyLoader(string connectionString)
    {
        _connectionString = connectionString;
    }

    public List<BusinessHierarchyRow> LoadHierarchy()
    {
        var result = new List<BusinessHierarchyRow>();

        string daxQuery = @"
EVALUATE
SELECTCOLUMNS(
    'BusinessHierarchy',
    \"BusinessGroup\", 'BusinessHierarchy'[Business Group],
    \"BusinessUnit\", 'BusinessHierarchy'[Business Unit],
    \"BusinessArea\", 'BusinessHierarchy'[Business Area],
    \"Sector\", 'BusinessHierarchy'[Sector],
    \"Desk\", 'BusinessHierarchy'[Desk],
    \"SubDesk\", 'BusinessHierarchy'[Sub Desk],
    \"Book\", 'BusinessHierarchy'[Book]
)";

        using var connection = new AdomdConnection(_connectionString);
        connection.Open();

        using var command = new AdomdCommand(daxQuery, connection);
        using var reader = command.ExecuteReader();

        while (reader.Read())
        {
            var row = new BusinessHierarchyRow
            {
                BusinessGroup = reader["BusinessGroup"]?.ToString(),
                BusinessUnit  = reader["BusinessUnit"]?.ToString(),
                BusinessArea  = reader["BusinessArea"]?.ToString(),
                Sector        = reader["Sector"]?.ToString(),
                Desk          = reader["Desk"]?.ToString(),
                SubDesk       = reader["SubDesk"]?.ToString(),
                Book          = reader["Book"]?.ToString(),
            };

            result.Add(row);
        }

        return result;
    }
}