using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

public class SubDeskReadinessWorker : BackgroundService
{
    private readonly ILogger<SubDeskReadinessWorker> _logger;
    private readonly ExecutionReadinessTracker _readinessTracker;
    private readonly IEventQueue _eventQueue; // abstracted queue interface

    public SubDeskReadinessWorker(
        ILogger<SubDeskReadinessWorker> logger,
        ExecutionReadinessTracker readinessTracker,
        IEventQueue eventQueue)
    {
        _logger = logger;
        _readinessTracker = readinessTracker;
        _eventQueue = eventQueue;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("SubDeskReadinessWorker started.");

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                var subDeskName = await _eventQueue.DequeueAsync(stoppingToken);

                if (!string.IsNullOrEmpty(subDeskName))
                {
                    _logger.LogInformation("Received readiness event for sub-desk: {SubDesk}", subDeskName);
                    _readinessTracker.MarkSubDeskReady(subDeskName);
                }
            }
            catch (OperationCanceledException)
            {
                // expected on shutdown
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing sub-desk readiness event.");
                await Task.Delay(TimeSpan.FromSeconds(5), stoppingToken); // backoff
            }
        }

        _logger.LogInformation("SubDeskReadinessWorker stopped.");
    }
}