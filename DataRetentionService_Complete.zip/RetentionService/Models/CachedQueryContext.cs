using System.Collections.Generic;

public class CachedQueryContext
{
    public int QueryId { get; set; }
    public string QueryName { get; set; }
    public string TargetNodeName { get; set; }
    public string TargetNodeLevel { get; set; }
    public HashSet<string> RequiredSubDesks { get; set; } = new();
    public HashSet<string> ReadySubDesks { get; set; } = new();

    public bool IsReady => RequiredSubDesks.SetEquals(ReadySubDesks);
}