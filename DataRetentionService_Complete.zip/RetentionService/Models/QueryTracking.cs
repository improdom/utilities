public class QueryTracking
{
    public int QueryId { get; set; }
    public string QueryName { get; set; }
    public string TargetNodeName { get; set; }
    public string TargetNodeLevel { get; set; }
}