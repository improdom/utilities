using System;
using System.Collections.Generic;
using System.Linq;

public class QueryReadinessRepository : IQueryReadinessRepository
{
    private readonly RetentionDbContext _context;

    public QueryReadinessRepository(RetentionDbContext context)
    {
        _context = context;
    }

    public List<QueryReadiness> GetAllQueries()
    {
        return _context.QueryReadinesses.ToList();
    }

    public List<ReadinessStatus> GetAllReadiness()
    {
        return _context.ReadinessStatuses.ToList();
    }

    public List<string> ResolveSubDesks(string level, string value)
    {
        // Logic assumes hierarchy is loaded into a separate table or cached externally.
        throw new NotImplementedException("Hierarchy resolution should be implemented based on source (Power BI or table).");
    }

    public void MarkSubDeskReady(int queryId, string subDeskName)
    {
        var status = _context.ReadinessStatuses
            .FirstOrDefault(r => r.QueryId == queryId && r.SubDeskName == subDeskName);

        if (status == null)
        {
            status = new ReadinessStatus
            {
                QueryId = queryId,
                SubDeskName = subDeskName,
                IsReady = true,
                LastUpdated = DateTime.UtcNow
            };
            _context.ReadinessStatuses.Add(status);
        }
        else
        {
            status.IsReady = true;
            status.LastUpdated = DateTime.UtcNow;
        }

        _context.SaveChanges();
    }

    public void LogQueryExecution(int queryId, bool success, string message)
    {
        var log = new QueryExecutionLog
        {
            QueryId = queryId,
            ExecutionTime = DateTime.UtcNow,
            Success = success,
            Message = message
        };

        _context.QueryExecutionLogs.Add(log);
        _context.SaveChanges();
    }
}