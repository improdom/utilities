using System.Collections.Generic;

public interface IQueryReadinessRepository
{
    List<QueryTracking> GetAllQueries();
    List<ReadinessStatus> GetAllReadiness();
    List<string> ResolveSubDesks(string level, string value);
    void MarkSubDeskReady(int queryId, string subDeskName);
    void LogQueryExecution(int queryId, bool success, string message);
}