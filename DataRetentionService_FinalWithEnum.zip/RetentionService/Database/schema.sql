-- Updated: readiness_status now includes execution_date (already done)
CREATE TABLE IF NOT EXISTS readiness_status (
    query_id INTEGER NOT NULL REFERENCES query_readiness(query_id),
    sub_desk_name TEXT NOT NULL,
    execution_date DATE NOT NULL DEFAULT CURRENT_DATE,
    is_ready BOOLEAN NOT NULL DEFAULT FALSE,
    last_updated TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (query_id, sub_desk_name, execution_date)
);

-- New: query_execution_status for tracking success/failure
CREATE TABLE IF NOT EXISTS query_execution_status (
    query_id INTEGER NOT NULL REFERENCES query_readiness(query_id),
    execution_date DATE NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('pending', 'success', 'failed')),
    last_attempt TIMESTAMPTZ DEFAULT NOW(),
    message TEXT,
    PRIMARY KEY (query_id, execution_date)
);

-- Optional: summary table for reporting (if you want to materialize logs)
CREATE MATERIALIZED VIEW IF NOT EXISTS query_daily_summary AS
SELECT
    qr.query_id,
    qr.query_name,
    qes.execution_date,
    qes.status,
    COUNT(rs.sub_desk_name) FILTER (WHERE rs.is_ready) AS ready_count,
    COUNT(rs.sub_desk_name) AS total_sub_desks
FROM query_readiness qr
LEFT JOIN query_execution_status qes
    ON qr.query_id = qes.query_id
LEFT JOIN readiness_status rs
    ON qr.query_id = rs.query_id AND rs.execution_date = qes.execution_date
GROUP BY qr.query_id, qr.query_name, qes.execution_date, qes.status;