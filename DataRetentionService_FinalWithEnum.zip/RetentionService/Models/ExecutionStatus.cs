public enum ExecutionStatus
{
    Pending,
    Ready,
    Running,
    Success,
    Failed
}