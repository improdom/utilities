using System;
using System.Collections.Generic;
using System.Linq;

public class QueryReadinessRepository : IQueryReadinessRepository
{
    private readonly RetentionDbContext _context;

    public QueryReadinessRepository(RetentionDbContext context)
    {
        _context = context;
    }

    public List<QueryReadiness> GetAllQueries()
    {
        return _context.QueryReadinesses.ToList();
    }

    public List<ReadinessStatus> GetAllReadinessForDate(DateTime executionDate)
    {
        return _context.ReadinessStatuses
            .Where(r => r.ExecutionDate == executionDate.Date)
            .ToList();
    }

    public void MarkSubDeskReady(int queryId, string subDeskName, DateTime executionDate)
    {
        var status = _context.ReadinessStatuses
            .FirstOrDefault(r =>
                r.QueryId == queryId &&
                r.SubDeskName == subDeskName &&
                r.ExecutionDate == executionDate.Date);

        if (status == null)
        {
            status = new ReadinessStatus
            {
                QueryId = queryId,
                SubDeskName = subDeskName,
                ExecutionDate = executionDate.Date,
                IsReady = true,
                LastUpdated = DateTime.UtcNow
            };
            _context.ReadinessStatuses.Add(status);
        }
        else
        {
            status.IsReady = true;
            status.LastUpdated = DateTime.UtcNow;
        }

        _context.SaveChanges();
    }

    public void LogQueryExecutionStatus(int queryId, DateTime executionDate, ExecutionStatus status, string message = null)
    {
        var existing = _context.QueryExecutionStatuses
            .FirstOrDefault(e => e.QueryId == queryId && e.ExecutionDate == executionDate.Date);

        if (existing == null)
        {
            _context.QueryExecutionStatuses.Add(new QueryExecutionStatus
            {
                QueryId = queryId,
                ExecutionDate = executionDate.Date,
                Status = status,
                LastAttempt = DateTime.UtcNow,
                Message = message
            });
        }
        else
        {
            existing.Status = status;
            existing.LastAttempt = DateTime.UtcNow;
            existing.Message = message;
        }

        _context.SaveChanges();
    }

    public string GetQueryExecutionStatus(int queryId, DateTime executionDate)
    {
        var record = _context.QueryExecutionStatuses
            .FirstOrDefault(e => e.QueryId == queryId && e.ExecutionDate == executionDate.Date);

        return record?.Status;
    }

    public List<QueryReadiness> GetPendingQueries(DateTime executionDate)
    {
        var executed = _context.QueryExecutionStatuses
            .Where(e => e.ExecutionDate == executionDate.Date && e.Status == ExecutionStatus.Success.ToString())
            .Select(e => e.QueryId)
            .ToHashSet();

        return _context.QueryReadinesses
            .Where(q => !executed.Contains(q.QueryId))
            .ToList();
    }


public void SetExecutionStatusReady(int queryId, DateTime executionDate)
{
    LogQueryExecutionStatus(queryId, executionDate, ExecutionStatus.Ready.ToString());
}

public void SetExecutionStatusRunning(int queryId, DateTime executionDate)
{
    LogQueryExecutionStatus(queryId, executionDate, ExecutionStatus.Running.ToString());
}

public void SetExecutionStatusSuccess(int queryId, DateTime executionDate)
{
    LogQueryExecutionStatus(queryId, executionDate, ExecutionStatus.Success.ToString());
}

public void SetExecutionStatusFailed(int queryId, DateTime executionDate, string message)
{
    LogQueryExecutionStatus(queryId, executionDate, ExecutionStatus.Failed.ToString(), message);
}

public List<QueryReadiness> GetFailedOrReadyQueries(DateTime executionDate)
{
    var retryable = _context.QueryExecutionStatuses
        .Where(e =>
            e.ExecutionDate == executionDate.Date &&
            (e.Status == ExecutionStatus.Failed.ToString() || e.Status == ExecutionStatus.Ready.ToString()))
        .Select(e => e.QueryId)
        .ToHashSet();

    return _context.QueryReadinesses
        .Where(q => retryable.Contains(q.QueryId))
        .ToList();
}
}