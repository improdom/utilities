using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Extensions.Logging;

public class ExecutionReadinessTracker
{
    private readonly ILogger<ExecutionReadinessTracker> _logger;
    private readonly IQueryReadinessRepository _db;
    private readonly HierarchyResolverService _hierarchyResolver;

    private readonly ConcurrentDictionary<int, QueryReadinessContext> _queryCache = new();

    public ExecutionReadinessTracker(
        IQueryReadinessRepository db,
        ILogger<ExecutionReadinessTracker> logger,
        HierarchyResolverService hierarchyResolver)
    {
        _db = db;
        _logger = logger;
        _hierarchyResolver = hierarchyResolver;

        LoadCacheFromDatabase();
    }

    private void LoadCacheFromDatabase()
    {
        _logger.LogInformation("Loading query readiness state from database...");

        var queries = _db.GetAllQueries();
        var readiness = _db.GetAllReadinessForDate(DateTime.UtcNow.Date);

        foreach (var query in queries)
        {
            var requiredSubDesks = _hierarchyResolver.GetSubDesksForNode(
                query.TargetNodeLevel,
                query.TargetNodeName
            );

            var context = new QueryReadinessContext
            {
                QueryId = query.QueryId,
                QueryName = query.QueryName,
                TargetNodeLevel = query.TargetNodeLevel,
                TargetNodeName = query.TargetNodeName,
                RequiredSubDesks = requiredSubDesks.ToHashSet(),
                ReadySubDesks = readiness
                    .Where(r => r.QueryId == query.QueryId && r.IsReady)
                    .Select(r => r.SubDeskName)
                    .ToHashSet()
            };

            _queryCache[query.QueryId] = context;

            _logger.LogInformation("Cached query {QueryId} with {Ready}/{Total} sub-desks ready.",
                query.QueryId, context.ReadySubDesks.Count, context.RequiredSubDesks.Count);
        }
    }

    public void MarkSubDeskReady(string subDeskName)
    {
        _logger.LogInformation("Received sub-desk readiness for: {SubDesk}", subDeskName);

        foreach (var query in _queryCache.Values)
        {
            if (!query.RequiredSubDesks.Contains(subDeskName)) continue;
            if (query.ReadySubDesks.Contains(subDeskName)) continue;

            query.ReadySubDesks.Add(subDeskName);
            _logger.LogInformation("Sub-desk {SubDesk} marked ready for Query {QueryId}", subDeskName, query.QueryId);

            _db.MarkSubDeskReady(query.QueryId, subDeskName, DateTime.UtcNow.Date);

            if (query.IsReady && ShouldTriggerExecution(query.QueryId))
            {
                _logger.LogInformation("All sub-desks ready. Preparing to execute Query {QueryId}", query.QueryId);
                _db.LogQueryExecutionStatus(query.QueryId, DateTime.UtcNow.Date, ExecutionStatus.Running);
                TriggerQuery(query.QueryId);
            }
        }
    }

    private bool ShouldTriggerExecution(int queryId)
    {
        var status = _db.GetQueryExecutionStatus(queryId, DateTime.UtcNow.Date);
        return string.IsNullOrEmpty(status) ||
               status == ExecutionStatus.Pending.ToString() ||
               status == ExecutionStatus.Failed.ToString();
    }

    private void TriggerQuery(int queryId)
    {
        _logger.LogInformation("Executing Power BI query for QueryId {QueryId}", queryId);

        try
        {
            // TODO: Add Power BI execution logic
            _db.LogQueryExecutionStatus(queryId, DateTime.UtcNow.Date, ExecutionStatus.Success);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Execution failed for QueryId {QueryId}", queryId);
            _db.LogQueryExecutionStatus(queryId, DateTime.UtcNow.Date, ExecutionStatus.Failed, ex.Message);
        }
    }
}