public interface IQueryReadinessRepository
{
    List<QueryReadiness> GetAllQueries();
    List<ReadinessStatus> GetAllReadinessForDate(DateTime executionDate);
    void MarkSubDeskReady(int queryId, string subDeskName, DateTime executionDate);
    void LogQueryExecutionStatus(int queryId, DateTime executionDate, string status, string message = null);
    string GetQueryExecutionStatus(int queryId, DateTime executionDate);
    List<QueryReadiness> GetPendingQueries(DateTime executionDate);
}