-- Table: query_readiness
CREATE TABLE IF NOT EXISTS query_readiness (
    query_id SERIAL PRIMARY KEY,
    query_name TEXT NOT NULL,
    target_node_name TEXT NOT NULL,
    target_node_level TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Table: readiness_status
CREATE TABLE IF NOT EXISTS readiness_status (
    query_id INTEGER REFERENCES query_readiness(query_id),
    sub_desk_name TEXT NOT NULL,
    is_ready BOOLEAN NOT NULL DEFAULT FALSE,
    last_updated TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (query_id, sub_desk_name)
);

-- Table: query_execution_log
CREATE TABLE IF NOT EXISTS query_execution_log (
    execution_id SERIAL PRIMARY KEY,
    query_id INTEGER REFERENCES query_readiness(query_id),
    execution_time TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    success BOOLEAN NOT NULL,
    message TEXT
);

-- Optional: business_hierarchy (if needed for persistent hierarchy)
CREATE TABLE IF NOT EXISTS business_hierarchy (
    node_id SERIAL PRIMARY KEY,
    node_name TEXT NOT NULL,
    node_level TEXT NOT NULL,
    parent_id INTEGER REFERENCES business_hierarchy(node_id)
);