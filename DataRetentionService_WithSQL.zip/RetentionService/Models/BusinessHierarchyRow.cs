public class BusinessHierarchyRow
{
    public string BusinessGroup { get; set; }
    public string BusinessUnit { get; set; }
    public string BusinessArea { get; set; }
    public string Sector { get; set; }
    public string Desk { get; set; }
    public string SubDesk { get; set; }
    public string Book { get; set; }
}