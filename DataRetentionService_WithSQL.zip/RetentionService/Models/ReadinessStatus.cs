using System;

public class ReadinessStatus
{
    public int QueryId { get; set; }
    public string SubDeskName { get; set; }
    public bool IsReady { get; set; }
    public DateTime LastUpdated { get; set; }

    public QueryReadiness Query { get; set; }
}