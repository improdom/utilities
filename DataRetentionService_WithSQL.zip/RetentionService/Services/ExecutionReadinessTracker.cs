using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;

public class ExecutionReadinessTracker
{
    private readonly ConcurrentDictionary<int, QueryReadinessContext> _queryCache = new();
    private readonly IQueryReadinessRepository _db;

    public ExecutionReadinessTracker(IQueryReadinessRepository db)
    {
        _db = db;
        LoadCacheFromDatabase();
    }

    private void LoadCacheFromDatabase()
    {
        var queries = _db.GetAllQueries();
        var readiness = _db.GetAllReadiness();

        foreach (var query in queries)
        {
            var requiredSubDesks = _db.ResolveSubDesks(query.TargetNodeLevel, query.TargetNodeName);

            var context = new QueryReadinessContext
            {
                QueryId = query.QueryId,
                QueryName = query.QueryName,
                TargetNodeLevel = query.TargetNodeLevel,
                TargetNodeName = query.TargetNodeName,
                RequiredSubDesks = requiredSubDesks.ToHashSet(),
                ReadySubDesks = readiness
                    .Where(r => r.QueryId == query.QueryId && r.IsReady)
                    .Select(r => r.SubDeskName)
                    .ToHashSet()
            };

            _queryCache[query.QueryId] = context;
        }
    }

    public void MarkSubDeskReady(string subDeskName)
    {
        foreach (var query in _queryCache.Values)
        {
            if (!query.RequiredSubDesks.Contains(subDeskName)) continue;

            query.ReadySubDesks.Add(subDeskName);
            _db.MarkSubDeskReady(query.QueryId, subDeskName);

            if (query.IsReady)
            {
                _db.LogQueryExecution(query.QueryId, success: true, message: "Triggered from cache");
                TriggerQuery(query.QueryId);
            }
        }
    }

    private void TriggerQuery(int queryId)
    {
        // TODO: Add Power BI execution logic here
        System.Console.WriteLine($"Triggering query execution for QueryId {queryId}");
    }
}