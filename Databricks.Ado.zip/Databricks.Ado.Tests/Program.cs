using System.Data;
using Databricks.Ado;
using Microsoft.Azure.Databricks.Client;
using Microsoft.Azure.Databricks.Client.Models;

var passed = 0;
void Check(bool condition, string label) { if (!condition) throw new Exception(label); passed++; }
void Throws<T>(Action action) where T : Exception
{ try { action(); } catch (T) { passed++; return; } throw new Exception($"Expected {typeof(T).Name}"); }
var api = new FakeApi();
using var connection = new DatabricksConnection(api, "warehouse", "catalog", "schema");
IDbConnection db = connection;
using var command = db.CreateCommand();
command.CommandText = "select :id";
Throws<InvalidOperationException>(() => command.ExecuteReader());
db.Open();
var parameter = command.CreateParameter(); parameter.ParameterName = ":id"; parameter.Value = 7; command.Parameters.Add(parameter);
using (IDataReader reader = command.ExecuteReader())
{
    Check(api.Last!.WarehouseId == "warehouse" && api.Last.Catalog == "catalog", "Warehouse/catalog");
    Check(api.Last.Parameters.Single().Name == "id" && api.Last.Parameters.Single().Value == "7", "Parameter binding");
    Check(api.Polls == 1 && api.ChunkFetches == 1, "Polling and chunk retrieval");
    Check(reader.Read() && reader.GetInt32(0) == 7 && reader.IsDBNull(1), "First row and null");
    Check(reader.GetName(1) == "value" && reader.GetOrdinal("VALUE") == 0, "Duplicate column names");
    Check(reader.Read() && reader.GetInt32(0) == 8 && reader.GetString(1) == "second", "Second chunk row");
    Check(!reader.Read() && !reader.NextResult(), "End of result");
}
Check(db.State == ConnectionState.Open, "Default behavior retains connection");
Check((int)command.ExecuteScalar()! == 7, "Scalar");
using (var reader = command.ExecuteReader(CommandBehavior.CloseConnection)) { reader.Close(); }
Check(db.State == ConnectionState.Closed, "CloseConnection");
db.Open();
using (var reader = command.ExecuteReader())
{
    var table = new DataTable(); table.Load(reader);
    Check(table.Rows.Count == 2 && (int)table.Rows[1][0] == 8, "DataTable.Load compatibility");
}
api.Truncated = true;
Throws<DatabricksException>(() => command.ExecuteReader());
api.Truncated = false;
api.Fail = true;
Throws<DatabricksException>(() => command.ExecuteReader());
api.Fail = false;
api.Forever = true;
command.CommandTimeout = 1;
Throws<OperationCanceledException>(() => command.ExecuteReader());
Check(api.Cancels == 1, "Timeout cancels remote statement");
api.Forever = false;
api.Custom = new StatementExecution
{
    StatementId = "typed",
    Status = new StatementExecutionStatus { State = StatementExecutionState.SUCCEEDED },
    Manifest = new StatementExecutionManifest
    {
        TotalChunkCount = 1, TotalRowCount = 1,
        Schema = new StatementExecutionSchema { ColumnCount = 4, Columns = new[] {
            new StatementExecutionSchemaColumn { Name = "flag", TypeName = "BOOLEAN", Position = 0 },
            new StatementExecutionSchemaColumn { Name = "amount", TypeName = "DECIMAL", TypePrecision = 10, Position = 1 },
            new StatementExecutionSchemaColumn { Name = "date", TypeName = "DATE", Position = 2 },
            new StatementExecutionSchemaColumn { Name = "large", TypeName = "DECIMAL", TypePrecision = 38, Position = 3 }
        } }
    },
    Result = new StatementExecutionResultChunk { RowCount = 1, DataArray = new[] { new[] { "true", "12.50", "2026-10-07", "12345678901234567890123456789012345678" } } }
};
using (var reader = command.ExecuteReader())
{
    reader.Read();
    Check(reader.GetBoolean(0) && reader.GetDecimal(1) == 12.5m, "Typed boolean/decimal");
    Check(reader.GetDateTime(2) == new DateTime(2026, 10, 7), "Typed date");
    Check(reader.GetFieldType(3) == typeof(string) && reader.GetString(3).Length == 38, "Large decimal preserves precision");
}
api.Custom = null;
Throws<NotSupportedException>(() => db.BeginTransaction());
Throws<NotSupportedException>(() => command.ExecuteReader(CommandBehavior.SchemaOnly));
connection.Dispose();
Throws<ObjectDisposedException>(() => connection.Open());
Console.WriteLine($"Passed {passed} checks.");

sealed class FakeApi : IStatementExecutionApi
{
    public void Dispose() { }
    public SqlStatement? Last;
    public int Polls, ChunkFetches, Cancels;
    public bool Truncated, Fail, Forever;
    public StatementExecution? Custom;
    public Task<StatementExecution> Execute(SqlStatement statement, CancellationToken ct = default)
    {
        Last = statement;
        return Task.FromResult(new StatementExecution { StatementId = "statement", Status = new StatementExecutionStatus { State = StatementExecutionState.PENDING } });
    }
    public Task<StatementExecution> Get(string id, CancellationToken ct = default)
    {
        Polls++;
        if (Custom is not null) return Task.FromResult(Custom);
        if (Forever) return Task.FromResult(new StatementExecution { StatementId = id, Status = new StatementExecutionStatus { State = StatementExecutionState.RUNNING } });
        return Task.FromResult(new StatementExecution
        {
            StatementId = id,
            Status = new StatementExecutionStatus { State = Fail ? StatementExecutionState.FAILED : StatementExecutionState.SUCCEEDED,
                Error = Fail ? new StatementExecutionError { Message = "SQL error", ErrorCode = StatementExecutionErrorCode.BAD_REQUEST } : null },
            Manifest = new StatementExecutionManifest
            {
                TotalChunkCount = 2, TotalRowCount = 2, Truncated = Truncated,
                Schema = new StatementExecutionSchema { ColumnCount = 2, Columns = new[] {
                    new StatementExecutionSchemaColumn { Name = "value", TypeName = "INT", TypeText = "INT", Position = 0 },
                    new StatementExecutionSchemaColumn { Name = "value", TypeName = "STRING", TypeText = "STRING", Position = 1 }
                } }
            },
            Result = new StatementExecutionResultChunk { DataArray = new[] { new string[] { "7", null! } }, RowCount = 1 }
        });
    }
    public Task<StatementExecutionResultChunk> GetResultChunk(string id, int chunkIndex, CancellationToken ct = default)
    {
        if (chunkIndex != 1) throw new Exception("Wrong chunk index");
        ChunkFetches++;
        return Task.FromResult(new StatementExecutionResultChunk { DataArray = new[] { new[] { "8", "second" } }, RowCount = 1, ChunkIndex = 1 });
    }
    public Task Cancel(string id, CancellationToken ct = default) { Cancels++; return Task.CompletedTask; }
}
