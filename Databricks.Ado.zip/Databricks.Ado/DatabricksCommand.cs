using System.Data;
using System.Data.Common;
using Microsoft.Azure.Databricks.Client.Models;

namespace Databricks.Ado;

public sealed class DatabricksCommand : DbCommand
{
    private readonly DatabricksParameterCollection parameters = new();
    private readonly object gate = new();
    private CancellationTokenSource? execution;
    private DatabricksConnection? connection;
    private bool disposed;
    private int timeout = 30;
    public override string CommandText { get; set; } = "";
    public override int CommandTimeout { get => timeout; set { if (value < 0) throw new ArgumentOutOfRangeException(nameof(value)); timeout = value; } }
    public override CommandType CommandType { get; set; } = CommandType.Text;
    public override bool DesignTimeVisible { get; set; }
    public override UpdateRowSource UpdatedRowSource { get; set; } = UpdateRowSource.None;
    protected override DbConnection? DbConnection
    {
        get => connection;
        set { if (value is not null and not DatabricksConnection) throw new ArgumentException("Use DatabricksConnection."); connection = (DatabricksConnection?)value; }
    }
    protected override DbTransaction? DbTransaction { get => null; set { if (value is not null) throw new NotSupportedException("Transactions are unsupported."); } }
    protected override DbParameterCollection DbParameterCollection => parameters;
    protected override DbParameter CreateDbParameter() => new DatabricksParameter();
    public override void Prepare() { Validate(); } // REST API has no server-side prepare.
    public override void Cancel() { lock (gate) execution?.Cancel(); }
    private DatabricksConnection Validate()
    {
        ObjectDisposedException.ThrowIf(disposed, this);
        if (CommandType != CommandType.Text) throw new NotSupportedException("Only CommandType.Text is supported.");
        if (string.IsNullOrWhiteSpace(CommandText)) throw new InvalidOperationException("CommandText is required.");
        var conn = connection ?? throw new InvalidOperationException("Set Connection first.");
        conn.EnsureOpen();
        return conn;
    }
    protected override DbDataReader ExecuteDbDataReader(CommandBehavior behavior) =>
        Task.Run(() => ExecuteDbDataReaderAsync(behavior, CancellationToken.None)).GetAwaiter().GetResult();
    protected override async Task<DbDataReader> ExecuteDbDataReaderAsync(CommandBehavior behavior, CancellationToken cancellationToken)
    {
        const CommandBehavior supported = CommandBehavior.CloseConnection | CommandBehavior.SingleResult | CommandBehavior.SingleRow | CommandBehavior.SequentialAccess;
        if ((behavior & ~supported) != 0) throw new NotSupportedException("SchemaOnly and KeyInfo are unsupported.");
        var conn = Validate();
        using var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        lock (gate)
        {
            if (execution is not null) throw new InvalidOperationException("A command cannot execute concurrently.");
            execution = cts;
        }
        string? id = null;
        try
        {
            if (CommandTimeout > 0) cts.CancelAfter(TimeSpan.FromSeconds(CommandTimeout));
            var ct = cts.Token;
            ct.ThrowIfCancellationRequested();
            var input = parameters.Cast<DatabricksParameter>().Select(p => p.ToApi()).ToArray();
            if (input.Select(p => p.Name).Distinct(StringComparer.Ordinal).Count() != input.Length)
                throw new ArgumentException("Parameter names must be unique.");
            var statement = new SqlStatement
            {
                Statement = CommandText, WarehouseId = conn.WarehouseId,
                Catalog = string.IsNullOrEmpty(conn.Database) ? null : conn.Database, Schema = conn.Schema,
                Parameters = input, Disposition = SqlStatementDisposition.INLINE, Format = StatementFormat.JSON_ARRAY,
                WaitTimeout = "0s", OnWaitTimeout = SqlStatementOnWaitTimeout.CONTINUE
            };
            var response = await conn.Statements.Execute(statement, ct).ConfigureAwait(false);
            id = response.StatementId;
            while (response.Status.State is StatementExecutionState.PENDING or StatementExecutionState.RUNNING)
            {
                if (string.IsNullOrEmpty(id)) throw new DatabricksException("Server omitted the statement ID.");
                await Task.Delay(250, ct).ConfigureAwait(false);
                response = await conn.Statements.Get(id, ct).ConfigureAwait(false);
            }
            if (response.Status.State != StatementExecutionState.SUCCEEDED)
                throw new DatabricksException(response.Status.Error?.Message ?? $"Statement ended in state {response.Status.State}.", response.Status.Error?.ErrorCode.ToString());
            var manifest = response.Manifest ?? throw new DatabricksException("Server omitted the result manifest.");
            if (manifest.Truncated) throw new DatabricksException("The result was truncated. Use a smaller query result; partial data is not returned.");
            var columns = manifest.Schema.Columns.OrderBy(c => c.Position).ToArray();
            var rows = new List<string?[]>();
            void Add(StatementExecutionResultChunk? chunk)
            {
                if (chunk?.DataArray is not null) rows.AddRange(chunk.DataArray);
                else if (chunk is { RowCount: > 0 }) throw new DatabricksException("Expected inline JSON result data.");
            }
            Add(response.Result);
            // The client models NextChunkIndex as int, so absent and zero are indistinguishable.
            // Use manifest.TotalChunkCount to reliably fetch every chunk.
            for (var index = 1; index < manifest.TotalChunkCount; index++)
            {
                if (string.IsNullOrEmpty(id)) throw new DatabricksException("Server omitted the statement ID.");
                Add(await conn.Statements.GetResultChunk(id, index, ct).ConfigureAwait(false));
            }
            ct.ThrowIfCancellationRequested();
            if (rows.Count != manifest.TotalRowCount) throw new DatabricksException("Returned row count does not match the manifest.");
            if ((behavior & CommandBehavior.SingleRow) != 0 && rows.Count > 1) rows.RemoveRange(1, rows.Count - 1);
            return new DatabricksDataReader(columns, rows, (behavior & CommandBehavior.CloseConnection) != 0 ? conn : null);
        }
        catch (OperationCanceledException)
        {
            if (!string.IsNullOrEmpty(id))
            {
                using var cleanup = new CancellationTokenSource(TimeSpan.FromSeconds(5));
                try { await conn.Statements.Cancel(id, cleanup.Token).ConfigureAwait(false); }
                catch { /* Preserve the original cancellation; remote cancellation is best effort. */ }
            }
            throw;
        }
        finally { lock (gate) execution = null; }
    }
    public override object? ExecuteScalar() { using var reader = ExecuteReader(); return reader.Read() && reader.FieldCount > 0 ? reader.GetValue(0) : null; }
    public override async Task<object?> ExecuteScalarAsync(CancellationToken ct)
    {
        using var reader = await ExecuteReaderAsync(ct).ConfigureAwait(false);
        return reader.Read() && reader.FieldCount > 0 ? reader.GetValue(0) : null;
    }
    public override int ExecuteNonQuery() => throw new NotSupportedException("This minimal provider supports queries through ExecuteReader and ExecuteScalar.");
    public override Task<int> ExecuteNonQueryAsync(CancellationToken ct) => throw new NotSupportedException("Use ExecuteReader for this provider.");
    protected override void Dispose(bool disposing) { if (disposing) { Cancel(); disposed = true; } base.Dispose(disposing); }
}
