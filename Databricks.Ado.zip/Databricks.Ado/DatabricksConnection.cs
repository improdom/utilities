using System.Data;
using System.Data.Common;
using Microsoft.Azure.Databricks.Client;

namespace Databricks.Ado;

/// <summary>A logical connection over an existing client. The caller owns the client.</summary>
public sealed class DatabricksConnection : DbConnection
{
    private ConnectionState state;
    private bool disposed;
    private string catalog;
    internal IStatementExecutionApi Statements { get; }
    public string WarehouseId { get; }
    public string? Schema { get; }
    public DatabricksConnection(DatabricksClient client, string warehouseId, string? catalog = null, string? schema = null)
        : this((client ?? throw new ArgumentNullException(nameof(client))).SQL.StatementExecution, warehouseId, catalog, schema) { }
    public DatabricksConnection(IStatementExecutionApi statements, string warehouseId, string? catalog = null, string? schema = null)
    {
        Statements = statements ?? throw new ArgumentNullException(nameof(statements));
        if (string.IsNullOrWhiteSpace(warehouseId)) throw new ArgumentException("Warehouse ID is required.", nameof(warehouseId));
        WarehouseId = warehouseId;
        this.catalog = catalog ?? "";
        Schema = schema;
    }
    public override string ConnectionString { get => $"WarehouseId={WarehouseId}"; set => throw new NotSupportedException("Pass your existing DatabricksClient and warehouse ID to the constructor."); }
    public override string Database => catalog;
    public override string DataSource => WarehouseId;
    public override string ServerVersion => throw new NotSupportedException();
    public override ConnectionState State => state;
    public override int ConnectionTimeout => 0;
    // Stateless API: first command execution contacts the server.
    public override void Open() { ObjectDisposedException.ThrowIf(disposed, this); ChangeState(ConnectionState.Open); }
    public override Task OpenAsync(CancellationToken ct) { ct.ThrowIfCancellationRequested(); Open(); return Task.CompletedTask; }
    public override void Close() => ChangeState(ConnectionState.Closed);
    private void ChangeState(ConnectionState next)
    {
        var old = state; state = next;
        if (old != next) OnStateChange(new StateChangeEventArgs(old, next));
    }
    public override void ChangeDatabase(string databaseName)
    {
        EnsureOpen(); ArgumentException.ThrowIfNullOrWhiteSpace(databaseName); catalog = databaseName;
    }
    internal void EnsureOpen()
    {
        ObjectDisposedException.ThrowIf(disposed, this);
        if (state != ConnectionState.Open) throw new InvalidOperationException("Open the connection before executing a command.");
    }
    protected override DbTransaction BeginDbTransaction(IsolationLevel isolationLevel) => throw new NotSupportedException("Transactions are outside this provider's scope.");
    protected override DbCommand CreateDbCommand() { ObjectDisposedException.ThrowIf(disposed, this); return new DatabricksCommand { Connection = this }; }
    protected override void Dispose(bool disposing) { if (disposing) { Close(); disposed = true; } base.Dispose(disposing); }
}

public sealed class DatabricksException : DbException
{
    public string? DatabricksErrorCode { get; }
    public DatabricksException(string message, string? errorCode = null) : base(message) => DatabricksErrorCode = errorCode;
}
