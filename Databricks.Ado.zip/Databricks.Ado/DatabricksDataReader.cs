using System.Collections;
using System.Data;
using System.Data.Common;
using System.Globalization;
using Microsoft.Azure.Databricks.Client.Models;

namespace Databricks.Ado;

/// <summary>Forward-only reader over buffered inline results; preserves duplicate column names.</summary>
public sealed class DatabricksDataReader : DbDataReader
{
    private readonly StatementExecutionSchemaColumn[] columns;
    private readonly List<string?[]> rows;
    private readonly DatabricksConnection? closeConnection;
    private int position = -1;
    private bool closed;
    internal DatabricksDataReader(StatementExecutionSchemaColumn[] columns, List<string?[]> rows, DatabricksConnection? closeConnection)
    {
        this.columns = columns; this.rows = rows; this.closeConnection = closeConnection;
        if (rows.Any(r => r.Length != columns.Length)) throw new DatabricksException("Result row width does not match the schema.");
    }
    public override int FieldCount => columns.Length;
    public override bool HasRows => rows.Count != 0;
    public override bool IsClosed => closed;
    public override int Depth => 0;
    public override int RecordsAffected => -1;
    public override object this[int ordinal] => GetValue(ordinal);
    public override object this[string name] => GetValue(GetOrdinal(name));
    private void EnsureOpen() { if (closed) throw new InvalidOperationException("Reader is closed."); }
    public override bool Read() { EnsureOpen(); if (position < rows.Count) position++; return position < rows.Count; }
    public override Task<bool> ReadAsync(CancellationToken ct) { ct.ThrowIfCancellationRequested(); return Task.FromResult(Read()); }
    public override bool NextResult() { EnsureOpen(); position = rows.Count; return false; }
    public override void Close() { if (closed) return; closed = true; rows.Clear(); closeConnection?.Close(); }
    protected override void Dispose(bool disposing) { if (disposing) Close(); base.Dispose(disposing); }
    public override string GetName(int ordinal) => columns[ordinal].Name;
    public override string GetDataTypeName(int ordinal) => columns[ordinal].TypeText ?? columns[ordinal].TypeName;
    public override int GetOrdinal(string name)
    {
        var i = Array.FindIndex(columns, c => c.Name == name);
        if (i < 0) i = Array.FindIndex(columns, c => string.Equals(c.Name, name, StringComparison.OrdinalIgnoreCase));
        return i < 0 ? throw new IndexOutOfRangeException(name) : i;
    }
    public override Type GetFieldType(int ordinal) => columns[ordinal].TypeName.ToUpperInvariant() switch
    {
        "BOOLEAN" => typeof(bool), "BYTE" or "TINYINT" => typeof(sbyte), "SHORT" or "SMALLINT" => typeof(short),
        "INT" or "INTEGER" => typeof(int), "LONG" or "BIGINT" => typeof(long), "FLOAT" => typeof(float),
        "DOUBLE" => typeof(double), "DECIMAL" when columns[ordinal].TypePrecision <= 28 => typeof(decimal),
        "DATE" or "TIMESTAMP" or "TIMESTAMP_NTZ" => typeof(DateTime), _ => typeof(string)
    };
    public override object GetValue(int ordinal)
    {
        EnsureOpen();
        if (position < 0 || position >= rows.Count) throw new InvalidOperationException("Call Read before accessing a row.");
        var text = rows[position][ordinal];
        if (text is null) return DBNull.Value;
        var type = GetFieldType(ordinal);
        if (type == typeof(string)) return text;
        if (type == typeof(DateTime)) return DateTime.Parse(text, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind);
        return Convert.ChangeType(text, type, CultureInfo.InvariantCulture);
    }
    public override int GetValues(object[] values)
    {
        var count = Math.Min(values.Length, FieldCount);
        for (var i = 0; i < count; i++) values[i] = GetValue(i);
        return count;
    }
    public override bool IsDBNull(int ordinal) => GetValue(ordinal) is DBNull;
    // Typed accessors enforce the CLR type, like other ADO.NET readers.
    public override bool GetBoolean(int ordinal) => (bool)GetValue(ordinal);
    public override byte GetByte(int ordinal) => checked((byte)(sbyte)GetValue(ordinal));
    public override short GetInt16(int ordinal) => (short)GetValue(ordinal);
    public override int GetInt32(int ordinal) => (int)GetValue(ordinal);
    public override long GetInt64(int ordinal) => (long)GetValue(ordinal);
    public override float GetFloat(int ordinal) => (float)GetValue(ordinal);
    public override double GetDouble(int ordinal) => (double)GetValue(ordinal);
    public override decimal GetDecimal(int ordinal) => (decimal)GetValue(ordinal);
    public override DateTime GetDateTime(int ordinal) => (DateTime)GetValue(ordinal);
    public override string GetString(int ordinal) => (string)GetValue(ordinal);
    public override Guid GetGuid(int ordinal) => Guid.Parse(GetString(ordinal));
    public override char GetChar(int ordinal) => char.Parse(GetString(ordinal));
    public override long GetBytes(int ordinal, long dataOffset, byte[]? buffer, int bufferOffset, int length) =>
        throw new NotSupportedException("Binary values are exposed as the API's string representation.");
    public override long GetChars(int ordinal, long dataOffset, char[]? buffer, int bufferOffset, int length)
    {
        var text = GetString(ordinal);
        if (buffer is null) return text.Length;
        if (dataOffset < 0 || dataOffset > text.Length || bufferOffset < 0 || length < 0 || bufferOffset > buffer.Length - length)
            throw new ArgumentOutOfRangeException();
        var count = Math.Min(length, text.Length - (int)dataOffset);
        text.CopyTo((int)dataOffset, buffer, bufferOffset, count);
        return count;
    }
    public override IEnumerator GetEnumerator() => new DbEnumerator(this, false);
    public override DataTable GetSchemaTable()
    {
        var table = new DataTable("SchemaTable") { Locale = CultureInfo.InvariantCulture };
        table.Columns.Add("ColumnName", typeof(string)); table.Columns.Add("ColumnOrdinal", typeof(int));
        table.Columns.Add("DataType", typeof(Type)); table.Columns.Add("AllowDBNull", typeof(bool));
        table.Columns.Add("ColumnSize", typeof(int)); table.Columns.Add("DataTypeName", typeof(string));
        for (var i = 0; i < FieldCount; i++) table.Rows.Add(GetName(i), i, GetFieldType(i), true, -1, GetDataTypeName(i));
        return table;
    }
}
