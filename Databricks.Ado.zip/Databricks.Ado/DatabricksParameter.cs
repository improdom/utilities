using System.Collections;
using System.Data;
using System.Data.Common;
using System.Globalization;
using Microsoft.Azure.Databricks.Client.Models;

namespace Databricks.Ado;

public sealed class DatabricksParameter : DbParameter
{
    private DbType? type;
    private ParameterDirection direction = ParameterDirection.Input;
    public DatabricksParameter() { }
    public DatabricksParameter(string name, object? value) { ParameterName = name; Value = value; }
    public override DbType DbType { get => type ?? Infer(Value); set => type = value; }
    public override ParameterDirection Direction { get => direction; set { if (value != ParameterDirection.Input) throw new NotSupportedException("Only input parameters are supported."); direction = value; } }
    public override bool IsNullable { get; set; }
    public override string ParameterName { get; set; } = "";
    public override string SourceColumn { get; set; } = "";
    public override object? Value { get; set; }
    public override bool SourceColumnNullMapping { get; set; }
    public override int Size { get; set; }
    public override void ResetDbType() => type = null;
    private static DbType Infer(object? value) => value switch
    {
        bool => DbType.Boolean, byte or sbyte => DbType.Byte, short => DbType.Int16, int => DbType.Int32,
        long => DbType.Int64, float => DbType.Single, double => DbType.Double, decimal => DbType.Decimal,
        DateOnly => DbType.Date, DateTime => DbType.DateTime2, DateTimeOffset => DbType.DateTimeOffset,
        byte[] => DbType.Binary, _ => DbType.String
    };
    internal SqlStatementParameter ToApi()
    {
        var name = ParameterName.TrimStart(':');
        if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Parameter names cannot be empty.");
        var sqlType = DbType switch
        {
            DbType.Boolean => "BOOLEAN", DbType.Byte or DbType.SByte or DbType.Int16 => "SMALLINT",
            DbType.Int32 => "INT", DbType.Int64 => "BIGINT", DbType.Single => "FLOAT", DbType.Double => "DOUBLE",
            DbType.Decimal or DbType.Currency or DbType.VarNumeric => $"DECIMAL({(Precision == 0 ? 38 : Precision)},{(Precision == 0 ? DecimalScale() : Scale)})",
            DbType.Date => "DATE", DbType.DateTime or DbType.DateTime2 or DbType.DateTimeOffset => "TIMESTAMP",
            DbType.String or DbType.AnsiString or DbType.StringFixedLength or DbType.AnsiStringFixedLength or DbType.Guid => "STRING",
            _ => throw new NotSupportedException($"Parameter type {DbType} is unsupported.")
        };
        string? value = Value switch
        {
            null or DBNull => null,
            bool b => b ? "true" : "false",
            DateOnly d => d.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
            DateTime d => d.ToString(DbType == DbType.Date ? "yyyy-MM-dd" : "yyyy-MM-dd HH:mm:ss.fffffff", CultureInfo.InvariantCulture),
            DateTimeOffset d => d.UtcDateTime.ToString("yyyy-MM-dd HH:mm:ss.fffffff", CultureInfo.InvariantCulture),
            IFormattable f => f.ToString(null, CultureInfo.InvariantCulture),
            _ => Value.ToString()
        };
        return new SqlStatementParameter { Name = name, Type = sqlType, Value = value };
    }
    private int DecimalScale() => Value is decimal d ? (decimal.GetBits(d)[3] >> 16) & 0x7f : Scale;
}

internal sealed class DatabricksParameterCollection : DbParameterCollection
{
    private readonly List<DbParameter> items = new();
    public override int Count => items.Count;
    public override object SyncRoot => ((ICollection)items).SyncRoot;
    public override int Add(object value) { if (value is not DatabricksParameter p) throw new ArgumentException("Use DatabricksParameter."); items.Add(p); return items.Count - 1; }
    public override void AddRange(Array values) { foreach (var value in values) Add(value!); }
    public override void Clear() => items.Clear();
    public override bool Contains(object value) => value is DbParameter p && items.Contains(p);
    public override bool Contains(string value) => IndexOf(value) >= 0;
    public override void CopyTo(Array array, int index) => ((ICollection)items).CopyTo(array, index);
    public override IEnumerator GetEnumerator() => items.GetEnumerator();
    public override int IndexOf(object value) => value is DbParameter p ? items.IndexOf(p) : -1;
    public override int IndexOf(string name) => items.FindIndex(p => string.Equals(p.ParameterName.TrimStart(':'), name.TrimStart(':'), StringComparison.Ordinal));
    public override void Insert(int index, object value) { if (value is not DatabricksParameter p) throw new ArgumentException("Use DatabricksParameter."); items.Insert(index, p); }
    public override void Remove(object value) { if (value is DbParameter p) items.Remove(p); }
    public override void RemoveAt(int index) => items.RemoveAt(index);
    public override void RemoveAt(string name) => RemoveAt(IndexOf(name));
    protected override DbParameter GetParameter(int index) => items[index];
    protected override DbParameter GetParameter(string name) => GetParameter(IndexOf(name));
    protected override void SetParameter(int index, DbParameter value) { if (value is not DatabricksParameter) throw new ArgumentException("Use DatabricksParameter."); items[index] = value; }
    protected override void SetParameter(string name, DbParameter value) { var i = IndexOf(name); if (i < 0) Add(value); else SetParameter(i, value); }
}
