# Databricks ADO.NET query wrapper

A small .NET 8 library using **Microsoft.Azure.Databricks.Client 2.8.0** for all Databricks operations. It accepts the same `DatabricksClient` you use for jobs. `DbConnection`, `DbCommand`, and `DbDataReader` implement `IDbConnection`, `IDbCommand`, and `IDataReader` respectively.

## Usage

Add a project reference to `Databricks.Ado/Databricks.Ado.csproj`, then:

```csharp
using System.Data;
using Databricks.Ado;
using Microsoft.Azure.Databricks.Client;

// Reuse your existing client here; its credentials/authentication remain unchanged.
DatabricksClient client = existingClient;

using IDbConnection connection = new DatabricksConnection(
    client, warehouseId: "your-warehouse-id", catalog: "main", schema: "default");
connection.Open();

using IDbCommand command = connection.CreateCommand();
command.CommandText = "SELECT id, name FROM customers WHERE id = :id";
command.CommandTimeout = 60;
var parameter = command.CreateParameter();
parameter.ParameterName = "id";
parameter.Value = 123;
command.Parameters.Add(parameter);

using IDataReader reader = command.ExecuteReader();
while (reader.Read())
{
    int id = reader.GetInt32(reader.GetOrdinal("id"));
    int nameOrdinal = reader.GetOrdinal("name");
    string? name = reader.IsDBNull(nameOrdinal) ? null : reader.GetString(nameOrdinal);
    Console.WriteLine($"{id}: {name}");
}
```

Match typed accessors to your SQL column types: `INT` → `GetInt32`, `BIGINT` → `GetInt64`. Alternatively use `reader["column"]` or `GetValue`. SQL NULL maps to `DBNull.Value`. Named parameters use `:name` SQL markers; values are sent separately to the client, without SQL interpolation.

For async callers, use the concrete types or `DbConnection`/`DbCommand`: `await connection.OpenAsync()` and `await command.ExecuteReaderAsync(cancellationToken)`. The synchronous interfaces block until results are ready. `CommandTimeout` defaults to 30 seconds; zero disables it. Timeout/cancellation raises `OperationCanceledException` and attempts remote cancellation once a statement ID is available. If initial submission is interrupted before an ID is received, remote execution may continue.

## Scope and behavior

- `Open()` opens a logical connection locally. Authentication and warehouse access are checked on first execution. Closing/disposing the wrapper never disposes the caller's shared client.
- Executes one SQL text statement through `client.SQL.StatementExecution`; polls pending/running statements and retrieves all result chunks using the manifest's chunk count.
- Results use `INLINE`/`JSON_ARRAY` and are buffered before returning the reader. Suitable for small query results; the API limits inline results to 25 MiB. Truncation and mismatched row counts raise an exception rather than silently returning partial results.
- Supports `ExecuteReader`, `ExecuteScalar`, input parameters, basic schema metadata, and `CommandBehavior.CloseConnection`. `SingleRow` restricts the returned reader after fetching results. `SequentialAccess` is accepted but data remains buffered.
- Boolean, integer, floating point, date/timestamp, and decimal columns (precision ≤ 28) map to CLR values. Higher-precision decimals, binary, complex and other types remain their API string representation to avoid precision loss or speculative decoding. `GetBytes` is unsupported. Timestamps without offsets remain unspecified-kind `DateTime` values.
- Transactions, stored procedures, output parameters, `ExecuteNonQuery`, `SchemaOnly`, and `KeyInfo` are unsupported. `Prepare()` validates locally. No ORM compatibility is promised.
- Do not execute one command concurrently or mutate it during execution. Configure HTTP timeouts/retries on your existing client. An underlying client HTTP timeout may expire before this wrapper's command timeout.

## Build and verify

```text
dotnet build Databricks.Ado/Databricks.Ado.csproj
dotnet run --project Databricks.Ado.Tests/Databricks.Ado.Tests.csproj
```

The tests use the actual package's `IStatementExecutionApi` interface with a fake implementation; no warehouse credentials are required. A live warehouse integration test has not been run.

References: [Azure Databricks client source](https://github.com/Azure/azure-databricks-client), [Statement Execution API](https://docs.databricks.com/api/statement-execution/v1/statement-execution).
