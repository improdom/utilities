namespace DaxQueryBuilder.Enums
{
    public enum Orders
    {
        ASC,
        DESC
    }
}
