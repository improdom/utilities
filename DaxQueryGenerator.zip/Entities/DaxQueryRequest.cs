using System.Collections.Generic;

namespace DaxQueryGenerator.Entities
{
    public class DaxQueryRequest
    {
        public int Id { get; set; }
        public int? TopN { get; set; }
        public bool GroupByAttributes { get; set; } = true;
        public bool DistinctResult { get; set; } = false;

        public List<DaxQueryAttribute> Attributes { get; set; }
        public List<DaxQueryMeasure> Measures { get; set; }
        public List<DaxQueryFilter> Filters { get; set; }
        public List<DaxQueryRowFilter> RowFilters { get; set; }
        public List<DaxQueryVariable> Variables { get; set; }
        public List<DaxQuerySortField> SortFields { get; set; }
        public DaxQueryTopNPerGroupOption TopNPerGroupOption { get; set; }
    }
}
