using System.Collections.Generic;

namespace DaxQueryGenerator.Models
{
    public class DaxQueryRequest
    {
        public List<string> Attributes { get; set; }
        public List<Measure> Measures { get; set; }
        public FilterGroup Filters { get; set; }
        public List<RowFilter> RowFilters { get; set; }
        public List<Variable> Variables { get; set; }
        public List<SortField> Sort { get; set; }
        public int? TopN { get; set; }
        public QueryOptions Options { get; set; }
    }

    public class Measure
    {
        public string Name { get; set; }
        public string Alias { get; set; }
        public string Aggregation { get; set; }
    }

    public class FilterGroup
    {
        public string Operator { get; set; }
        public List<object> Conditions { get; set; }
    }

    public class FilterCondition
    {
        public string Table { get; set; }
        public string Column { get; set; }
        public string Operator { get; set; }
        public object Value { get; set; }
    }

    public class RowFilter
    {
        public string Expression { get; set; }
    }

    public class Variable
    {
        public string Name { get; set; }
        public string Expression { get; set; }
    }

    public class SortField
    {
        public string Field { get; set; }
        public string Direction { get; set; }
    }

    public class QueryOptions
    {
        public bool GroupByAttributes { get; set; }
        public bool Distinct { get; set; }
        public TopNPerGroupOptions TopNPerGroup { get; set; }
    }

    public class TopNPerGroupOptions
    {
        public List<string> GroupBy { get; set; }
        public int TopN { get; set; }
        public string OrderByMeasure { get; set; }
        public string OrderDirection { get; set; }
    }
}
