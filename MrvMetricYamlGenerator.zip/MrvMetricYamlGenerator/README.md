# MRV Metric View YAML Generator (Databricks)

This sample project packages the classes discussed in the chat:
- Reads mapping rows from SQL Server (`cubiq.cubiq_metadata`)
- Extracts table aliases from a Metric View YAML template (`source`, `joins`, etc.)
- Adapts existing MRV filters into SQL-capable filters
- Enriches filters with `SourceTableName`/`SourceColumnName` using SQL mapping + YAML alias index
- Renders Databricks Metric View measure expressions: `SUM(...) FILTER (WHERE ...)`
- Injects measures into the YAML template (replacing `measures:` only)
- Uploads YAML to Databricks Workspace using the Workspace Import API

## Build & Run

Open `MrvMetricYamlGenerator.sln` in Visual Studio, set `src/MrvMetricYamlGenerator` as startup project, and run.

`Program.cs` shows an example pipeline. Replace:
- SQL Server connection string
- Databricks host + token
- YAML template content
- Measure/base expression mapping
- Filters input (in your production code you already have them)

## Notes

- The alias extraction is schema-tolerant and looks for common keys: `source`, `joins`, plus `name/table/dataset` and `alias/as`.
- If your YAML schema uses different keys, update `MetricViewAliasIndex` key lists accordingly.
