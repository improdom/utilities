using System;
using System.Collections.Generic;
using System.Linq;

namespace MrvBuilder.MetricsViews;

public interface IMetricExprRenderer
{
    string RenderExpr(MeasureMetadata measure);
}

public sealed class DatabricksMetricExprRenderer : IMetricExprRenderer
{
    public string RenderExpr(MeasureMetadata measure)
    {
        if (measure is null) throw new ArgumentNullException(nameof(measure));
        if (measure.Base is null || string.IsNullOrWhiteSpace(measure.Base.SqlExpression))
            throw new ArgumentException("Measure.Base.SqlExpression is required.");

        var whereClauses = new List<string>();

        foreach (var f in measure.Filters ?? Enumerable.Empty<Filter>())
        {
            if (f.Values is { Count: > 0 })
            {
                whereClauses.Add(RenderInClause(f));
            }
            else if (!string.IsNullOrWhiteSpace(f.ScalarValue))
            {
                whereClauses.Add(RenderScalarClause(f));
            }
        }

        if (whereClauses.Count == 0)
            return measure.Base.SqlExpression;

        var where = string.Join("\nAND ", whereClauses);
        return $"{measure.Base.SqlExpression} FILTER (WHERE {where})";
    }

    private static string RenderInClause(Filter f)
    {
        var col = f.GetSqlColumnRef();
        var values = string.Join(", ", f.Values.Select(FormatValue));

        return f.FilterType switch
        {
            FilterType.Include => $"{col} IN ({values})",
            FilterType.Exclude => $"{col} NOT IN ({values})",
            _ => throw new NotSupportedException($"Unsupported FilterType: {f.FilterType}")
        };
    }

    private static string RenderScalarClause(Filter f)
    {
        var col = f.GetSqlColumnRef();
        var value = f.ScalarIsString ? $"'{EscapeSqlString(f.ScalarValue!)}'" : f.ScalarValue!;

        return f.FilterType switch
        {
            FilterType.Include => $"{col} = {value}",
            FilterType.Exclude => $"{col} <> {value}",
            _ => throw new NotSupportedException($"Unsupported FilterType: {f.FilterType}")
        };
    }

    private static string FormatValue(FilterValue v)
        => v.IsString ? $"'{EscapeSqlString(v.Raw)}'" : v.Raw;

    private static string EscapeSqlString(string s)
        => s.Replace("'", "''");
}
