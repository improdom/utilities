using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace MrvBuilder.MetricsViews;

public sealed class DatabricksWorkspaceDeployer
{
    private readonly HttpClient _http;
    private readonly Uri _baseUri;

    public DatabricksWorkspaceDeployer(HttpClient http, string workspaceHost, string token)
    {
        _http = http ?? throw new ArgumentNullException(nameof(http));

        if (!workspaceHost.StartsWith("http", StringComparison.OrdinalIgnoreCase))
            throw new ArgumentException("workspaceHost must be like https://<workspace-host>");

        _baseUri = new Uri(workspaceHost.TrimEnd('/') + "/");
        _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
    }

    public async Task UploadYamlAsync(string workspacePath, string yamlContent, CancellationToken ct = default)
    {
        var b64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(yamlContent));

        var payload = new
        {
            path = workspacePath,
            format = "AUTO",
            overwrite = true,
            content = b64
        };

        var url = new Uri(_baseUri, "api/2.0/workspace/import");
        using var req = new HttpRequestMessage(HttpMethod.Post, url)
        {
            Content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json")
        };

        using var resp = await _http.SendAsync(req, ct);
        var body = await resp.Content.ReadAsStringAsync(ct);

        if (!resp.IsSuccessStatusCode)
            throw new InvalidOperationException($"Databricks workspace import failed ({(int)resp.StatusCode}): {body}");
    }
}
