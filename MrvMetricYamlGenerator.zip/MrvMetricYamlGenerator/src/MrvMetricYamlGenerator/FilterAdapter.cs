using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

using Old = Marvel.CubiQ.MrvDaxBuilder;
using New = MrvBuilder.MetricsViews;

namespace MrvBuilder.MetricsViews;

public interface IFilterAdapter<in TOldFilter, out TNewFilter>
{
    TNewFilter Adapt(TOldFilter oldFilter);
}

public sealed class FilterAdapter : IFilterAdapter<Old.Filter, New.Filter>
{
    public New.Filter Adapt(Old.Filter oldFilter)
    {
        if (oldFilter is null) throw new ArgumentNullException(nameof(oldFilter));

        var nf = new New.Filter
        {
            Dimension = oldFilter.Dimension,
            Attribute = oldFilter.Attribute,
            SourceTableName = oldFilter.SourceTableName,     // may be null; will be enriched
            SourceColumnName = oldFilter.SourceColumnName,   // may be null; will be enriched
            FilterType = MapFilterType(oldFilter.FilterType)
        };

        var raw = (oldFilter.FilterValue ?? string.Empty).Trim();
        if (string.IsNullOrWhiteSpace(raw))
            return nf;

        var tokens = SplitToTokens(raw);

        if (tokens.Count > 1)
        {
            foreach (var t in tokens)
                nf.Values.Add(ToFilterValue(t));
            return nf;
        }

        // scalar
        var single = tokens[0];
        var fv = ToFilterValue(single);
        nf.ScalarValue = fv.Raw;
        nf.ScalarIsString = fv.IsString;
        return nf;
    }

    private static New.FilterType MapFilterType(Old.FilterType oldType) =>
        oldType switch
        {
            Old.FilterType.Include => New.FilterType.Include,
            Old.FilterType.Exclude => New.FilterType.Exclude,
            Old.FilterType.TableInclude => New.FilterType.Include,
            _ => New.FilterType.Include
        };

    private static List<string> SplitToTokens(string raw)
    {
        raw = raw.Trim();

        // common wrappers
        raw = raw.Replace("{", string.Empty).Replace("}", string.Empty);
        raw = raw.Replace("IN (", string.Empty, StringComparison.OrdinalIgnoreCase).Replace(")", string.Empty);

        var tokens = raw.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                        .Select(t => t.Trim())
                        .Where(t => t.Length > 0)
                        .ToList();

        if (tokens.Count == 0)
            tokens.Add(raw);

        return tokens;
    }

    private static New.FilterValue ToFilterValue(string token)
    {
        token = token.Trim();

        if ((token.StartsWith(""") && token.EndsWith(""")) ||
            (token.StartsWith("'") && token.EndsWith("'")))
        {
            token = token[1..^1];
            return New.FilterValue.Str(token);
        }

        if (long.TryParse(token, NumberStyles.Integer, CultureInfo.InvariantCulture, out var n))
            return New.FilterValue.Num(n);

        return New.FilterValue.Str(token);
    }
}
