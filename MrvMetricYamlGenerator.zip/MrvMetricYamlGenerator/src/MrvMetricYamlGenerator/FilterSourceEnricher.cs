using System;
using System.Collections.Generic;

namespace MrvBuilder.MetricsViews;

public sealed class FilterSourceEnricher
{
    private readonly IReadOnlyDictionary<DimAttrKey, AttributeMappingRow> _index;
    private readonly MetricViewAliasIndex _aliasIndex;

    public FilterSourceEnricher(IReadOnlyDictionary<DimAttrKey, AttributeMappingRow> index, MetricViewAliasIndex aliasIndex)
    {
        _index = index ?? throw new ArgumentNullException(nameof(index));
        _aliasIndex = aliasIndex ?? throw new ArgumentNullException(nameof(aliasIndex));
    }

    public void Enrich(IEnumerable<Filter> filters, bool throwIfMissing = true)
    {
        foreach (var f in filters)
        {
            if (!string.IsNullOrWhiteSpace(f.SourceColumnName))
                continue;

            if (string.IsNullOrWhiteSpace(f.Dimension) || string.IsNullOrWhiteSpace(f.Attribute))
            {
                if (throwIfMissing)
                    throw new InvalidOperationException("Filter missing Dimension/Attribute; cannot map to source column.");
                continue;
            }

            var key = new DimAttrKey(f.Dimension!, f.Attribute!);

            if (!_index.TryGetValue(key, out var row))
            {
                if (throwIfMissing)
                    throw new KeyNotFoundException($"No mapping found for Dimension='{f.Dimension}', Attribute='{f.Attribute}'.");
                continue;
            }

            f.SourceColumnName = row.AttributeName;

            // Derive alias from YAML, fallback to mapping table's table name
            f.SourceTableName = _aliasIndex.TryGetAlias(row.TableName) ?? row.TableName;

            if (!string.IsNullOrWhiteSpace(f.ScalarValue))
                f.ScalarIsString = IsStringType(row.DataType);
        }
    }

    private static bool IsStringType(string dataType)
    {
        dataType = (dataType ?? "").Trim().ToLowerInvariant();
        return dataType is "string" or "varchar" or "nvarchar" or "char" or "text" or "date" or "timestamp";
    }
}
