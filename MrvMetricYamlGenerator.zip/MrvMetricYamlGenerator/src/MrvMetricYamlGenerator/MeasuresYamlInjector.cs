using System;
using System.Collections.Generic;
using System.IO;
using YamlDotNet.RepresentationModel;

namespace MrvBuilder.MetricsViews;

public sealed class MetricMeasureYaml
{
    public required string Name { get; init; }
    public required string Expr { get; init; }
}

public sealed class MetricMeasuresBuilder
{
    private readonly IMetricExprRenderer _renderer;

    public MetricMeasuresBuilder(IMetricExprRenderer renderer) => _renderer = renderer;

    public List<MetricMeasureYaml> BuildYamlMeasures(IEnumerable<MeasureMetadata> measures)
    {
        var list = new List<MetricMeasureYaml>();
        foreach (var m in measures)
        {
            list.Add(new MetricMeasureYaml
            {
                Name = m.Name,
                Expr = _renderer.RenderExpr(m)
            });
        }
        return list;
    }
}

public sealed class MeasuresYamlInjector
{
    public string InjectMeasures(string templateYaml, IReadOnlyList<MetricMeasureYaml> measures)
    {
        if (templateYaml is null) throw new ArgumentNullException(nameof(templateYaml));
        if (measures is null) throw new ArgumentNullException(nameof(measures));

        var stream = new YamlStream();
        stream.Load(new StringReader(templateYaml));

        if (stream.Documents.Count == 0)
            throw new InvalidOperationException("Template YAML has no documents.");

        if (stream.Documents[0].RootNode is not YamlMappingNode root)
            throw new InvalidOperationException("Template YAML root is not a mapping node.");

        var seq = new YamlSequenceNode();

        foreach (var m in measures)
        {
            seq.Add(new YamlMappingNode
            {
                { "name", new YamlScalarNode(m.Name) },
                { "expr", new YamlScalarNode(m.Expr) }
            });
        }

        root.Children[new YamlScalarNode("measures")] = seq;

        using var sw = new StringWriter();
        stream.Save(sw, assignAnchors: false);
        return sw.ToString();
    }
}
