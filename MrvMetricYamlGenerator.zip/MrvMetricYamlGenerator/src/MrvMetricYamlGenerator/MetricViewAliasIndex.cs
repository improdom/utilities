using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using YamlDotNet.RepresentationModel;

namespace MrvBuilder.MetricsViews;

public sealed class MetricViewAliasIndex
{
    private readonly Dictionary<string, string> _map;

    private MetricViewAliasIndex(Dictionary<string, string> map) => _map = map;

    public string? TryGetAlias(string logicalTableName)
    {
        if (string.IsNullOrWhiteSpace(logicalTableName)) return null;
        return _map.TryGetValue(logicalTableName.Trim(), out var alias) ? alias : null;
    }

    public static MetricViewAliasIndex FromYamlTemplate(string templateYaml)
    {
        if (templateYaml is null) throw new ArgumentNullException(nameof(templateYaml));

        var yaml = new YamlStream();
        yaml.Load(new StringReader(templateYaml));

        if (yaml.Documents.Count == 0)
            throw new InvalidOperationException("YAML template contains no documents.");

        if (yaml.Documents[0].RootNode is not YamlMappingNode root)
            throw new InvalidOperationException("YAML root node must be a mapping.");

        var map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        // source section
        if (TryGetMapping(root, "source", out var sourceNode))
            ExtractNameAliasPairs(sourceNode, map);

        // joins section
        if (TryGetSequence(root, "joins", out var joinsSeq))
        {
            foreach (var item in joinsSeq.Children.OfType<YamlNode>())
                ExtractNameAliasPairs(item, map);
        }

        // alternate keys used in other schemas
        foreach (var altKey in new[] { "relationships", "datasets", "tables" })
        {
            if (TryGetSequence(root, altKey, out var seq))
            {
                foreach (var item in seq.Children.OfType<YamlNode>())
                    ExtractNameAliasPairs(item, map);
            }
        }

        return new MetricViewAliasIndex(map);
    }

    private static void ExtractNameAliasPairs(YamlNode node, Dictionary<string, string> map)
    {
        if (node is not YamlMappingNode m)
            return;

        // Common key variants across YAML schemas
        var logicalName = TryGetFirstScalar(m, "name", "table", "dataset", "relation", "from");
        var alias = TryGetFirstScalar(m, "alias", "as");

        if (!string.IsNullOrWhiteSpace(logicalName) && !string.IsNullOrWhiteSpace(alias))
        {
            map[logicalName!] = alias!;
            return;
        }

        // Recursive scan for nested join objects
        foreach (var child in m.Children.Values)
        {
            switch (child)
            {
                case YamlMappingNode cm:
                    var cn = TryGetFirstScalar(cm, "name", "table", "dataset", "relation", "from");
                    var ca = TryGetFirstScalar(cm, "alias", "as");
                    if (!string.IsNullOrWhiteSpace(cn) && !string.IsNullOrWhiteSpace(ca))
                        map[cn!] = ca!;
                    break;

                case YamlSequenceNode cs:
                    foreach (var item in cs.Children)
                        ExtractNameAliasPairs(item, map);
                    break;
            }
        }
    }

    private static bool TryGetMapping(YamlMappingNode root, string key, out YamlMappingNode mapping)
    {
        mapping = null!;
        var node = GetChild(root, key);
        if (node is YamlMappingNode m)
        {
            mapping = m;
            return true;
        }
        return false;
    }

    private static bool TryGetSequence(YamlMappingNode root, string key, out YamlSequenceNode seq)
    {
        seq = null!;
        var node = GetChild(root, key);
        if (node is YamlSequenceNode s)
        {
            seq = s;
            return true;
        }
        return false;
    }

    private static YamlNode? GetChild(YamlMappingNode root, string key)
    {
        foreach (var kvp in root.Children)
        {
            if (kvp.Key is YamlScalarNode ks &&
                string.Equals(ks.Value, key, StringComparison.OrdinalIgnoreCase))
                return kvp.Value;
        }
        return null;
    }

    private static string? TryGetFirstScalar(YamlMappingNode m, params string[] keys)
    {
        foreach (var key in keys)
        {
            foreach (var kvp in m.Children)
            {
                if (kvp.Key is YamlScalarNode ks &&
                    string.Equals(ks.Value, key, StringComparison.OrdinalIgnoreCase))
                {
                    if (kvp.Value is YamlScalarNode vs)
                        return vs.Value;
                }
            }
        }
        return null;
    }
}
