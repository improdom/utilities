using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace MrvBuilder.MetricsViews;

public sealed class MetricViewYamlProvisioner
{
    private readonly MetricMeasuresBuilder _measuresBuilder;
    private readonly MeasuresYamlInjector _injector;
    private readonly DatabricksWorkspaceDeployer _deployer;

    public MetricViewYamlProvisioner(
        MetricMeasuresBuilder measuresBuilder,
        MeasuresYamlInjector injector,
        DatabricksWorkspaceDeployer deployer)
    {
        _measuresBuilder = measuresBuilder;
        _injector = injector;
        _deployer = deployer;
    }

    public async Task GenerateAndDeployAsync(
        string templateYaml,
        IReadOnlyList<MeasureMetadata> measures,
        string targetWorkspaceYamlPath,
        CancellationToken ct = default)
    {
        var yamlMeasures = _measuresBuilder.BuildYamlMeasures(measures);
        var finalYaml = _injector.InjectMeasures(templateYaml, yamlMeasures);
        await _deployer.UploadYamlAsync(targetWorkspaceYamlPath, finalYaml, ct);
    }
}
