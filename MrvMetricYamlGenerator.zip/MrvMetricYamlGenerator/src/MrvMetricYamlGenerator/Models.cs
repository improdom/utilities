namespace MrvBuilder.MetricsViews;

public enum FilterType
{
    Include,
    Exclude
}

public readonly record struct FilterValue(string Raw, bool IsString)
{
    public static FilterValue Str(string s) => new(s, true);
    public static FilterValue Num(long n) => new(n.ToString(), false);
    public static FilterValue Num(string n) => new(n, false);
}

public sealed class Filter
{
    // Existing MRV semantics
    public string? Dimension { get; set; }
    public string? Attribute { get; set; }
    public FilterType FilterType { get; set; } = FilterType.Include;

    // New: SQL source targeting (populated via mapping + YAML aliases)
    public string? SourceTableName { get; set; }   // alias (preferred) or logical table
    public string? SourceColumnName { get; set; }  // column name

    // Values (IN list)
    public List<FilterValue> Values { get; set; } = new();

    // Scalar filter support
    public string? ScalarValue { get; set; }
    public bool ScalarIsString { get; set; } = true;

    public string GetSqlColumnRef()
    {
        if (string.IsNullOrWhiteSpace(SourceColumnName))
            throw new InvalidOperationException("Filter.SourceColumnName is required for SQL rendering.");

        if (string.IsNullOrWhiteSpace(SourceTableName))
            return SourceColumnName!;

        return $"{SourceTableName}.{SourceColumnName}";
    }
}

public sealed class BaseExpression
{
    // Example: "SUM(source.reporting_value)"
    public required string SqlExpression { get; init; }
}

public sealed class MeasureMetadata
{
    public required string Name { get; init; } // YAML measure name
    public required BaseExpression Base { get; init; }
    public List<Filter> Filters { get; init; } = new();
}
