// These stubs exist only so this sample solution compiles standalone.
// In your MRV Builder solution, remove this file and reference your real types.
namespace Marvel.CubiQ.MrvDaxBuilder;

public enum FilterType
{
    Include,
    Exclude,
    TableInclude
}

public sealed class Filter
{
    public string? Dimension { get; set; }
    public string? Attribute { get; set; }
    public string? FilterValue { get; set; }
    public FilterType FilterType { get; set; } = FilterType.Include;

    // The properties you added in your codebase:
    public string? SourceTableName { get; set; }
    public string? SourceColumnName { get; set; }
}
