using System.Net.Http;
using MrvBuilder.MetricsViews;

Console.WriteLine("MRV Metric View YAML Generator (sample)");

/*
 * Replace these with your real values or inject via environment variables / config.
 */
var sqlConnectionString = "Server=YOUR_SQL;Database=YOUR_DB;Integrated Security=true;TrustServerCertificate=true;";
var databricksHost = "https://YOUR_WORKSPACE_HOST";
var databricksToken = "YOUR_DATABRICKS_TOKEN";
var targetWorkspaceYamlPath = "/Shared/metric_views/cubiq_semantic_view.yaml";

/*
 * Minimal example YAML template. In production, read from file or embedded resource.
 * The alias extractor reads `source` and `joins` sections to map logical table name -> alias.
 */
var yamlTemplate = """
name: cubiq_semantic_view
source:
  name: risk_report_view
  alias: source
joins:
  - name: desk
    alias: book
  - name: position
    alias: pos
measures: []
""";

// Example: your existing filters list already exists in MRV Builder. Here we just stub them.
var oldFilters = new List<Marvel.CubiQ.MrvDaxBuilder.Filter>
{
    new() { Dimension = "desk", Attribute = "risk_book", FilterType = Marvel.CubiQ.MrvDaxBuilder.FilterType.Include, FilterValue = "Yes" },
    new() { Dimension = "risk_report_view", Attribute = "lingua_risk_measure_id", FilterType = Marvel.CubiQ.MrvDaxBuilder.FilterType.Include, FilterValue = "7" },
    new() { Dimension = "risk_report_view", Attribute = "mrv_partition", FilterType = Marvel.CubiQ.MrvDaxBuilder.FilterType.Include, FilterValue = "253086428,264527080,385145945" },
    // Unqualified example: if you want f_Num unqualified, you can set SourceColumnName directly on the new Filter
};

// 1) Adapt old filters -> new filters
var adapter = new FilterAdapter();
var newFilters = oldFilters.Select(adapter.Adapt).ToList();

// 2) Load SQL mapping & build index
var repo = new SqlServerAttributeMappingRepository(sqlConnectionString);
// NOTE: Uncomment to actually load from SQL Server
// var mappingRows = await repo.LoadAsync();
// var mappingIndex = AttributeMappingIndex.BuildIndex(mappingRows);

// For demo, we'll fake mappingIndex. In your app, load from SQL server as above.
var mappingIndex = new Dictionary<DimAttrKey, AttributeMappingRow>
{
    [new DimAttrKey("desk", "risk_book")] = new AttributeMappingRow { TableName = "desk", AttributeName = "risk_book", DataType = "string" },
    [new DimAttrKey("risk_report_view", "lingua_risk_measure_id")] = new AttributeMappingRow { TableName = "risk_report_view", AttributeName = "lingua_risk_measure_id", DataType = "int" },
    [new DimAttrKey("risk_report_view", "mrv_partition")] = new AttributeMappingRow { TableName = "risk_report_view", AttributeName = "mrv_partition", DataType = "int" },
};

// 3) Build alias index from YAML template and enrich filters
var aliasIndex = MetricViewAliasIndex.FromYamlTemplate(yamlTemplate);
var enricher = new FilterSourceEnricher(mappingIndex, aliasIndex);
enricher.Enrich(newFilters, throwIfMissing: true);

// 4) Build measures
var measures = new List<MeasureMetadata>
{
    new()
    {
        Name = "Credit_Delta",
        Base = new BaseExpression { SqlExpression = "SUM(source.reporting_value)" },
        Filters = newFilters
    }
};

// 5) Render + inject YAML (and optionally deploy)
var renderer = new DatabricksMetricExprRenderer();
var measureBuilder = new MetricMeasuresBuilder(renderer);
var injector = new MeasuresYamlInjector();

var yamlMeasures = measureBuilder.BuildYamlMeasures(measures);
var finalYaml = injector.InjectMeasures(yamlTemplate, yamlMeasures);

Console.WriteLine("Generated YAML:");
Console.WriteLine(finalYaml);

// 6) Deploy to Databricks Workspace (uncomment when ready)
/*
using var http = new HttpClient();
var deployer = new DatabricksWorkspaceDeployer(http, databricksHost, databricksToken);
await deployer.UploadYamlAsync(targetWorkspaceYamlPath, finalYaml);
Console.WriteLine($"Uploaded to {targetWorkspaceYamlPath}");
*/
