using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading;
using System.Threading.Tasks;

namespace MrvBuilder.MetricsViews;

public sealed class AttributeMappingRow
{
    public required string TableName { get; init; }
    public required string AttributeName { get; init; }
    public required string DataType { get; init; }
    public string? BusinessTableName { get; init; }
    public string? BusinessAttributeName { get; init; }
}

public readonly record struct DimAttrKey(string Dimension, string Attribute);

public static class AttributeMappingIndex
{
    public static Dictionary<DimAttrKey, AttributeMappingRow> BuildIndex(IEnumerable<AttributeMappingRow> rows)
    {
        var dict = new Dictionary<DimAttrKey, AttributeMappingRow>(new DimAttrKeyComparer());
        foreach (var r in rows)
        {
            var key = new DimAttrKey(r.TableName, r.AttributeName);
            dict[key] = r;
        }
        return dict;
    }

    private sealed class DimAttrKeyComparer : IEqualityComparer<DimAttrKey>
    {
        public bool Equals(DimAttrKey x, DimAttrKey y) =>
            string.Equals(x.Dimension, y.Dimension, StringComparison.OrdinalIgnoreCase) &&
            string.Equals(x.Attribute, y.Attribute, StringComparison.OrdinalIgnoreCase);

        public int GetHashCode(DimAttrKey obj)
        {
            var h1 = StringComparer.OrdinalIgnoreCase.GetHashCode(obj.Dimension ?? "");
            var h2 = StringComparer.OrdinalIgnoreCase.GetHashCode(obj.Attribute ?? "");
            return (h1 * 397) ^ h2;
        }
    }
}

public sealed class SqlServerAttributeMappingRepository
{
    private readonly string _connectionString;

    public SqlServerAttributeMappingRepository(string connectionString)
        => _connectionString = connectionString ?? throw new ArgumentNullException(nameof(connectionString));

    public async Task<List<AttributeMappingRow>> LoadAsync(CancellationToken ct = default)
    {
        const string sql = @"
select
    [table_name],
    [attribute_name],
    [data_type],
    [business_table_name],
    [business_attribute_name]
from [cubiq].[cubiq_metadata];";

        var results = new List<AttributeMappingRow>();

        using var conn = new SqlConnection(_connectionString);
        await conn.OpenAsync(ct);

        using var cmd = new SqlCommand(sql, conn) { CommandType = CommandType.Text };
        using var reader = await cmd.ExecuteReaderAsync(ct);

        while (await reader.ReadAsync(ct))
        {
            results.Add(new AttributeMappingRow
            {
                TableName = reader.GetString(reader.GetOrdinal("table_name")),
                AttributeName = reader.GetString(reader.GetOrdinal("attribute_name")),
                DataType = reader.GetString(reader.GetOrdinal("data_type")),
                BusinessTableName = reader.IsDBNull(reader.GetOrdinal("business_table_name"))
                    ? null : reader.GetString(reader.GetOrdinal("business_table_name")),
                BusinessAttributeName = reader.IsDBNull(reader.GetOrdinal("business_attribute_name"))
                    ? null : reader.GetString(reader.GetOrdinal("business_attribute_name")),
            });
        }

        return results;
    }
}
