
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace MrvBuilder.MetricsViews;

public sealed class DatabricksWorkspaceDeployer
{
    private readonly HttpClient _http;
    private readonly Uri _base;

    public DatabricksWorkspaceDeployer(HttpClient http, string host, string token)
    {
        _http = http;
        _base = new Uri(host.TrimEnd('/') + "/");
        _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
    }

    public async Task UploadYamlAsync(string path, string yaml)
    {
        var b64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(yaml));
        var payload = new { path, format = "AUTO", overwrite = true, content = b64 };
        var req = new HttpRequestMessage(HttpMethod.Post, new Uri(_base,"api/2.0/workspace/import"))
        {
            Content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8,"application/json")
        };
        var resp = await _http.SendAsync(req);
        if (!resp.IsSuccessStatusCode)
            throw new Exception(await resp.Content.ReadAsStringAsync());
    }
}
