
namespace MrvBuilder.MetricsViews;

public sealed class DatabricksFilterCriteriaRenderer
{
    public string Render(IEnumerable<Filter> filters)
    {
        var parts = new List<string>();

        foreach (var f in filters)
        {
            var col = f.GetSqlColumnRef();

            if (f.Values.Any())
            {
                var vals = string.Join(", ", f.Values.Select(v => v.IsString ? $"'{v.Raw}'" : v.Raw));
                parts.Add(f.FilterType == FilterType.Exclude
                    ? $"{col} NOT IN ({vals})"
                    : $"{col} IN ({vals})");
            }
            else if (!string.IsNullOrWhiteSpace(f.ScalarValue))
            {
                var v = f.ScalarIsString ? $"'{f.ScalarValue}'" : f.ScalarValue;
                parts.Add(f.FilterType == FilterType.Exclude
                    ? $"{col} <> {v}"
                    : $"{col} = {v}");
            }
        }

        return string.Join(" AND ", parts);
    }
}
