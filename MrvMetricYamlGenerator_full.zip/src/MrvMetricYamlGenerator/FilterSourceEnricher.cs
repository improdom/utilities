
namespace MrvBuilder.MetricsViews;

public sealed class FilterSourceEnricher
{
    private readonly IReadOnlyDictionary<DimAttrKey, AttributeMappingRow> _index;
    private readonly ITableQualifierResolver _resolver;

    public FilterSourceEnricher(IReadOnlyDictionary<DimAttrKey, AttributeMappingRow> index,
                                ITableQualifierResolver resolver)
    {
        _index = index;
        _resolver = resolver;
    }

    public void Enrich(IEnumerable<Filter> filters)
    {
        foreach (var f in filters)
        {
            if (f.SourceColumnName != null) continue;
            var key = new DimAttrKey(f.Dimension!, f.Attribute!);
            if (!_index.TryGetValue(key, out var row)) continue;

            f.SourceColumnName = row.AttributeName;
            f.SourceTableName = _resolver.ResolveQualifier(row.TableName);
        }
    }
}
