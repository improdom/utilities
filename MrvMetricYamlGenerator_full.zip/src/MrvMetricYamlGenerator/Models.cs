
namespace MrvBuilder.MetricsViews;

public enum FilterType { Include, Exclude }

public readonly record struct FilterValue(string Raw, bool IsString);

public sealed class Filter
{
    public string? Dimension { get; set; }
    public string? Attribute { get; set; }
    public FilterType FilterType { get; set; }
    public string? SourceTableName { get; set; }
    public string? SourceColumnName { get; set; }
    public List<FilterValue> Values { get; set; } = new();
    public string? ScalarValue { get; set; }
    public bool ScalarIsString { get; set; }

    public string GetSqlColumnRef()
        => string.IsNullOrWhiteSpace(SourceTableName)
            ? SourceColumnName!
            : $"{SourceTableName}.{SourceColumnName}";
}

public sealed class BaseExpression
{
    public required string SqlExpression { get; init; }
}

public sealed class MeasureMetadata
{
    public required string Name { get; init; }
    public required BaseExpression Base { get; init; }
    public List<Filter> Filters { get; init; } = new();
}
