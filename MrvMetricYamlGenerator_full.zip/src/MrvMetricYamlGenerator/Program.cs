
using MrvBuilder.MetricsViews;

Console.WriteLine("Full simplified MRV generator ready.");
