
using System.Data;
using System.Data.SqlClient;

namespace MrvBuilder.MetricsViews;

public sealed class AttributeMappingRow
{
    public required string TableName { get; init; }
    public required string AttributeName { get; init; }
    public required string DataType { get; init; }
}

public readonly record struct DimAttrKey(string Dimension, string Attribute);

public static class AttributeMappingIndex
{
    public static Dictionary<DimAttrKey, AttributeMappingRow> BuildIndex(IEnumerable<AttributeMappingRow> rows)
    {
        var dict = new Dictionary<DimAttrKey, AttributeMappingRow>(new DimAttrComparer());
        foreach (var r in rows)
            dict[new DimAttrKey(r.TableName, r.AttributeName)] = r;
        return dict;
    }

    private sealed class DimAttrComparer : IEqualityComparer<DimAttrKey>
    {
        public bool Equals(DimAttrKey x, DimAttrKey y)
            => x.Dimension.Equals(y.Dimension, StringComparison.OrdinalIgnoreCase)
            && x.Attribute.Equals(y.Attribute, StringComparison.OrdinalIgnoreCase);

        public int GetHashCode(DimAttrKey obj)
            => HashCode.Combine(obj.Dimension.ToLower(), obj.Attribute.ToLower());
    }
}

public sealed class SqlServerAttributeMappingRepository
{
    private readonly string _connectionString;
    public SqlServerAttributeMappingRepository(string cs) => _connectionString = cs;

    public async Task<List<AttributeMappingRow>> LoadAsync()
    {
        const string sql = "select table_name, attribute_name, data_type from cubiq.cubiq_metadata";
        var results = new List<AttributeMappingRow>();
        using var conn = new SqlConnection(_connectionString);
        await conn.OpenAsync();
        using var cmd = new SqlCommand(sql, conn);
        using var r = await cmd.ExecuteReaderAsync();
        while (await r.ReadAsync())
        {
            results.Add(new AttributeMappingRow
            {
                TableName = r.GetString(0),
                AttributeName = r.GetString(1),
                DataType = r.GetString(2)
            });
        }
        return results;
    }
}
