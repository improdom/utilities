
namespace MrvBuilder.MetricsViews;

public interface ITableQualifierResolver
{
    string? ResolveQualifier(string logicalTableName);
}

public sealed class DefaultTableQualifierResolver : ITableQualifierResolver
{
    private readonly string _baseLogicalTable;
    private readonly string _baseAlias;

    public DefaultTableQualifierResolver(string baseLogicalTable = "risk_report_view", string baseAlias = "source")
    {
        _baseLogicalTable = baseLogicalTable;
        _baseAlias = baseAlias;
    }

    public string? ResolveQualifier(string logicalTableName)
        => string.Equals(logicalTableName, _baseLogicalTable, StringComparison.OrdinalIgnoreCase)
            ? _baseAlias
            : logicalTableName;
}
