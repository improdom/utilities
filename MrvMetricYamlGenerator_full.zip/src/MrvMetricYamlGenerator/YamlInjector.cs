
using YamlDotNet.RepresentationModel;

namespace MrvBuilder.MetricsViews;

public sealed class MeasuresYamlInjector
{
    public string Inject(string template, string filter, IEnumerable<MeasureMetadata> measures)
    {
        var stream = new YamlStream();
        stream.Load(new StringReader(template));
        var root = (YamlMappingNode)stream.Documents[0].RootNode;

        root.Children[new YamlScalarNode("filter")] = new YamlScalarNode(filter);

        var seq = new YamlSequenceNode();
        foreach (var m in measures)
        {
            seq.Add(new YamlMappingNode
            {
                { "name", new YamlScalarNode(m.Name) },
                { "expr", new YamlScalarNode(m.Base.SqlExpression) }
            });
        }
        root.Children[new YamlScalarNode("measures")] = seq;

        using var sw = new StringWriter();
        stream.Save(sw);
        return sw.ToString();
    }
}
