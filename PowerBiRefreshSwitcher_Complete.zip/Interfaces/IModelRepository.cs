using System;
using System.Threading.Tasks;
using PowerBiRefreshSwitcher.Models;

namespace PowerBiRefreshSwitcher.Interfaces
{
    public interface IModelRepository
    {
        Task<ModelState> GetCurrentModelStateAsync();
        Task<WorkerModel> GetModelByIdAsync(Guid id);
        Task SwapReaderWriterAsync();
        Task LogRefreshAsync(Guid modelId, bool success, string? errorMessage = null);
    }
}
