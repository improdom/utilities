using System;
using System.Threading.Tasks;
namespace PowerBiRefreshSwitcher.Interfaces
{
    public interface IModelSwitchService
    {
        Task<Guid?> ExecuteRefreshCycleAsync();
    }
}
