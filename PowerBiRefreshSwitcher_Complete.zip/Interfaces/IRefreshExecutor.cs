using System.Threading.Tasks;
using PowerBiRefreshSwitcher.Models;

namespace PowerBiRefreshSwitcher.Interfaces
{
    public interface IRefreshExecutor
    {
        Task RefreshModelAsync(WorkerModel model);
    }
}
