using System.Threading.Tasks;

namespace PowerBiRefreshSwitcher.Interfaces
{
    public interface IRouterModelService
    {
        Task UpdateRouterModelConnectionAsync(string newReaderModelName);
    }
}
