using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PowerBiRefreshSwitcher.Models
{
    [Table("model_refresh_log")]
    public class ModelRefreshLog
    {
        [Key]
        public Guid ModelRefreshLogId { get; set; }
        public Guid WorkerModelId { get; set; }
        public DateTime RefreshStartedAt { get; set; }
        public DateTime? RefreshEndedAt { get; set; }
        public string Status { get; set; }
        public string Message { get; set; }
    }
}
