using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PowerBiRefreshSwitcher.Models
{
    [Table("model_role_history")]
    public class ModelRoleHistory
    {
        [Key]
        public Guid ModelRoleHistoryId { get; set; }
        public Guid WorkerModelId { get; set; }
        public string Role { get; set; }
        public bool IsCurrent { get; set; }
        public DateTime ActivatedAt { get; set; }
        public DateTime? DeactivatedAt { get; set; }
        public string SwitchReason { get; set; }
    }
}
