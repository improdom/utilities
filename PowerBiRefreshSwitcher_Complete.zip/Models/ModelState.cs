using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PowerBiRefreshSwitcher.Models
{
    [Table("model_state")]
    public class ModelState
    {
        [Key]
        public Guid ModelStateId { get; set; }
        public Guid ReaderModelId { get; set; }
        public Guid WriterModelId { get; set; }
        public string Status { get; set; }
        public DateTime? LastSwitchTime { get; set; }
        public DateTime UpdatedAt { get; set; }
    }
}
