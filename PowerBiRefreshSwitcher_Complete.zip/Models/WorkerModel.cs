using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PowerBiRefreshSwitcher.Models
{
    [Table("worker_model")]
    public class WorkerModel
    {
        [Key]
        public Guid WorkerModelId { get; set; }
        public string ModelName { get; set; }
        public Guid WorkspaceId { get; set; }
        public Guid DatasetId { get; set; }
        public bool IsEnabled { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }
}
