using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using PowerBiRefreshSwitcher.Interfaces;
using PowerBiRefreshSwitcher.Repositories;
using PowerBiRefreshSwitcher.Services;

var services = new ServiceCollection();
services.AddLogging(config => config.AddConsole());

services.AddSingleton<IModelRepository, ModelRepository>(); // TODO: Implement
services.AddSingleton<IRouterModelService, RouterModelService>(); // TODO: Implement
services.AddSingleton<IRefreshExecutor, RefreshExecutor>(); // TODO: Implement
services.AddSingleton<IModelSwitchService, ModelSwitchService>();

var serviceProvider = services.BuildServiceProvider();
var switchService = serviceProvider.GetRequiredService<IModelSwitchService>();
await switchService.ExecuteRefreshCycleAsync();
