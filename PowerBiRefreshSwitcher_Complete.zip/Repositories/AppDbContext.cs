using Microsoft.EntityFrameworkCore;
using PowerBiRefreshSwitcher.Models;

namespace PowerBiRefreshSwitcher.Repositories
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<WorkerModel> WorkerModels { get; set; }
        public DbSet<ModelState> ModelStates { get; set; }
        public DbSet<ModelRoleHistory> ModelRoleHistories { get; set; }
        public DbSet<ModelRefreshLog> ModelRefreshLogs { get; set; }
    }
}
