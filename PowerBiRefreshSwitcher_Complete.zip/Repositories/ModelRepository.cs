using System;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using PowerBiRefreshSwitcher.Interfaces;
using PowerBiRefreshSwitcher.Models;

namespace PowerBiRefreshSwitcher.Repositories
{
    public class ModelRepository : IModelRepository
    {
        private readonly AppDbContext _context;

        public ModelRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<ModelState> GetCurrentModelStateAsync()
        {
            return await _context.ModelStates.FirstOrDefaultAsync();
        }

        public async Task<WorkerModel> GetModelByIdAsync(Guid id)
        {
            return await _context.WorkerModels.FindAsync(id);
        }

        public async Task SwapReaderWriterAsync()
        {
            var state = await GetCurrentModelStateAsync();
            var temp = state.ReaderModelId;
            state.ReaderModelId = state.WriterModelId;
            state.WriterModelId = temp;
            state.LastSwitchTime = DateTime.UtcNow;
            state.UpdatedAt = DateTime.UtcNow;
            await _context.SaveChangesAsync();
        }

        public async Task LogRefreshAsync(Guid modelId, bool success, string errorMessage = null)
        {
            var log = new ModelRefreshLog
            {
                ModelRefreshLogId = Guid.NewGuid(),
                WorkerModelId = modelId,
                RefreshStartedAt = DateTime.UtcNow,
                RefreshEndedAt = DateTime.UtcNow,
                Status = success ? "success" : "failure",
                Message = errorMessage
            };
            await _context.ModelRefreshLogs.AddAsync(log);
            await _context.SaveChangesAsync();
        }
    }
}
