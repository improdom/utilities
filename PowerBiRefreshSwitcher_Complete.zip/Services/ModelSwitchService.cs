using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using PowerBiRefreshSwitcher.Interfaces;
using PowerBiRefreshSwitcher.Models;

namespace PowerBiRefreshSwitcher.Services
{
    public class ModelSwitchService : IModelSwitchService
    {
        private readonly IModelRepository _modelRepo;
        private readonly IRouterModelService _routerService;
        private readonly IRefreshExecutor _refreshExecutor;
        private readonly ILogger<ModelSwitchService> _logger;

        public ModelSwitchService(
            IModelRepository modelRepo,
            IRouterModelService routerService,
            IRefreshExecutor refreshExecutor,
            ILogger<ModelSwitchService> logger)
        {
            _modelRepo = modelRepo;
            _routerService = routerService;
            _refreshExecutor = refreshExecutor;
            _logger = logger;
        }

        public async Task<Guid?> ExecuteRefreshCycleAsync()
        {
            _logger.LogInformation("🔁 Starting refresh cycle...");

            WorkerModel newWriterModel;

            try
            {
                newWriterModel = await SwitchModelsAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Failed during model switching or router update. Aborting refresh.");
                return null;
            }

            try
            {
                _logger.LogInformation("♻️ Refreshing Writer model: {Writer}", newWriterModel.ModelName);
                await _refreshExecutor.RefreshModelAsync(newWriterModel);
                await _modelRepo.LogRefreshAsync(newWriterModel.Id, success: true);
                _logger.LogInformation("✅ Writer model refreshed successfully.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Writer model refresh failed: {Writer}", newWriterModel.ModelName);
                await _modelRepo.LogRefreshAsync(newWriterModel.Id, success: false, errorMessage: ex.Message);
                return null;
            }

            return newWriterModel.Id;
        }

        private async Task<WorkerModel> SwitchModelsAsync()
        {
            await _modelRepo.SwapReaderWriterAsync();

            var newState = await _modelRepo.GetCurrentModelStateAsync();
            var newReader = await _modelRepo.GetModelByIdAsync(newState.ReaderModelId);
            var newWriter = await _modelRepo.GetModelByIdAsync(newState.WriterModelId);

            await _routerService.UpdateRouterModelConnectionAsync(newReader.ModelName);
            return newWriter;
        }
    }
}
