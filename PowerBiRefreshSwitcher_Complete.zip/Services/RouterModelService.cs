using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AnalysisServices.Tabular;
using Microsoft.Extensions.Logging;
using PowerBiRefreshSwitcher.Interfaces;

namespace PowerBiRefreshSwitcher.Services
{
    public class RouterModelService : IRouterModelService
    {
        private readonly string _workspaceConnectionString;
        private readonly string _routerModelName;
        private readonly string _dataSourceName;
        private readonly ILogger<RouterModelService> _logger;

        public RouterModelService(
            string workspaceConnectionString,
            string routerModelName,
            string dataSourceName,
            ILogger<RouterModelService> logger)
        {
            _workspaceConnectionString = workspaceConnectionString;
            _routerModelName = routerModelName;
            _dataSourceName = dataSourceName;
            _logger = logger;
        }

        public async Task UpdateRouterModelConnectionAsync(string newReaderModelName)
        {
            try
            {
                _logger.LogInformation("Connecting to workspace: {Workspace}", _workspaceConnectionString);

                using var server = new Server();
                server.Connect(_workspaceConnectionString);

                var database = server.Databases[_routerModelName];
                if (database == null)
                    throw new InvalidOperationException($"Router model '{_routerModelName}' not found.");

                var dataSource = database.Model.DataSources
                    .OfType<ProviderDataSource>()
                    .FirstOrDefault(ds => ds.Name == _dataSourceName);

                if (dataSource == null)
                    throw new InvalidOperationException($"Data source '{_dataSourceName}' not found in router model.");

                string expectedConnection = $"DataSource={_workspaceConnectionString};Initial Catalog={newReaderModelName}";

                if (dataSource.ConnectionString == expectedConnection)
                {
                    _logger.LogInformation("Connection string already set to the correct reader model.");
                    return;
                }

                _logger.LogInformation("Updating router model to point to reader model: {Model}", newReaderModelName);
                dataSource.ConnectionString = expectedConnection;

                database.Model.SaveChanges();
                _logger.LogInformation("Router model updated successfully.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to update router model connection.");
                throw;
            }
        }
    }
}
