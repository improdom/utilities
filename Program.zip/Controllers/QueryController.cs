using Microsoft.AspNetCore.Mvc;
using SsasPbiProxyApi.Models;
using SsasPbiProxyApi.Models.Dtos;
using SsasPbiProxyApi.Services;

namespace SsasPbiProxyApi.Controllers;

[ApiController]
[Route("v1")]
public sealed class QueryController : ControllerBase
{
    private readonly IQueryExecutionService _svc;

    public QueryController(IQueryExecutionService svc)
    {
        _svc = svc;
    }

    /// <summary>
    /// Execute DAX or MDX queries against Power BI or SSAS cube using Power BI compatible API format.
    /// Each query specifies its own type (as string): "DAX" for Power BI, "MDX" for SSAS Cube.
    /// QueryType defaults to "DAX" if not provided.
    /// Supports concurrent execution of multiple queries of mixed types.
    /// Matches: https://learn.microsoft.com/en-us/rest/api/power-bi/datasets/execute-queries
    /// </summary>
    [HttpPost("myorg/datarelay/executeQueries")]
    [Produces("application/json")]
    public async Task<ActionResult<ExecuteQueriesResponse>> ExecuteQueries(
        [FromBody] ExecuteQueriesRequest request,
        CancellationToken ct)
    {
        // Validate request
        if (request?.Queries == null || request.Queries.Count == 0)
        {
            return BadRequest(new ExecuteQueriesResponse
            {
                Error = new ExecuteQueriesError
                {
                    Code = "InvalidArgument",
                    Message = "At least one query must be provided"
                }
            });
        }

        // Validate query types
        foreach (var query in request.Queries)
        {
            if (!Enum.IsDefined(typeof(QueryType), query.QueryType))
            {
                return BadRequest(new ExecuteQueriesResponse
                {
                    Error = new ExecuteQueriesError
                    {
                        Code = "InvalidArgument",
                        Message = $"Invalid QueryType. Supported values: {string.Join(", ", Enum.GetNames(typeof(QueryType)))}"
                    }
                });
            }
        }

        try
        {
            var response = await _svc.ExecuteAsync(request, ct);
            return Ok(response);
        }
        catch (Exception ex)
        {
            return StatusCode(500, new ExecuteQueriesResponse
            {
                Error = new ExecuteQueriesError
                {
                    Code = "ServerException",
                    Message = ex.Message
                }
            });
        }
    }

    [HttpGet("healthz")]
    public IActionResult Healthz() => Ok(new { status = "ok" });
}
