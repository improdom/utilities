using System.Net;
using System.Text.Json;
using SsasPbiProxyApi.Models.Dtos;

namespace SsasPbiProxyApi.Middleware;

public sealed class PowerBiStyleExceptionMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<PowerBiStyleExceptionMiddleware> _logger;

    public PowerBiStyleExceptionMiddleware(RequestDelegate next, ILogger<PowerBiStyleExceptionMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task Invoke(HttpContext context)
    {
        var correlationId = context.TraceIdentifier;

        try
        {
            context.Response.Headers["x-correlation-id"] = correlationId;
            await _next(context);
        }
        catch (OperationCanceledException) when (context.RequestAborted.IsCancellationRequested)
        {
            // Client canceled request.
            context.Response.StatusCode = 499;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unhandled error. CorrelationId={CorrelationId}", correlationId);

            var status = MapStatus(ex);
            context.Response.StatusCode = (int)status;
            context.Response.ContentType = "application/json";

            var response = new ExecuteQueriesResponse
            {
                Error = new ExecuteQueriesError
                {
                    Code = status == HttpStatusCode.BadRequest ? "BadRequest" : "ServerError",
                    Message = ex.Message
                }
            };

            await context.Response.WriteAsync(JsonSerializer.Serialize(response, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            }));
        }
    }

    private static HttpStatusCode MapStatus(Exception ex)
        => ex switch
        {
            InvalidOperationException => HttpStatusCode.BadRequest,
            ArgumentException => HttpStatusCode.BadRequest,
            _ => HttpStatusCode.InternalServerError
        };
}
