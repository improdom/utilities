namespace SsasPbiProxyApi.Models.Dtos;

/// <summary>
/// Power BI compatible error details
/// Matches: https://learn.microsoft.com/en-us/rest/api/power-bi/datasets/execute-queries
/// </summary>
public sealed class ExecuteQueriesError
{
    /// <summary>
    /// The code associated with the error
    /// </summary>
    public string Code { get; set; } = default!;

    /// <summary>
    /// The message of the error
    /// </summary>
    public string Message { get; set; } = default!;
}
