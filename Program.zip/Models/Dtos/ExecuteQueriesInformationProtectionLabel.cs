namespace SsasPbiProxyApi.Models.Dtos;

/// <summary>
/// Power BI compatible information protection label details
/// Matches: https://learn.microsoft.com/en-us/rest/api/power-bi/datasets/execute-queries
/// </summary>
public sealed class ExecuteQueriesInformationProtectionLabel
{
    /// <summary>
    /// The identifier (guid) of the information protection label
    /// </summary>
    public string? Id { get; set; }

    /// <summary>
    /// The display name of the information protection label
    /// </summary>
    public string? Name { get; set; }
}
