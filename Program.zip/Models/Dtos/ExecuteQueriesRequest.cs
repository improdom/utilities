using System.ComponentModel.DataAnnotations;

namespace SsasPbiProxyApi.Models.Dtos;

/// <summary>
/// Power BI compatible request to execute queries against a dataset or SSAS cube
/// Matches: https://learn.microsoft.com/en-us/rest/api/power-bi/datasets/execute-queries
/// Extended to support both DAX (Power BI) and MDX (SSAS) queries
/// Each query specifies its own type to support mixed query types in a single request
/// Supports concurrent execution of multiple queries
/// </summary>
public sealed class ExecuteQueriesRequest
{
    /// <summary>
    /// The list of queries to execute concurrently
    /// Each query will be executed in parallel against the target specified by its QueryType
    /// Supports mixed DAX and MDX queries in the same request
    /// </summary>
    [Required]
    public List<ExecuteQuery> Queries { get; set; } = new();

    /// <summary>
    /// The serialization settings for the result set
    /// </summary>
    public ExecuteQueriesSerializationSettings? SerializerSettings { get; set; }
}
