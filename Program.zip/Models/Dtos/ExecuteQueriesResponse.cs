namespace SsasPbiProxyApi.Models.Dtos;

/// <summary>
/// A response schema modeled after Power BI REST "execute queries" patterns:
/// Matches: https://learn.microsoft.com/en-us/rest/api/power-bi/datasets/execute-queries
/// Structure: results -> tables -> rows
/// </summary>
public sealed class ExecuteQueriesResponse
{
    /// <summary>
    /// The list of results, one per input query
    /// </summary>
    public List<ExecuteQueryResult> Results { get; set; } = new();

    /// <summary>
    /// The details of an error, if present (at root level)
    /// </summary>
    public ExecuteQueriesError? Error { get; set; }

    /// <summary>
    /// The details of the information protection label, if any, associated with the dataset
    /// </summary>
    public ExecuteQueriesInformationProtectionLabel? InformationProtectionLabel { get; set; }
}
