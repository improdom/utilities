namespace SsasPbiProxyApi.Models.Dtos;

/// <summary>
/// Power BI compatible serialization settings for query results
/// </summary>
public sealed class ExecuteQueriesSerializationSettings
{
    /// <summary>
    /// Whether null (blank) values should be included in the result set.
    /// If unspecified, the default value is false.
    /// </summary>
    public bool IncludeNulls { get; set; } = false;
}
