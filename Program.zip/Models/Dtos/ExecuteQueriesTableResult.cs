namespace SsasPbiProxyApi.Models.Dtos;

/// <summary>
/// A table of data in the query result
/// </summary>
public sealed class ExecuteQueriesTableResult
{
    /// <summary>
    /// A list of rows, where each row is an object keyed by column names
    /// </summary>
    public List<Dictionary<string, object?>> Rows { get; set; } = new();

    /// <summary>
    /// The details of an error, if present (at table level)
    /// </summary>
    public ExecuteQueriesError? Error { get; set; }
}
