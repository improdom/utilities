using System.ComponentModel.DataAnnotations;

namespace SsasPbiProxyApi.Models.Dtos;

/// <summary>
/// Represents a single query to execute (DAX or MDX)
/// </summary>
public sealed class ExecuteQuery
{
    /// <summary>
    /// Optional identifier for this query. If provided, will be echoed back in the result for correlation.
    /// Useful for correlating results when multiple queries are executed.
    /// </summary>
    public string? Id { get; set; }

    /// <summary>
    /// Query type: DAX for Power BI datasets, MDX for SSAS cubes
    /// Used to identify the target source for this query.
    /// Defaults to DAX if not provided.
    /// </summary>
    public QueryType QueryType { get; set; } = QueryType.DAX;

    /// <summary>
    /// The query string to be executed (DAX or MDX)
    /// </summary>
    [Required]
    public string Query { get; set; } = default!;
}
