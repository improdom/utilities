namespace SsasPbiProxyApi.Models.Dtos;

/// <summary>
/// The results from a single dataset query
/// </summary>
public sealed class ExecuteQueryResult
{
    /// <summary>
    /// The identifier of the query this result corresponds to (echoed from the request for correlation)
    /// </summary>
    public string? Id { get; set; }

    /// <summary>
    /// A list of tables data for a query
    /// </summary>
    public List<ExecuteQueriesTableResult> Tables { get; set; } = new();

    /// <summary>
    /// The details of an error, if present (at query result level)
    /// </summary>
    public ExecuteQueriesError? Error { get; set; }
}
