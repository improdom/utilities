using System.Text.Json.Serialization;

namespace SsasPbiProxyApi.Models;

/// <summary>
/// Query type: DAX for Power BI datasets, MDX for SSAS cubes
/// </summary>
[JsonConverter(typeof(JsonStringEnumConverter))]
public enum QueryType
{
    DAX = 0,
    MDX = 1
}
