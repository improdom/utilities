namespace SsasPbiProxyApi.Options;

public sealed class ProxyOptions
{
    public int DefaultRowLimit { get; set; } = 100000;
    public int CommandTimeoutSeconds { get; set; } = 300;
    public int MaxQueryChars { get; set; } = 200000;
}

public sealed class TargetOptions
{
    public string ConnectionString { get; set; } = default!;
    public string? FriendlyName { get; set; }
}

public sealed class TargetsOptions
{
    public Dictionary<string, TargetOptions> Targets { get; set; } = new();
}
