using Microsoft.OpenApi.Models;
using SsasPbiProxyApi.Middleware;
using SsasPbiProxyApi.Options;
using SsasPbiProxyApi.Services;
using System.Text.Json;

var builder = WebApplication.CreateBuilder(args);

// Controllers + JSON settings
builder.Services.AddControllers()
    .AddJsonOptions(o =>
    {
        // Power BI APIs use camelCase
        o.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
        o.JsonSerializerOptions.DictionaryKeyPolicy = JsonNamingPolicy.CamelCase;
        o.JsonSerializerOptions.DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull;
    });

// Swagger
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "SSAS / Power BI Proxy API",
        Version = "v1",
        Description = "Executes DAX/MDX against SSAS or Power BI XMLA and returns Power BI–style JSON."
    });
});

// Options
builder.Services.Configure<ProxyOptions>(builder.Configuration.GetSection("Proxy"));
builder.Services.Configure<Dictionary<string, TargetOptions>>(builder.Configuration.GetSection("Targets"));

// Services
builder.Services.AddScoped<IQueryExecutionService, AdomdQueryExecutionService>();

var app = builder.Build();

// Middleware
app.UseMiddleware<PowerBiStyleExceptionMiddleware>();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// Typical production additions you should wire up:
// app.UseAuthentication();
// app.UseAuthorization();

app.MapControllers();

app.Run();
