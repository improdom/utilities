# SsasPbiProxyApi

A lightweight ASP.NET Core REST API that acts as a **proxy** for executing **DAX** or **MDX** queries against:

- **SSAS** (on-prem or Azure Analysis Services)
- **Power BI** via **XMLA endpoint** (Premium / Fabric capacities)

It returns a JSON response intentionally shaped to be **compatible with the Power BI "execute queries" style** response:
`results -> tables -> rows`, with optional `columns` metadata for easy integration.

## Endpoints

- `POST /v1/query`  Execute a DAX/MDX query and return Power BI–style JSON
- `GET  /healthz`   Liveness check

Swagger UI is available at `/swagger` in Development.

## Build & Run

```bash
dotnet restore
dotnet run
```

> Configure connection strings in `appsettings.json` (or environment variables).

## Example Request

```json
{
  "target": "SsasCube",
  "queryType": "DAX",
  "query": "EVALUATE ROW( \"Answer\", 42 )",
  "options": {
    "rowLimit": 1000,
    "includeColumns": true
  }
}
```

## Example Response (Power BI–style)

```json
{
  "results": [
    {
      "tables": [
        {
          "name": "PrimaryResult",
          "columns": [
            { "name": "Answer", "dataType": "Int64" }
          ],
          "rows": [
            { "Answer": 42 }
          ]
        }
      ]
    }
  ]
}
```

## Security Notes (Important)

- This template intentionally does **not** include auth. In production, add:
  - AAD/JWT auth (recommended), or at minimum an API key / mTLS.
  - Allowlist targets and limit query size/timeouts.
  - Audit logging (query hash, duration, rowcount), **avoid logging full query text**.

## Databricks Notebook Usage (pseudo)

```python
import requests, json

payload = {
  "target": "SsasCube",
  "queryType": "MDX",
  "query": "SELECT ... FROM [Cube]"
}

r = requests.post("https://<host>/v1/query", json=payload, timeout=600)
r.raise_for_status()
data = r.json()

rows = data["results"][0]["tables"][0]["rows"]
```
