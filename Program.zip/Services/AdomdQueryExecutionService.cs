using Microsoft.AnalysisServices.AdomdClient;
using Microsoft.Extensions.Options;
using SsasPbiProxyApi.Models;
using SsasPbiProxyApi.Models.Dtos;
using SsasPbiProxyApi.Options;
using System.Data;

namespace SsasPbiProxyApi.Services;

public sealed class AdomdQueryExecutionService : IQueryExecutionService
{
    private readonly ProxyOptions _proxy;
    private readonly IDictionary<string, TargetOptions> _targets;
    private readonly ILogger<AdomdQueryExecutionService> _logger;

    public AdomdQueryExecutionService(
        IOptions<ProxyOptions> proxyOptions,
        IOptions<Dictionary<string, TargetOptions>> targetsOptions,
        ILogger<AdomdQueryExecutionService> logger)
    {
        _proxy = proxyOptions.Value;
        _targets = targetsOptions.Value;
        _logger = logger;
    }

    public async Task<ExecuteQueriesResponse> ExecuteAsync(ExecuteQueriesRequest request, CancellationToken ct)
    {
        // Validate queries
        if (request.Queries == null || request.Queries.Count == 0)
            throw new InvalidOperationException("At least one query must be provided.");

        // Validate all required targets exist
        var uniqueQueryTypes = request.Queries.Select(q => q.QueryType).Distinct().ToList();
        foreach (var queryType in uniqueQueryTypes)
        {
            var targetKey = queryType == QueryType.DAX ? "PowerBi" : "Ssas";
            if (!_targets.TryGetValue(targetKey, out _))
                throw new InvalidOperationException($"Target '{targetKey}' not configured for {queryType} queries. Check configuration Targets:{targetKey}.");
        }

        // Get execution settings
        var rowLimit = _proxy.DefaultRowLimit;
        var timeoutSeconds = _proxy.CommandTimeoutSeconds;
        var includeNulls = request.SerializerSettings?.IncludeNulls ?? false;

        _logger.LogInformation(
            "Executing {QueryCount} queries. TimeoutSeconds={Timeout}",
            request.Queries.Count, timeoutSeconds);

        // Execute all queries concurrently
        var queryTasks = request.Queries.Select(q =>
        {
            var targetKey = q.QueryType == QueryType.DAX ? "PowerBi" : "Ssas";
            var target = _targets[targetKey];
            var queryTypeLabel = q.QueryType == QueryType.DAX ? "DAX" : "MDX";
            return ExecuteQueryAsync(q, target.ConnectionString, timeoutSeconds, rowLimit, includeNulls, queryTypeLabel, ct);
        }).ToList();

        var results = await Task.WhenAll(queryTasks);

        // Build response with all query results (one result per query for Power BI compatibility)
        var response = new ExecuteQueriesResponse();

        foreach (var queryResult in results)
        {
            response.Results.Add(queryResult);
        }

        _logger.LogInformation("All {QueryCount} queries completed", request.Queries.Count);

        return response;
    }

    private async Task<ExecuteQueryResult> ExecuteQueryAsync(
        ExecuteQuery query,
        string connectionString,
        int timeoutSeconds,
        int rowLimit,
        bool includeNulls,
        string queryTypeLabel,
        CancellationToken ct)
    {
        // Extract and validate query
        var queryText = query.Query ?? "";
        if (queryText.Length == 0)
            throw new InvalidOperationException("Query is empty.");
        if (queryText.Length > _proxy.MaxQueryChars)
            throw new InvalidOperationException($"Query too large. Limit is {_proxy.MaxQueryChars} chars.");

        var start = DateTimeOffset.UtcNow;

        // Execute query
        using var conn = new AdomdConnection(connectionString);
        await Task.Run(() => conn.Open(), ct);

        using var cmd = conn.CreateCommand();
        cmd.CommandText = queryText;
        cmd.CommandTimeout = timeoutSeconds;

        using var reader = await Task.Run(() => cmd.ExecuteReader(CommandBehavior.SequentialAccess), ct);

        // Build result for this query
        var result = new ExecuteQueryResult { Id = query.Id };

        int resultSetIndex = 0;
        do
        {
            var table = new ExecuteQueriesTableResult();

            int rowsRead = 0;
            while (await Task.Run(() => reader.Read(), ct))
            {
                if (rowsRead >= rowLimit) break;

                var rowObj = new Dictionary<string, object?>(StringComparer.OrdinalIgnoreCase);
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    var name = reader.GetName(i);
                    object? value = reader.IsDBNull(i) ? null : reader.GetValue(i);

                    // Skip null values if includeNulls is false
                    if (value == null && !includeNulls)
                        continue;

                    // Normalize DateTime to UTC
                    if (value is DateTime dt)
                        value = DateTime.SpecifyKind(dt, DateTimeKind.Utc);

                    rowObj[name] = value;
                }

                table.Rows.Add(rowObj);
                rowsRead++;
            }

            result.Tables.Add(table);
            resultSetIndex++;

            // If we broke due to row limit, consume remainder to allow NextResult() cleanly
            while (rowsRead >= rowLimit && await Task.Run(() => reader.Read(), ct)) { }
        }
        while (await Task.Run(() => reader.NextResult(), ct));

        var durMs = (DateTimeOffset.UtcNow - start).TotalMilliseconds;
        _logger.LogInformation(
            "{QueryType} query completed in {Ms} ms. ResultSets={Sets}",
            queryTypeLabel, (int)durMs, resultSetIndex);

        return result;
    }
}
