using SsasPbiProxyApi.Models.Dtos;

namespace SsasPbiProxyApi.Services;

public interface IQueryExecutionService
{
    Task<ExecuteQueriesResponse> ExecuteAsync(ExecuteQueriesRequest request, CancellationToken ct);
}
