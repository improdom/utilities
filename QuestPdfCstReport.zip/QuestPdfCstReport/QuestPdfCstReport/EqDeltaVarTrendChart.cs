using QuestPDF.Fluent;
using QuestPDF.Infrastructure;

public static class EqDeltaVarTrendChart
{
    private const int BarCount = 67;
    private const int ImageWidth = 1800;
    private const int ImageHeight = 1080;
    private const double LeftMin = -400;
    private const double LeftMax = 1000;
    private const double RightMin = -40;
    private const double RightMax = 60;

    private static readonly Sector[] Sectors =
    [
        new("Unknown", "#1F5F81"),
        new("Capital Markets Financing", "#9A918A"),
        new("Clearing", "#3E6B3D"),
        new("Corporate Derivatives", "#7D8790"),
        new("Credit", "#343B42"),
        new("DP - Principal Inv & Strat Ventures", "#A0AD78"),
        new("Electronic - Agency", "#415461"),
        new("Electronic - Principal", "#9AA1A5"),
        new("Equity Derivatives", "#0F6B72"),
        new("FX", "#9AB0BD"),
        new("GB Debt Capital Markets", "#40444A"),
        new("GB Leveraged Capital Markets", "#7B6864"),
        new("Management - Derivatives & Solutions", "#67737C"),
        new("Management - Execution Services", "#C7C1AE"),
        new("Principal Inv & Strat Ventures", "#6E2B34"),
        new("Quantitative Investment Solutions", "#8D989D"),
        new("Rates", "#C8BA73"),
        new("Risk-Taking (s)", "#694F45"),
        new("Securities Lending & Financing", "#D8D7D3"),
        new("Voice", "#363636")
    ];

    public static void Compose(IContainer container)
    {
        container.Image(RenderPng()).FitArea();
    }

    private static byte[] RenderPng()
    {
        var rows = CreateMockRows();
        var plot = new ScottPlot.Plot();

        ConfigurePlot(plot);
        AddStackedBars(plot, rows);
        AddRegVarLine(plot, rows);
        AddLegend(plot);

        var path = Path.Combine(Path.GetTempPath(), $"{Guid.NewGuid():N}-eq-delta-var-trend.png");

        try
        {
            plot.SavePng(path, ImageWidth, ImageHeight);
            return File.ReadAllBytes(path);
        }
        finally
        {
            if (File.Exists(path))
                File.Delete(path);
        }
    }

    private static void ConfigurePlot(ScottPlot.Plot plot)
    {
        plot.Title("Chart 7  EQ: EQ Delta by Sector vs Regulatory VaR Trend", size: 28);
        plot.YLabel("EQ Delta ex Funds", size: 20);

        plot.FigureBackground.Color = ScottPlot.Colors.White;
        plot.DataBackground.Color = ScottPlot.Colors.White;

        plot.Axes.SetLimitsX(-1, BarCount);
        plot.Axes.SetLimitsY(LeftMin, LeftMax);
        plot.Axes.Left.SetTicks(
            [1000, 800, 600, 400, 200, 0, -200, -400],
            ["1,000", "800", "600", "400", "200", "0", "(200)", "(400)"]);

        plot.Axes.Right.IsVisible = true;
        plot.Axes.Right.Label.Text = "Reg Var";
        plot.Axes.Right.Label.FontSize = 20;
        plot.Axes.Right.SetTicks(
            RightTicks().Select(MapRegVarToLeftAxis).ToArray(),
            ["(40)", "(20)", "0", "20", "40", "60"]);

        var tickPositions = DateTicks().Select(x => x.Position).ToArray();
        var tickLabels = DateTicks().Select(x => x.Label).ToArray();
        plot.Axes.Bottom.SetTicks(tickPositions, tickLabels);
        plot.Axes.Bottom.TickLabelStyle.Rotation = -90;
        plot.Axes.Bottom.TickLabelStyle.Alignment = ScottPlot.Alignment.MiddleRight;
        plot.Axes.Bottom.MinimumSize = 120;

        plot.Grid.MajorLineColor = ScottPlot.Color.FromHex("#E7E7E7");
        plot.Grid.MajorLineWidth = 1;
        plot.Axes.Color(ScottPlot.Color.FromHex("#69727A"));
        plot.Axes.FrameWidth(1);
    }

    private static void AddStackedBars(ScottPlot.Plot plot, IReadOnlyList<ChartRow> rows)
    {
        var bars = new List<ScottPlot.Bar>();

        for (var rowIndex = 0; rowIndex < rows.Count; rowIndex++)
        {
            var row = rows[rowIndex];
            var positiveBase = 0d;
            var negativeBase = 0d;

            for (var sectorIndex = 0; sectorIndex < Sectors.Length; sectorIndex++)
            {
                var value = row.Values[sectorIndex];

                if (Math.Abs(value) < 0.1)
                    continue;

                var valueBase = value >= 0 ? positiveBase : negativeBase;
                var valueTop = valueBase + value;

                bars.Add(new ScottPlot.Bar
                {
                    Position = rowIndex,
                    ValueBase = valueBase,
                    Value = valueTop,
                    Size = 0.68,
                    FillColor = ScottPlot.Color.FromHex(Sectors[sectorIndex].Color).WithAlpha(0.78),
                    LineWidth = 0
                });

                if (value >= 0)
                    positiveBase = valueTop;
                else
                    negativeBase = valueTop;
            }
        }

        plot.Add.Bars(bars.ToArray());
    }

    private static void AddRegVarLine(ScottPlot.Plot plot, IReadOnlyList<ChartRow> rows)
    {
        var xs = Enumerable.Range(0, rows.Count).Select(x => (double)x).ToArray();
        var ys = rows.Select(x => MapRegVarToLeftAxis(x.RegVar)).ToArray();

        var line = plot.Add.ScatterLine(xs, ys);
        line.Color = ScottPlot.Color.FromHex("#30383D");
        line.LineWidth = 4;
        line.LegendText = "Reg Var";
    }

    private static void AddLegend(ScottPlot.Plot plot)
    {
        plot.Legend.ManualItems.Add(new ScottPlot.LegendItem
        {
            LabelText = "Reg Var",
            LineColor = ScottPlot.Color.FromHex("#30383D"),
            LineWidth = 4
        });

        foreach (var sector in Sectors)
        {
            plot.Legend.ManualItems.Add(new ScottPlot.LegendItem
            {
                LabelText = sector.Name,
                FillColor = ScottPlot.Color.FromHex(sector.Color),
                LineColor = ScottPlot.Color.FromHex(sector.Color)
            });
        }

        plot.Legend.FontSize = 15;
        plot.Legend.Orientation = ScottPlot.Orientation.Horizontal;
        plot.Legend.OutlineStyle.IsVisible = false;
        plot.Legend.ShadowColor = ScottPlot.Colors.Transparent;
        plot.Legend.Padding = new(0);
        plot.ShowLegend(ScottPlot.Alignment.LowerCenter);
    }

    private static List<ChartRow> CreateMockRows()
    {
        var rows = new List<ChartRow>();
        var reg = new[]
        {
            -6, -4, -5, -1, -2, 0, -1, -3, -7, -6, -22, -14, -6, -2, 4, 9, 13, 14, 31, 10, 17, 21, 23, 28, 20, 31, 24,
            24, 21, 42, 26, 36, 39, 24, 25, 24, 7, 29, 26, 31, 36, 36, 25, 34, 23, 27, 22, 24, 21, -2, 7, 14, 20, 27,
            27, 26, 15, 40, 19, 19, 20, 22, 25, 20, 24, 18, 19
        };

        for (var index = 0; index < BarCount; index++)
        {
            var totalPositive = 320
                                + 120 * MathF.Sin(index * 0.42f)
                                + 70 * MathF.Sin(index * 0.17f + 1.1f)
                                + (index is >= 18 and <= 21 ? 220 : 0)
                                + (index is >= 58 and <= 66 ? 100 : 0);

            if (index is >= 30 and <= 44)
                totalPositive -= 80;

            var totalNegative = -55 - 45 * MathF.Abs(MathF.Sin(index * 0.36f + 0.7f));

            if (index is 16 or 17 or 38 or 39 or 46)
                totalNegative -= 130;

            if (index is 18 or 22 or 61)
                totalPositive += 170;

            rows.Add(new ChartRow(DistributeValues(index, totalPositive, totalNegative), reg[index]));
        }

        return rows;
    }

    private static double[] DistributeValues(int index, float positiveTotal, float negativeTotal)
    {
        var values = new double[Sectors.Length];
        var positiveWeights = new[] { 0.05f, 0.08f, 0.02f, 0.07f, 0.16f, 0.03f, 0.03f, 0.02f, 0.50f, 0.02f, 0.04f, 0.02f, 0.02f, 0.02f, 0.01f, 0.02f, 0.02f, 0.01f, 0.01f, 0.03f };
        var negativeWeights = new[] { 0.05f, 0.02f, 0.01f, 0.09f, 0.20f, 0.02f, 0.01f, 0.01f, 0.18f, 0.04f, 0.08f, 0.08f, 0.03f, 0.02f, 0.03f, 0.02f, 0.03f, 0.04f, 0.04f, 0.10f };

        for (var sector = 0; sector < values.Length; sector++)
        {
            var jitter = 0.84f + 0.28f * MathF.Abs(MathF.Sin((index + 1) * (sector + 3) * 0.19f));
            values[sector] = positiveTotal * positiveWeights[sector] * jitter;

            if (sector is 4 or 8 or 10 or 11 or 19 || (index + sector) % 9 == 0)
                values[sector] += negativeTotal * negativeWeights[sector] * (0.85f + 0.3f * MathF.Abs(MathF.Cos(index * 0.21f + sector)));
        }

        return values;
    }

    private static double MapRegVarToLeftAxis(double regVar)
    {
        var normalized = (regVar - RightMin) / (RightMax - RightMin);
        return LeftMin + normalized * (LeftMax - LeftMin);
    }

    private static double[] RightTicks() => [-40, -20, 0, 20, 40, 60];

    private static (double Position, string Label)[] DateTicks() =>
    [
        (4, "09-Jan"), (11, "16-Jan"), (18, "23-Jan"), (25, "30-Jan"),
        (32, "06-Feb"), (39, "13-Feb"), (46, "20-Feb"), (53, "27-Feb"),
        (60, "06-Mar"), (66, "10-Apr")
    ];

    private sealed record Sector(string Name, string Color);
    private sealed record ChartRow(double[] Values, double RegVar);
}
