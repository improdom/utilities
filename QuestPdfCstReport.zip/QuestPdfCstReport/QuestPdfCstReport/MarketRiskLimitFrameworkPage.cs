using System.Globalization;
using System.Text;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

public static class MarketRiskLimitFrameworkPage
{
    private const float RowHeight = 17.2f;
    private const string TextColor = "#2F3438";
    private const string Red = "#A73A4A";
    private const string Green = "#4A9A42";
    private const string Blue = "#2E5E9E";
    private const string Line = "#4D555C";
    private const string LightLine = "#C7CDD1";
    private const string HeaderFill = "#E7E3DF";

    public static void Compose(IContainer container)
    {
        container.Column(column =>
        {
            column.Item().Text("IB Market Risk Limit Framework Overview").FontSize(21).Bold().FontColor(TextColor);
            column.Item().Height(6);
            column.Item().Text("Key Highlights:").FontSize(9.5f).Bold().FontColor("#B02438");
            column.Item().Height(78);
            column.Item().Element(ComposeLimitTable);
            column.Item().Height(18);
            column.Item().Element(ComposeNotes);
        });
    }

    private static void ComposeLimitTable(IContainer container)
    {
        var groups = CreateData();

        container.Table(table =>
        {
            table.ColumnsDefinition(columns =>
            {
                columns.ConstantColumn(31);
                columns.ConstantColumn(256);
                columns.ConstantColumn(50);
                columns.ConstantColumn(50);
                columns.ConstantColumn(47);
                columns.ConstantColumn(43);
                columns.ConstantColumn(46);
                columns.ConstantColumn(43);
                columns.ConstantColumn(54);
                columns.ConstantColumn(65);
                columns.ConstantColumn(103);
            });

            ComposeHeader(table);

            foreach (var group in groups)
                ComposeGroup(table, group);
        });
    }

    private static void ComposeHeader(TableDescriptor table)
    {
        table.Cell().Element(HeaderCell).Text("");
        table.Cell().Element(HeaderCell).Text("");

        foreach (var header in new[] { "Auth", "Ccy", "RAG", "Effective\nLimit", "Exposure", "% Util", "Prior\nExposure", "W-o-W\nExposure Change", "3 Month Trend" })
            table.Cell().Element(HeaderCell).AlignCenter().Text(header).FontSize(6.2f).SemiBold();
    }

    private static void ComposeGroup(TableDescriptor table, LimitGroup group)
    {
        table.Cell().RowSpan((uint)group.Rows.Count).Element(SectionCell)
            .RotateLeft().AlignCenter().AlignMiddle().Text(group.Name).FontSize(6.5f).SemiBold();

        for (var index = 0; index < group.Rows.Count; index++)
        {
            var row = group.Rows[index];
            var isLast = index == group.Rows.Count - 1;

            table.Cell().Element(c => MetricCell(c, isLast)).Text(row.Metric).FontSize(6.4f).SemiBold();
            table.Cell().Element(c => TextCell(c, isLast)).Text(row.Auth).FontSize(6.2f).AlignCenter();
            table.Cell().Element(c => TextCell(c, isLast)).Text(row.Currency).FontSize(6.2f).AlignCenter();
            table.Cell().Element(c => RagCell(c, isLast)).Text("\u25CF").FontSize(14).FontColor(Green).AlignCenter();
            table.Cell().Element(c => NumberCell(c, isLast, row.EffectiveLimit)).Text(row.EffectiveLimit).FontSize(6.1f).AlignRight();
            table.Cell().Element(c => NumberCell(c, isLast, row.Exposure)).Text(row.Exposure).FontSize(6.1f).AlignRight();
            table.Cell().Element(c => NumberCell(c, isLast, row.Utilization)).Text(row.Utilization).FontSize(6.1f).AlignCenter();
            table.Cell().Element(c => NumberCell(c, isLast, row.PriorExposure)).Text(row.PriorExposure).FontSize(6.1f).AlignRight();
            table.Cell().Element(c => NumberCell(c, isLast, row.WeekChange)).Text(row.WeekChange).FontSize(6.1f).AlignRight();
            table.Cell().Element(c => TrendCell(c, isLast)).Svg(BuildSparkline(row.Trend)).FitArea();
        }
    }

    private static void ComposeNotes(IContainer container)
    {
        container.Column(column =>
        {
            column.Spacing(1);
            column.Item().Text("Note 1) Include limits which are subject to IB CRO approval authority level and higher").FontSize(6.5f);
            column.Item().Text("2) Include portfolio limits only (ie. no single name corporate credit concentration limits)").FontSize(6.5f);
            column.Item().Text("3) Stress limit is applicable against the worst of Failure, Government Stimulus, Global Trade War and Global Crisis Scenario").FontSize(6.5f);
        });
    }

    private static IContainer HeaderCell(IContainer c)
    {
        return c.Height(29).Background(HeaderFill).Border(0.8f).BorderColor(Line).PaddingHorizontal(3).AlignMiddle();
    }

    private static IContainer SectionCell(IContainer c)
    {
        return c.Background("#F3F1EF").Border(0.8f).BorderColor(Line).Padding(2);
    }

    private static IContainer MetricCell(IContainer c, bool isLast)
    {
        return DataCell(c, isLast).PaddingLeft(4).AlignMiddle();
    }

    private static IContainer TextCell(IContainer c, bool isLast)
    {
        return DataCell(c, isLast).AlignMiddle();
    }

    private static IContainer RagCell(IContainer c, bool isLast)
    {
        return DataCell(c, isLast).AlignMiddle();
    }

    private static IContainer NumberCell(IContainer c, bool isLast, string value)
    {
        var container = DataCell(c, isLast).PaddingHorizontal(4).AlignMiddle();
        return IsRed(value) ? container.DefaultTextStyle(x => x.FontColor(Red)) : container;
    }

    private static IContainer TrendCell(IContainer c, bool isLast)
    {
        return DataCell(c, isLast).PaddingHorizontal(5).PaddingVertical(1);
    }

    private static IContainer DataCell(IContainer c, bool isLast)
    {
        return c.Height(RowHeight)
            .BorderLeft(0.75f).BorderRight(0.75f).BorderColor(Line)
            .BorderBottom(isLast ? 0.8f : 0.45f).BorderColor(isLast ? Line : LightLine);
    }

    private static bool IsRed(string value)
    {
        return value.Contains('(') || value == "0" || value.Equals("NaN", StringComparison.OrdinalIgnoreCase);
    }

    private static string BuildSparkline(double[] values)
    {
        const double width = 100;
        const double height = 18;
        const double center = 9;
        const double gap = 1.2;
        var barWidth = (width - gap * (values.Length - 1)) / values.Length;
        var max = Math.Max(1, values.Max(x => Math.Abs(x)));
        var svg = new StringBuilder();

        svg.Append($"""<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">""");

        for (var index = 0; index < values.Length; index++)
        {
            var value = values[index];
            var barHeight = Math.Abs(value) / max * 8.2;
            var x = index * (barWidth + gap);
            var y = value >= 0 ? center - barHeight : center;

            svg.Append(CultureInfo.InvariantCulture, $"""<rect x="{x:0.##}" y="{y:0.##}" width="{barWidth:0.##}" height="{barHeight:0.##}" fill="{Blue}"/>""");
        }

        svg.Append("</svg>");
        return svg.ToString();
    }

    private static List<LimitGroup> CreateData()
    {
        return
        [
            new("VaR (1 day 95% ETL)",
            [
                Row("Investment Bank", "BoD", "USDm", "(28)", "(7.1)", "25%", "(11.1)", "4.0", Trend(-1, -2, -2, -3, -4, -5, -3, -6, -2, -4, -5, -6, -3, -4, -4, -3)),
                Row("Global Markets", "GCEO", "USDm", "(28)", "(7.1)", "25%", "(11.2)", "4.1", Trend(-2, -3, -3, -4, -5, -6, -8, -4, -9, -6, -7, -8, -5, -6, -6, -4)),
                Row("Global Banking", "GCEO", "USDm", "(5)", "(0.1)", "1%", "(0.5)", "0.4", Trend(-1, -1, 0, 0, -1, -5, 0, -6, -4, 0, 0, -1, 0, -2, -1, -1))
            ]),

            new("Stress - Liquidity\nadjusted & Scenario",
            [
                Row("Investment Bank", "BoD", "USDm", "(2,500)", "(34)", "1%", "(473)", "439", Trend(-6, -3, -7, -4, -4, -5, -3, -3, -4, -2, -3, -3, -5, -4, -3, -2)),
                Row("Global Markets", "GCEO", "USDm", "(500)", "249", "", "94", "155", Trend(-2, 1, 4, -3, -2, 0, 1, 2, 1, 0, -1, -2, -1, 0, 1, 2)),
                Row("Global Banking", "GCEO", "USDm", "(2,500)", "(443)", "18%", "(732)", "289", Trend(-7, -8, -6, -9, -7, -5, -6, -8, -9, -7, -7, -6, -5, -4, -4, -3)),
                Row("GB Real Estate Finance", "GCRO", "USDm", "(200)", "(21)", "10%", "(20.6)", "0", Trend(-5, -5, -4, -6, -6, -7, -8, -6, -7, -8, -9, -6, -5, -4, -3, -2))
            ]),

            new("Equities",
            [
                Row("EQ Delta ex Funds", "IBCRO", "USDm", "800", "452", "57%", "244", "208", Trend(5, 3, 4, 6, 4, 5, 3, 2, 2, 3, 4, 5, 4, 5, 6, 7)),
                Row("EQ Delta Hedge Funds (UBS Funds)", "IBCRO", "USDm", "625", "160", "26%", "156", "4", Trend(3, 4, 5, 6, 5, 4, 4, 3, 3, 4, 4, 5, 5, 6, 7, 8)),
                Row("EQ Delta Hedge Funds (ex UBS Funds)", "IBCRO", "USDm", "500", "202", "40%", "201", "1", Trend(5, 5, 6, 4, 3, 4, 5, 5, 4, 4, 5, 6, 5, 6, 7, 7)),
                Row("EQ Delta (inc CM Delta) - Seed Money", "IBCRO", "USDm", "20", "0", "0%", "0", "0", Trend(1, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1)),
                Row("EQ Vega ex Funds - EM", "IBCRO", "USDm", "17", "8", "45%", "6", "1", Trend(4, -1, -3, -2, -5, -3, 1, 2, 3, 4, 5, -6, 2, 3, 4, 5)),
                Row("TV Change EQ ex Funds Slide - +/-10%", "IBCRO", "USDm", "0", "0", "NaN", "0", "0", Trend(-1, -2, -1, -3, -4, -2, -1, -2, -4, -3, -2, -1, -3, -2, -1, -2)),
                Row("TV Change EQ Hedge Funds Slide - +/-30%", "IBCRO", "USDm", "(50)", "(1)", "3%", "(1)", "0", Trend(-4, -5, -6, -6, -6, -5, -5, -4, -4, -5, -5, -6, -6, -5, -5, -5)),
                Row("Correlation Delta EQEQ Slide - +/-50%", "IBCRO", "USDm", "(30)", "(21)", "69%", "(21)", "(21)", Trend(-2, -3, -5, -4, -5, -6, -5, -5, -6, -7, -8, -7, -6, -5, -4, -4)),
                Row("Margin Loans (Approved Hold)", "GCRO", "USDm", "8,000", "5,057", "63%", "5,037", "20", Trend(6, 6, 7, 7, 7, 6, 6, 7, 8, 7, 8, 8, 7, 7, 8, 8))
            ]),

            new("Credit",
            [
                Row("Credit Delta (excl. SSA/Covered Bonds) - Total", "IBCRO", "USDk", "(1,500)", "(795)", "53%", "(998)", "203", Trend(-7, -5, -6, -8, -7, -5, -6, -4, -3, -4, -5, -6, -5, -4, -3, -2)),
                Row("Credit Delta (excl. SSA/Covered Bonds) Sublig - Total", "IBCRO", "USDk", "(450)", "(55)", "12%", "(116)", "61", Trend(-2, -2, -3, -4, -4, -5, -3, -2, -1, -2, -3, -5, -4, -3, -2, -1)),
                Row("Credit Delta Gross Issuer", "IBCRO", "USDk", "9,000", "6,708", "75%", "6,581", "128", Trend(7, 7, 7, 8, 8, 7, 7, 7, 6, 7, 7, 8, 7, 7, 8, 8))
            ]),

            new("Rates",
            [
                Row("IR Zero Delta", "IBCRO", "USDk", "(2,250)", "(980)", "44%", "(614)", "(366)", Trend(-4, -5, -6, -6, -7, -5, -4, -3, -2, -1, 1, 2, 4, 6, 8, 9))
            ]),

            new("FX",
            [
                Row("FX Vega Time Adjusted Net", "IBCRO", "USDm", "23", "18", "77%", "23", "(5)", Trend(2, 2, 2, 1, 1, 1, 0, 0, -1, -1, -2, -2, -3, -3, -4, -4))
            ])
        ];
    }

    private static LimitRow Row(string metric, string auth, string currency, string effectiveLimit, string exposure, string utilization, string priorExposure, string weekChange, double[] trend)
    {
        return new(metric, auth, currency, effectiveLimit, exposure, utilization, priorExposure, weekChange, trend);
    }

    private static double[] Trend(params double[] values) => values;

    private sealed record LimitGroup(string Name, List<LimitRow> Rows);
    private sealed record LimitRow(string Metric, string Auth, string Currency, string EffectiveLimit, string Exposure, string Utilization, string PriorExposure, string WeekChange, double[] Trend);
}
