using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

QuestPDF.Settings.License = LicenseType.Community;

var outputPath = Path.GetFullPath(args.Length > 0 ? args[0] : "PortfolioOverview-CST.pdf");
var tempPath = Path.Combine(Path.GetTempPath(), $"{Path.GetFileNameWithoutExtension(outputPath)}-temp.pdf");
var keepTempFile = false;

try
{
    CreateDocument(CstReportData.Create()).GeneratePdf(tempPath);
    File.Copy(tempPath, outputPath, true);
    Console.WriteLine($"Created: {outputPath}");
}
catch (IOException ex)
{
    keepTempFile = true;
    Console.Error.WriteLine($"Could not copy PDF to '{outputPath}': {ex.Message}");
    Console.Error.WriteLine($"Generated PDF remains at: {tempPath}");
}
catch (Exception ex)
{
    Console.Error.WriteLine($"PDF generation failed: {ex.Message}");
    Console.Error.WriteLine(ex.StackTrace);
}
finally
{
    if (!keepTempFile && File.Exists(tempPath))
        File.Delete(tempPath);
}

static IDocument CreateDocument(CstReportModel model)
{
    return Document.Create(document =>
    {
        document.Page(page =>
        {
            page.Size(PageSizes.A4.Landscape());
            page.Margin(Layout.PageMargin);
            page.PageColor(Colors.White);
            page.DefaultTextStyle(x => x.FontFamily("Arial").FontSize(Layout.BodyFont).FontColor(CstColors.Text));
            page.Content().Element(c => ComposePage(c, model));
        });

        document.Page(page =>
        {
            page.Size(PageSizes.A4.Landscape());
            page.Margin(28);
            page.PageColor(Colors.White);
            page.DefaultTextStyle(x => x.FontFamily("Arial").FontSize(8).FontColor(CstColors.Text));
            page.Content().Element(EqDeltaVarTrendChart.Compose);
        });

        document.Page(page =>
        {
            page.Size(PageSizes.A4.Landscape());
            page.Margin(24);
            page.PageColor(Colors.White);
            page.DefaultTextStyle(x => x.FontFamily("Arial").FontSize(6.2f).FontColor(CstColors.Text));
            page.Content().Element(MarketRiskLimitFrameworkPage.Compose);
        });
    });
}

static void ComposePage(IContainer container, CstReportModel model)
{
    container.Column(column =>
    {
        column.Spacing(2);
        column.Item().Text("Portfolio Overview").FontSize(20).Bold();
        column.Item().Text("All figures are in USDm unless otherwise stated").FontSize(10).FontColor(CstColors.Subtitle);
        column.Item().Height(34);
        column.Item().Text("Table 1 Combined Stress Testing (CST)").FontSize(10).Bold();
        column.Item().Height(16);
        column.Item().Table(table => ComposeMainTable(table, model));
        column.Item().Height(4);
        column.Item().Element(ComposeNotes);
    });
}

static void ComposeMainTable(TableDescriptor table, CstReportModel model)
{
    table.ColumnsDefinition(columns =>
    {
        columns.ConstantColumn(126);
        columns.ConstantColumn(138);

        foreach (var _ in Enumerable.Range(0, 12))
            columns.ConstantColumn(39);

        columns.ConstantColumn(58);
    });

    table.Header(header =>
    {
        header.Cell().ColumnSpan(2).Element(HeaderBlank);
        header.Cell().ColumnSpan(5).Element(HeaderBand).AlignCenter().Text("Official Feb-26").FontSize(Layout.HeaderFont);
        header.Cell().ColumnSpan(5).Element(HeaderBand).AlignCenter().Text("Estimate\u00B9").FontSize(Layout.HeaderFont);
        header.Cell().ColumnSpan(2).Element(HeaderBand).AlignCenter().Text("Difference vs. Official").FontSize(Layout.HeaderFont);
        header.Cell().Element(HeaderBlank);

        header.Cell().ColumnSpan(2).Element(HeaderBlank);
        foreach (var heading in TableHeadings())
            header.Cell().Element(HeaderCell).AlignCenter().Text(heading).FontSize(Layout.HeaderFont).SemiBold();
    });

    string? previousGroup = null;

    foreach (var row in model.Rows)
    {
        var startsGroup = row.Group != previousGroup;
        previousGroup = row.Group;

        ComposeRowLabel(table, row, startsGroup);
        ComposeValues(table, row.Official, row);
        ComposeValues(table, row.Estimate, row);

        table.Cell().Element(c => NumberCell(c, row, false)).Text(row.Difference).FontSize(Layout.NumberFont).SemiBold(row.IsTotal).AlignRight();
        table.Cell().Element(c => NumberCell(c, row, false)).Text(row.DifferenceNote).FontSize(Layout.NumberFont).SemiBold(row.IsTotal).AlignCenter();
        table.Cell().Element(c => StandardCell(c, row, false)).Text(row.UpdateFrequency).FontSize(5).AlignCenter();
    }

    foreach (var footer in model.FooterRows)
    {
        table.Cell().ColumnSpan(2).Element(FooterCell).Text(footer.Label).FontSize(5.7f).SemiBold();
        foreach (var value in footer.Values)
            table.Cell().Element(FooterCell).Text(value).FontSize(5.5f).Bold().AlignRight();
    }

    ComposeRagRows(table);
}

static void ComposeRowLabel(TableDescriptor table, CstRow row, bool startsGroup)
{
    if (row.IsTotal && string.IsNullOrWhiteSpace(row.Label))
    {
        table.Cell().ColumnSpan(2).Element(c => TotalLabelCell(c, row))
            .Text(row.Group).FontSize(Layout.BodyFont).Bold();
        return;
    }

    table.Cell().Element(c => GroupCell(c, row, startsGroup))
        .Text(startsGroup ? row.Group : "").FontSize(Layout.BodyFont).Bold();
    table.Cell().Element(c => StandardCell(c, row, row.IsTotal))
        .Text(row.Label).FontSize(Layout.BodyFont).SemiBold(row.IsTotal);
}

static void ComposeValues(TableDescriptor table, string[] values, CstRow row)
{
    for (var index = 0; index < values.Length; index++)
    {
        table.Cell().Element(c => NumberCell(c, row, groupTotal: index == 4))
            .Text(values[index]).FontSize(Layout.NumberFont).SemiBold(row.IsTotal).AlignRight();
    }
}

static void ComposeRagRows(TableDescriptor table)
{
    table.Cell().ColumnSpan(2).Element(RagCell).Text("% of Util").FontSize(5.5f).Bold().FontColor(CstColors.Red);
    foreach (var percent in new[] { "81%", "38%", "77%", "91%", "85%", "94%", "65%", "76%", "93%", "91%", "", "", "" })
        table.Cell().Element(RagCell).Text(percent).FontSize(5.5f).Bold().FontColor(CstColors.Red).AlignCenter();

    table.Cell().ColumnSpan(2).Element(RagCell).Text("RAG").FontSize(5.5f).Bold();
    foreach (var color in RagColors())
        table.Cell().Element(RagCell).AlignCenter().Text(string.IsNullOrEmpty(color) ? "" : "\u25CF").FontSize(8).FontColor(string.IsNullOrEmpty(color) ? CstColors.Text : color);

    table.Cell().ColumnSpan(2).Element(BottomCell).Text("Buffer to Trigger").FontSize(5.5f).Bold();
    foreach (var buffer in new[] { "926", "249", "302", "674", "2,150", "276", "142", "310", "585", "1,312", "", "", "" })
        table.Cell().Element(BottomCell).Text(buffer).FontSize(5.5f).AlignRight();
}

static void ComposeNotes(IContainer container)
{
    container.Column(column =>
    {
        column.Spacing(2);
        column.Item().Text("Notes").FontSize(5.2f).Underline();
        column.Item().Text("1) Starting from 16 Jan 2026, Global Trade War is a new binding scenario to replace Global Crisis. Estimate table shows estimates plus intramonth updates. All other items are rolled over from the official monthly CST report.").FontSize(5.1f);
        column.Item().Text("2) Operational Risk estimate based on a revised allocation methodology, similar to the RWA approach.").FontSize(5.1f);
    });
}

static IContainer HeaderBlank(IContainer c) => c.MinHeight(10).BorderBottom(0.5f).BorderColor(CstColors.Line);
static IContainer HeaderBand(IContainer c) => HeaderBlank(c).AlignMiddle();
static IContainer HeaderCell(IContainer c) => HeaderBlank(c).PaddingHorizontal(2).AlignMiddle();
static IContainer FooterCell(IContainer c) => c.MinHeight(10).BorderBottom(0.35f).BorderColor(CstColors.LineLight).PaddingHorizontal(2).AlignMiddle();
static IContainer RagCell(IContainer c) => c.MinHeight(10).PaddingHorizontal(2).AlignMiddle();
static IContainer BottomCell(IContainer c) => c.MinHeight(9).BorderTop(0.7f).BorderBottom(0.7f).BorderColor(CstColors.LineDark).PaddingHorizontal(2).AlignMiddle();

static IContainer GroupCell(IContainer c, CstRow row, bool startsGroup)
{
    return RowBase(c, row, row.GroupTone ?? Colors.White).PaddingLeft(1.5f).PaddingTop(startsGroup ? 1.2f : 0);
}

static IContainer StandardCell(IContainer c, CstRow row, bool highlighted)
{
    return RowBase(c, row, highlighted ? CstColors.TotalFill : Colors.White).PaddingHorizontal(2).AlignMiddle();
}

static IContainer TotalLabelCell(IContainer c, CstRow row)
{
    return RowBase(c, row, row.GroupTone ?? CstColors.TotalFill).PaddingHorizontal(2).AlignMiddle();
}

static IContainer NumberCell(IContainer c, CstRow row, bool groupTotal)
{
    var fill = row.IsTotal ? CstColors.TotalFill : groupTotal ? CstColors.GroupTotalFill : Colors.White;
    return RowBase(c, row, fill).PaddingHorizontal(2).AlignMiddle();
}

static IContainer RowBase(IContainer c, CstRow row, string fill)
{
    var borderWidth = row.IsSectionDivider ? 0.7f : 0.2f;
    var borderColor = row.IsSectionDivider ? CstColors.LineDark : CstColors.LineLight;

    return c.MinHeight(8).Background(fill).BorderBottom(borderWidth).BorderColor(borderColor);
}

static string[] TableHeadings() =>
[
    "IB", "Group\nTreasury", "NCL", "Others", "Group Total",
    "IB", "Group\nTreasury", "NCL", "Others", "Group Total",
    "Group Total", "", "Update frequency"
];

static string[] RagColors() =>
[
    "#D7A22A", "#06744A", "#06744A", "#B0452E", "#D7A22A",
    "#D7A22A", "#06744A", "#06744A", "#D7A22A", "#D7A22A",
    "", "", ""
];

static class Layout
{
    public const float PageMargin = 12;
    public const float BodyFont = 5.2f;
    public const float HeaderFont = 5.3f;
    public const float NumberFont = 5.15f;
}

static class CstColors
{
    public const string Text = "#242424";
    public const string Subtitle = "#444444";
    public const string Line = "#9A9A9A";
    public const string LineDark = "#666666";
    public const string LineLight = "#D9D9D9";
    public const string GroupTotalFill = "#E3E3E3";
    public const string TotalFill = "#F2F2F2";
    public const string Red = "#B11B1B";
    public const string SectionTone = "#F5F5F5";
}

static class TextExtensions
{
    public static TextBlockDescriptor SemiBold(this TextBlockDescriptor text, bool enabled) => enabled ? text.SemiBold() : text;
}

record CstReportModel(List<CstRow> Rows, List<FooterRow> FooterRows);
record CstRow(string Group, string Label, string[] Official, string[] Estimate, string Difference, string DifferenceNote, string UpdateFrequency, bool IsSectionDivider = false, bool IsTotal = false, string? GroupTone = null);
record FooterRow(string Label, string[] Values);

static class CstReportData
{
    private static string[] V(params string[] values) => values;

    public static CstReportModel Create()
    {
        var rows = new List<CstRow>
        {
            new("Credit & Country risks", "Mortgages", V("", "", "", "308", "308"), V("", "", "", "312", "312"), "4", "", "Weekly (02/04/25)", true),
            new("Credit & Country risks", "Lombard", V("99", "", "", "317", "416"), V("102", "", "", "315", "417"), "1", "", "Weekly (02/04/25)"),
            new("Credit & Country risks", "Counterparty credit risk", V("421", "186", "12", "1", "621"), V("430", "190", "15", "2", "637"), "16", "", "GRR"),
            new("Credit & Country risks", "Corporates", V("768", "46", "19", "722", "1,555"), V("780", "50", "21", "730", "1,581"), "26", "", "GRR"),
            new("Credit & Country risks", "Loan Underwriting", V("636", "", "", "636", "636"), V("639", "3", "5", "2", "649"), "13", "", "Weekly (03/04/25)"),
            new("Credit & Country risks", "Issuer risk", V("503", "111", "(5)", "0", "609"), V("644", "177", "(5)", "0", "816"), "207", "", "Weekly (31/03/25)"),
            new("Credit & Country risks", "IFRS9 ECL", V("(9)", "0", "0", "881", "872"), V("(8)", "1", "0", "885", "878"), "6", "", "GRR"),
            new("Credit & Country risks", "CDF", V("156", "5", "98", "640", "900"), V("160", "6", "100", "645", "911"), "11", "", "GRR"),
            new("Credit & Country risks", "Other credit risk", V("6", "", "47", "460", "513"), V("7", "", "50", "465", "522"), "9", "", "GRR"),
            new("Credit & Country risks", "   o/w ARS / APS", V("", "", "47", "", "47"), V("", "", "48", "", "48"), "1", "", "GRR"),
            new("Market & Investment risks", "Traded Market risk", V("(296)", "(322)", "102", "30", "(485)"), V("(91)", "(270)", "94", "20", "(246)"), "239", "", "Weekly (05/04/25)", true),
            new("Market & Investment risks", "NCL Market risk", V("15", "5", "2", "8", "30"), V("18", "6", "3", "10", "37"), "7", "", "GRR"),
            new("Market & Investment risks", "Equity investments", V("196", "1", "43", "1,182", "1,422"), V("200", "2", "45", "1,190", "1,437"), "15", "", "GRR"),
            new("Market & Investment risks", "High-quality liquid assets", V("", "101", "", "", "101"), V("", "90", "", "", "90"), "(11)", "", "Weekly (03/04/25)"),
            new("Market & Investment risks", "Valuation Adjustments", V("518", "14", "92", "", "624"), V("520", "16", "95", "", "631"), "7", "", "GRR"),
            new("Operational Risk", "", V("615", "", "579", "2,045", "3,240"), V("620", "", "585", "2,060", "3,265"), "25", "", "GRR\u00B2", true),
            new("Treasury risk", "Funding & liquidity risk", V("262", "8", "11", "638", "919"), V("265", "9", "12", "645", "931"), "12", "", "GRR", true),
            new("Aggregate risk exposure P&L impact - Trigger utilization", "", V("3,874", "151", "998", "7,226", "12,250"), V("4,224", "258", "990", "7,215", "12,688"), "438", "", "GRR", true, true, CstColors.SectionTone),
            new("Treasury risk", "Structural FX", V("", "(979)", "", "", "(979)"), V("", "(980)", "", "", "(980)"), "(1)", "", "Weekly (03/04/25)", true),
            new("Market & Investment risks", "Market Risk (delta CET1 vs P&L)", V("", "(491)", "", "", "(491)"), V("", "(462)", "", "", "(462)"), "29", "", "GRR"),
            new("Market & Investment risks", "PVA (delta CET1 vs P&L)", V("", "252", "", "", "252"), V("", "250", "", "", "250"), "(2)", "", "GRR"),
            new("Aggregate risk exposure (excl. pension risk)", "", V("3,874", "(1,067)", "998", "7,226", "11,031"), V("4,224", "(931)", "990", "7,215", "11,499"), "468", "", "", true, true, CstColors.SectionTone),
        };

        var footerRows = new List<FooterRow>
        {
            new("Current Trigger released", V("4,800", "400", "1,300", "7,900", "14,400", "4,500", "400", "1,300", "7,800", "14,000", "", "", "")),
        };

        return new CstReportModel(rows, footerRows);
    }
}
