# PBIR Versioning for Azure Blob Storage

A complete .NET 8 sample for managing a Power BI enhanced PBIR folder structure in an Azure Storage account where **Hierarchical Namespace is disabled** and **Blob Versioning is enabled**.

## Supported requirements

1. Add a new PBIR report folder and create a logical report version.
2. Update the complete PBIR folder, creating native Azure versions for every uploaded file while preserving prior versions.
3. Restore an older report version and make the restored copy current.
4. Delete a logical version, with an optional safe purge of unreferenced native blob versions.
5. List all versions with creation date, creator, operation, description, file count, size, parent version, and current status.
6. Download a complete report version, ZIP, or individual file by version.

## Why the manifest is required

Azure Blob Versioning versions each blob independently. A PBIR report is a coordinated folder containing many JSON and resource files. The library writes one immutable JSON manifest per logical report version. Each manifest records the native Azure version ID for every PBIR file, plus:

- Logical version ID
- UTC creation timestamp
- Creator display name
- Optional stable user ID
- Operation: Created, Updated, or Restored
- Parent version
- Source version for a restore
- Description and correlation ID
- File count, size, content type, ETag, and SHA-256

The manifest is the report-level version. The native version IDs are the file-level history.

## Storage layout

```text
powerbi/reports/{reportId}/content/{complete PBIR structure}
.system/pbir-versioning/{reportId}/current.json
.system/pbir-versioning/{reportId}/versions/{logicalVersionId}.json
```

`current.json` is updated with an ETag condition so concurrent writers cannot silently replace one another. The class also serializes operations inside one process. In a multi-instance service, add a distributed lock or Azure Blob lease around write operations.

## Prerequisites

- .NET 8 SDK
- General-purpose v2 Azure Storage account
- Hierarchical Namespace disabled
- Blob Versioning enabled
- Blob soft delete strongly recommended
- For passwordless authentication, assign the application or managed identity an appropriate role such as **Storage Blob Data Contributor**

## Packages

- `Azure.Storage.Blobs` 12.29.1
- `Azure.Identity` 1.21.0 in the sample console app

## Build

```powershell
dotnet restore
dotnet build PbirVersioningSample.sln -c Release
```

## Authentication

### Connection string

PowerShell:

```powershell
$env:AZURE_STORAGE_CONNECTION_STRING = "<connection string>"
$env:AZURE_STORAGE_CONTAINER = "powerbi"
```

### DefaultAzureCredential

```powershell
$env:AZURE_STORAGE_ACCOUNT_URL = "https://<account>.blob.core.windows.net"
$env:AZURE_STORAGE_CONTAINER = "powerbi"
az login
```

For a deployed service, `DefaultAzureCredential` can use its managed identity.

Optional audit and display settings:

```powershell
$env:PBIR_USER_ID = "<Entra object ID or application user ID>"
$env:PBIR_DISPLAY_TIME_ZONE = "Eastern Standard Time"
```

On Linux, use `America/New_York` instead of `Eastern Standard Time` if needed.

## Run the included sample

### Add a report

```powershell
dotnet run --project src/PbirVersioning.Sample -- `
  add mrv-panel sample-data/Demo.Report "Julio Diaz" "Initial PBIR import"
```

### Update the report

```powershell
dotnet run --project src/PbirVersioning.Sample -- `
  update mrv-panel C:\PBIP\MRVPanel.Report "Julio Diaz" "Updated filters"
```

Every save records one authoritative `CreatedUtc` timestamp and the user information supplied through `PbirVersionContext`.

### List versions and creation dates

```powershell
dotnet run --project src/PbirVersioning.Sample -- list mrv-panel
```

Example output:

```text
  Version                            Created                  Created By           Operation  Files Description
-------------------------------------------------------------------------------------------------------------------
* 20260728T221503421Z_7e4d82a1       2026-07-28 06:15:03 PM  Julio Diaz           Updated       47 Updated filters
  20260727T194212117Z_0b39ca82       2026-07-27 03:42:12 PM  Julio Diaz           Created       45 Initial PBIR import
```

The manifest stores UTC. The sample converts it to the configured display timezone.

### Download current report

```powershell
dotnet run --project src/PbirVersioning.Sample -- `
  download mrv-panel current C:\Downloads\MRVPanel
```

### Download a historical report as ZIP

```powershell
dotnet run --project src/PbirVersioning.Sample -- `
  download-zip mrv-panel 20260727T194212117Z_0b39ca82 C:\Downloads\MRVPanel-old.zip
```

### Download one file from a version

```powershell
dotnet run --project src/PbirVersioning.Sample -- `
  download-file mrv-panel 20260727T194212117Z_0b39ca82 `
  definition/pages/Page1/page.json C:\Downloads\page.json
```

### Restore a version

```powershell
dotnet run --project src/PbirVersioning.Sample -- `
  restore mrv-panel 20260727T194212117Z_0b39ca82 "Julio Diaz" "Rollback after validation"
```

Restore does not move the current pointer directly to the old manifest. It re-uploads the selected historical file versions, creating a new current logical version with `Operation = Restored`. This preserves a complete audit trail.

### Delete a historical version

Delete only the logical manifest:

```powershell
dotnet run --project src/PbirVersioning.Sample -- `
  delete mrv-panel 20260727T194212117Z_0b39ca82
```

Delete the manifest and unreferenced native file versions:

```powershell
dotnet run --project src/PbirVersioning.Sample -- `
  delete mrv-panel 20260727T194212117Z_0b39ca82 --purge-native
```

The current version cannot be deleted. Restore another version first. Keep `--purge-native` off unless permanent physical deletion is required; Blob soft delete provides an additional safety layer.

## Library usage

```csharp
BlobContainerClient container = new(
    new Uri("https://account.blob.core.windows.net/powerbi"),
    new DefaultAzureCredential());

await container.CreateIfNotExistsAsync();

IPbirReportStore store = new PbirReportStore(container);

PbirReportVersionManifest version = await store.AddReportAsync(
    reportId: "mrv-panel",
    localPbirFolder: @"C:\PBIP\MRVPanel.Report",
    context: new PbirVersionContext
    {
        UserName = "Julio Diaz",
        UserId = "entra-object-id",
        Description = "Initial import",
        CorrelationId = Guid.NewGuid().ToString("N")
    });

Console.WriteLine($"{version.VersionId} created {version.CreatedUtc:O} by {version.CreatedBy}");
```

## PBIR-specific behavior

The scanner:

- Preserves the complete relative folder structure.
- Validates `.json`, `.pbir`, and `.pbip` files as JSON.
- Requires a `.pbir` file or enhanced `definition` folder by default.
- Excludes `.pbi/cache.abf`, `.pbi/localSettings.json`, `.git`, `bin`, and `obj`.
- Rejects symbolic links and unsafe download paths.
- Stores all dates in UTC and converts only for display.

The implementation uploads every included PBIR file on each logical save. PBIR definitions are mostly small JSON files, and this choice guarantees that each logical version has a complete, independent set of native blob version IDs. It also simplifies restoration and auditing.

## Production considerations

- Use managed identity instead of connection strings.
- Add a distributed Blob lease if several service instances may write the same report.
- Add PBIR JSON Schema validation if strict schema enforcement is needed; the included validator confirms valid JSON but does not fetch external schemas.
- Add retry, telemetry, and a cleanup process for manifests left behind after a current-pointer concurrency conflict.
- Configure lifecycle policies carefully so Azure does not remove native versions still referenced by manifests.
- Keep blob soft delete enabled, especially when supporting permanent version deletion.
