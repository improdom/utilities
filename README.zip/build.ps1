$ErrorActionPreference = "Stop"
dotnet restore .\PbirVersioningSample.sln
dotnet build .\PbirVersioningSample.sln -c Release --no-restore
