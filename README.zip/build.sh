#!/usr/bin/env bash
set -euo pipefail
dotnet restore ./PbirVersioningSample.sln
dotnet build ./PbirVersioningSample.sln -c Release --no-restore
