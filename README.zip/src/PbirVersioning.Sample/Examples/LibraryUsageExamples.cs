using Azure.Identity;
using Azure.Storage.Blobs;
using PbirVersioning.Models;
using PbirVersioning.Services;

namespace PbirVersioning.Sample.Examples;

/// <summary>
/// Direct library examples for the six required PBIR version-management operations.
/// These methods are illustrative and are not invoked by the command-line sample.
/// </summary>
internal static class LibraryUsageExamples
{
    /// <summary>
    /// Recreates the complete PBIR report folder structure for a specific logical version.
    /// The version ID can be obtained from <see cref="IPbirReportStore.ListVersionsAsync"/>.
    /// </summary>
    public static async Task DownloadReportFolderForSpecificVersionAsync(
        string accountName,
        string containerName,
        string reportId,
        string versionId,
        string downloadFolder,
        CancellationToken cancellationToken = default)
    {
        BlobContainerClient container = new(
            new Uri($"https://{accountName}.blob.core.windows.net/{containerName}"),
            new DefaultAzureCredential());

        IPbirReportStore store = new PbirReportStore(container);

        await store.DownloadVersionAsync(
            reportId,
            versionId,
            downloadFolder,
            overwrite: true,
            cancellationToken: cancellationToken);
    }

    public static async Task RunAllAsync(
        string accountName,
        string containerName,
        string reportId,
        string localPbirFolder,
        string downloadFolder,
        CancellationToken cancellationToken = default)
    {
        BlobContainerClient container = new(
            new Uri($"https://{accountName}.blob.core.windows.net/{containerName}"),
            new DefaultAzureCredential());

        await container.CreateIfNotExistsAsync(cancellationToken: cancellationToken);
        IPbirReportStore store = new PbirReportStore(container);

        PbirVersionContext initialContext = new()
        {
            UserName = "Julio Diaz",
            UserId = "optional-entra-object-id",
            Description = "Initial PBIR import",
            CorrelationId = Guid.NewGuid().ToString("N")
        };

        // 1. Add a new PBIR folder structure and create its first logical version.
        PbirReportVersionManifest created = await store.AddReportAsync(
            reportId,
            localPbirFolder,
            initialContext,
            cancellationToken);

        // 2. Update the complete report. Azure creates native versions for uploaded files.
        PbirReportVersionManifest updated = await store.UpdateReportAsync(
            reportId,
            localPbirFolder,
            initialContext with
            {
                Description = "Updated PBIR filters and visuals",
                CorrelationId = Guid.NewGuid().ToString("N")
            },
            cancellationToken);

        // 5. List logical versions, including date, creator, operation, and current status.
        IReadOnlyList<PbirReportVersionSummary> versions =
            await store.ListVersionsAsync(reportId, cancellationToken);

        foreach (PbirReportVersionSummary version in versions)
        {
            Console.WriteLine(
                $"{version.VersionId} | {version.CreatedUtc:O} | " +
                $"{version.CreatedBy} | {version.Operation} | " +
                $"Current={version.IsCurrent}");
        }

        // 6. Recreate the complete PBIR folder structure from the initial version.
        await store.DownloadVersionAsync(
            reportId,
            created.VersionId,
            downloadFolder,
            overwrite: true,
            cancellationToken: cancellationToken);

        // 3. Restore the initial version. The restore itself becomes a new current version.
        PbirReportVersionManifest restored = await store.RestoreVersionAsync(
            reportId,
            created.VersionId,
            initialContext with
            {
                Description = $"Restored from {created.VersionId}",
                CorrelationId = Guid.NewGuid().ToString("N")
            },
            cancellationToken);

        Console.WriteLine(
            $"Restored version {restored.VersionId} was created " +
            $"at {restored.CreatedUtc:O} by {restored.CreatedBy}.");

        // 4. Delete the now-historical updated logical version.
        // Keep purgeNativeBlobVersions false for the safer default.
        await store.DeleteVersionAsync(
            reportId,
            updated.VersionId,
            purgeNativeBlobVersions: false,
            cancellationToken: cancellationToken);
    }
}
