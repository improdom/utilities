using Azure.Identity;
using Azure.Storage.Blobs;
using PbirVersioning.Models;
using PbirVersioning.Options;
using PbirVersioning.Services;

return await PbirCli.RunAsync(args);

internal static class PbirCli
{
    public static async Task<int> RunAsync(string[] args)
    {
        if (args.Length == 0 || IsHelp(args[0]))
        {
            PrintHelp();
            return 0;
        }

        try
        {
            BlobContainerClient container = CreateContainerClient();
            await container.CreateIfNotExistsAsync();

            IPbirReportStore store = new PbirReportStore(
                container,
                new PbirReportStoreOptions
                {
                    ReportsRoot = Environment.GetEnvironmentVariable("PBIR_REPORTS_ROOT")
                                  ?? "powerbi/reports",
                    SystemRoot = Environment.GetEnvironmentVariable("PBIR_SYSTEM_ROOT")
                                 ?? ".system/pbir-versioning",
                    ValidateJsonFiles = true,
                    RequirePbirDefinition = true
                });

            string command = args[0].ToLowerInvariant();
            switch (command)
            {
                case "add":
                    RequireArguments(args, 4, "add <reportId> <folder> <userName> [description]");
                    PrintManifest(await store.AddReportAsync(
                        args[1],
                        args[2],
                        CreateContext(args, userNameIndex: 3, descriptionIndex: 4)));
                    break;

                case "update":
                    RequireArguments(args, 4, "update <reportId> <folder> <userName> [description]");
                    PrintManifest(await store.UpdateReportAsync(
                        args[1],
                        args[2],
                        CreateContext(args, userNameIndex: 3, descriptionIndex: 4)));
                    break;

                case "restore":
                    RequireArguments(args, 4, "restore <reportId> <versionId> <userName> [description]");
                    PrintManifest(await store.RestoreVersionAsync(
                        args[1],
                        args[2],
                        CreateContext(args, userNameIndex: 3, descriptionIndex: 4)));
                    break;

                case "list":
                    RequireArguments(args, 2, "list <reportId>");
                    PrintVersions(await store.ListVersionsAsync(args[1]));
                    break;

                case "current":
                    RequireArguments(args, 2, "current <reportId>");
                    PbirCurrentVersion? current = await store.GetCurrentVersionAsync(args[1]);
                    if (current is null)
                    {
                        Console.WriteLine("Report not found.");
                        return 2;
                    }
                    PrintManifest(current.Manifest);
                    break;

                case "download":
                    RequireArguments(args, 4, "download <reportId> <versionId|current> <destinationFolder>");
                    await store.DownloadVersionAsync(args[1], args[2], args[3], overwrite: true);
                    Console.WriteLine($"Downloaded report '{args[1]}' version '{args[2]}' to '{args[3]}'.");
                    break;

                case "download-zip":
                    RequireArguments(args, 4, "download-zip <reportId> <versionId|current> <destinationZip>");
                    await using (FileStream zip = File.Create(args[3]))
                    {
                        await store.DownloadVersionAsZipAsync(args[1], args[2], zip);
                    }
                    Console.WriteLine($"Downloaded report '{args[1]}' version '{args[2]}' to '{args[3]}'.");
                    break;

                case "download-file":
                    RequireArguments(args, 5,
                        "download-file <reportId> <versionId|current> <relativePath> <destinationFile>");
                    string? directory = Path.GetDirectoryName(Path.GetFullPath(args[4]));
                    if (!string.IsNullOrWhiteSpace(directory))
                    {
                        Directory.CreateDirectory(directory);
                    }
                    await using (FileStream output = File.Create(args[4]))
                    {
                        await store.DownloadFileVersionAsync(args[1], args[2], args[3], output);
                    }
                    Console.WriteLine($"Downloaded '{args[3]}' from version '{args[2]}'.");
                    break;

                case "delete":
                    RequireArguments(args, 3, "delete <reportId> <versionId> [--purge-native]");
                    bool purge = args.Skip(3).Any(value =>
                        value.Equals("--purge-native", StringComparison.OrdinalIgnoreCase));
                    DeleteVersionResult deleteResult = await store.DeleteVersionAsync(
                        args[1],
                        args[2],
                        purge);
                    Console.WriteLine(
                        $"Deleted version {deleteResult.VersionId}. " +
                        $"Manifest deleted: {deleteResult.ManifestDeleted}; " +
                        $"native versions deleted: {deleteResult.NativeVersionsDeleted}.");
                    break;

                default:
                    Console.Error.WriteLine($"Unknown command '{args[0]}'.");
                    PrintHelp();
                    return 2;
            }

            return 0;
        }
        catch (Exception exception)
        {
            Console.Error.WriteLine($"ERROR: {exception.Message}");
            return 1;
        }
    }

    private static BlobContainerClient CreateContainerClient()
    {
        string containerName = Environment.GetEnvironmentVariable("AZURE_STORAGE_CONTAINER")
                               ?? "powerbi";

        string? connectionString = Environment.GetEnvironmentVariable("AZURE_STORAGE_CONNECTION_STRING");
        if (!string.IsNullOrWhiteSpace(connectionString))
        {
            return new BlobContainerClient(connectionString, containerName);
        }

        string accountUrl = Environment.GetEnvironmentVariable("AZURE_STORAGE_ACCOUNT_URL")
                            ?? throw new InvalidOperationException(
                                "Set AZURE_STORAGE_CONNECTION_STRING or AZURE_STORAGE_ACCOUNT_URL.");

        return new BlobContainerClient(
            new Uri($"{accountUrl.TrimEnd('/')}/{containerName}"),
            new DefaultAzureCredential());
    }

    private static PbirVersionContext CreateContext(
        string[] args,
        int userNameIndex,
        int descriptionIndex) => new()
    {
        UserName = args[userNameIndex],
        UserId = Environment.GetEnvironmentVariable("PBIR_USER_ID"),
        Description = args.Length > descriptionIndex
            ? string.Join(' ', args.Skip(descriptionIndex))
            : null,
        CorrelationId = Guid.NewGuid().ToString("N")
    };

    private static void PrintVersions(IReadOnlyList<PbirReportVersionSummary> versions)
    {
        if (versions.Count == 0)
        {
            Console.WriteLine("No versions found.");
            return;
        }

        TimeZoneInfo displayTimeZone = ResolveDisplayTimeZone();
        Console.WriteLine(
            $"{new string(' ', 2)}{"Version",-34} {"Created",-24} {"Created By",-20} {"Operation",-10} {"Files",5} Description");
        Console.WriteLine(new string('-', 115));

        foreach (PbirReportVersionSummary version in versions)
        {
            DateTimeOffset displayDate = TimeZoneInfo.ConvertTime(version.CreatedUtc, displayTimeZone);
            string marker = version.IsCurrent ? "* " : "  ";
            Console.WriteLine(
                $"{marker}{version.VersionId,-34} " +
                $"{displayDate,-24:yyyy-MM-dd hh:mm:ss tt zzz} " +
                $"{Truncate(version.CreatedBy, 20),-20} " +
                $"{version.Operation,-10} " +
                $"{version.FileCount,5} " +
                $"{version.Description}");
        }

        Console.WriteLine($"\n* Current version. Display timezone: {displayTimeZone.DisplayName}");
    }

    private static void PrintManifest(PbirReportVersionManifest manifest)
    {
        TimeZoneInfo timeZone = ResolveDisplayTimeZone();
        DateTimeOffset localDate = TimeZoneInfo.ConvertTime(manifest.CreatedUtc, timeZone);

        Console.WriteLine($"Report:       {manifest.ReportId}");
        Console.WriteLine($"Version:      {manifest.VersionId}");
        Console.WriteLine($"Created UTC:  {manifest.CreatedUtc:O}");
        Console.WriteLine($"Created:      {localDate:yyyy-MM-dd hh:mm:ss tt zzz}");
        Console.WriteLine($"Created by:   {manifest.CreatedBy}");
        Console.WriteLine($"User ID:      {manifest.CreatedByUserId}");
        Console.WriteLine($"Operation:    {manifest.Operation}");
        Console.WriteLine($"Parent:       {manifest.ParentVersionId}");
        Console.WriteLine($"Restored from:{manifest.RestoredFromVersionId}");
        Console.WriteLine($"Files:        {manifest.FileCount}");
        Console.WriteLine($"Total bytes:  {manifest.TotalSizeBytes:N0}");
        Console.WriteLine($"Description:  {manifest.Description}");
    }

    private static TimeZoneInfo ResolveDisplayTimeZone()
    {
        string? requested = Environment.GetEnvironmentVariable("PBIR_DISPLAY_TIME_ZONE");
        if (!string.IsNullOrWhiteSpace(requested))
        {
            return TimeZoneInfo.FindSystemTimeZoneById(requested);
        }

        foreach (string id in new[] { "Eastern Standard Time", "America/New_York" })
        {
            try
            {
                return TimeZoneInfo.FindSystemTimeZoneById(id);
            }
            catch (TimeZoneNotFoundException)
            {
                // Try the next cross-platform ID.
            }
        }

        return TimeZoneInfo.Local;
    }

    private static string Truncate(string value, int maxLength) =>
        value.Length <= maxLength ? value : value[..(maxLength - 1)] + "…";

    private static bool IsHelp(string value) =>
        value is "-h" or "--help" or "help";

    private static void RequireArguments(string[] args, int minimum, string usage)
    {
        if (args.Length < minimum)
        {
            throw new ArgumentException($"Usage: {usage}");
        }
    }

    private static void PrintHelp()
    {
        Console.WriteLine("""
PBIR Versioning sample

Environment:
  AZURE_STORAGE_CONNECTION_STRING   Connection-string authentication, or
  AZURE_STORAGE_ACCOUNT_URL         Example: https://account.blob.core.windows.net
  AZURE_STORAGE_CONTAINER           Default: powerbi
  PBIR_USER_ID                      Optional stable Entra/application user ID
  PBIR_DISPLAY_TIME_ZONE            Optional Windows or IANA timezone ID

Commands:
  add <reportId> <folder> <userName> [description]
  update <reportId> <folder> <userName> [description]
  restore <reportId> <versionId> <userName> [description]
  list <reportId>
  current <reportId>
  download <reportId> <versionId|current> <destinationFolder>
  download-zip <reportId> <versionId|current> <destinationZip>
  download-file <reportId> <versionId|current> <relativePath> <destinationFile>
  delete <reportId> <versionId> [--purge-native]

Examples:
  dotnet run --project src/PbirVersioning.Sample -- add mrv-panel sample-data/Demo.Report "Julio Diaz" "Initial import"
  dotnet run --project src/PbirVersioning.Sample -- list mrv-panel
  dotnet run --project src/PbirVersioning.Sample -- download mrv-panel current ./downloads/mrv-panel
""");
    }
}
