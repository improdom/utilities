namespace PbirVersioning.Models;

public sealed record DeleteVersionResult
{
    public required string ReportId { get; init; }
    public required string VersionId { get; init; }
    public required bool ManifestDeleted { get; init; }
    public required bool NativeVersionsPurged { get; init; }
    public required int NativeVersionsDeleted { get; init; }
}
