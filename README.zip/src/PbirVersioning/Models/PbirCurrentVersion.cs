namespace PbirVersioning.Models;

public sealed record PbirCurrentVersion
{
    public required PbirCurrentVersionPointer Pointer { get; init; }
    public required PbirReportVersionManifest Manifest { get; init; }
}
