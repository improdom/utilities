namespace PbirVersioning.Models;

public sealed record PbirCurrentVersionPointer
{
    public required string ReportId { get; init; }
    public required string VersionId { get; init; }
    public required DateTimeOffset UpdatedUtc { get; init; }
    public required string UpdatedBy { get; init; }
    public string? UpdatedByUserId { get; init; }
}
