namespace PbirVersioning.Models;

public sealed record PbirReportVersionManifest
{
    public const int CurrentSchemaVersion = 1;

    public int SchemaVersion { get; init; } = CurrentSchemaVersion;
    public required string ReportId { get; init; }
    public required string VersionId { get; init; }
    public required DateTimeOffset CreatedUtc { get; init; }
    public required string CreatedBy { get; init; }
    public string? CreatedByUserId { get; init; }
    public required PbirVersionOperation Operation { get; init; }
    public string? ParentVersionId { get; init; }
    public string? RestoredFromVersionId { get; init; }
    public string? Description { get; init; }
    public string? CorrelationId { get; init; }
    public required IReadOnlyList<PbirVersionFile> Files { get; init; }

    public int FileCount => Files.Count;
    public long TotalSizeBytes => Files.Sum(file => file.Size);
}
