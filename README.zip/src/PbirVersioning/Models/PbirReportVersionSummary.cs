namespace PbirVersioning.Models;

public sealed record PbirReportVersionSummary
{
    public required string ReportId { get; init; }
    public required string VersionId { get; init; }
    public required DateTimeOffset CreatedUtc { get; init; }
    public required string CreatedBy { get; init; }
    public string? CreatedByUserId { get; init; }
    public required PbirVersionOperation Operation { get; init; }
    public string? ParentVersionId { get; init; }
    public string? RestoredFromVersionId { get; init; }
    public string? Description { get; init; }
    public string? CorrelationId { get; init; }
    public required int FileCount { get; init; }
    public required long TotalSizeBytes { get; init; }
    public required bool IsCurrent { get; init; }
}
