namespace PbirVersioning.Models;

public sealed record PbirVersionContext
{
    public required string UserName { get; init; }
    public string? UserId { get; init; }
    public string? Description { get; init; }
    public string? CorrelationId { get; init; }
}
