namespace PbirVersioning.Models;

public sealed record PbirVersionFile
{
    public required string RelativePath { get; init; }
    public required string BlobPath { get; init; }
    public required string NativeBlobVersionId { get; init; }
    public required string ETag { get; init; }
    public required long Size { get; init; }
    public required string ContentType { get; init; }
    public required string Sha256 { get; init; }
}
