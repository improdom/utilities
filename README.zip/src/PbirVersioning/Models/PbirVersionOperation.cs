namespace PbirVersioning.Models;

public enum PbirVersionOperation
{
    Created,
    Updated,
    Restored
}
