namespace PbirVersioning.Options;

public sealed class PbirReportStoreOptions
{
    public string ReportsRoot { get; init; } = "powerbi/reports";
    public string SystemRoot { get; init; } = ".system/pbir-versioning";
    public bool ValidateJsonFiles { get; init; } = true;
    public bool RequirePbirDefinition { get; init; } = true;

    internal string NormalizedReportsRoot => NormalizeRoot(ReportsRoot);
    internal string NormalizedSystemRoot => NormalizeRoot(SystemRoot);

    private static string NormalizeRoot(string value)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(value);
        return value.Replace('\\', '/').Trim('/');
    }
}
