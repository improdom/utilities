using PbirVersioning.Models;

namespace PbirVersioning.Services;

public interface IPbirReportStore
{
    Task<PbirReportVersionManifest> AddReportAsync(
        string reportId,
        string localPbirFolder,
        PbirVersionContext context,
        CancellationToken cancellationToken = default);

    Task<PbirReportVersionManifest> UpdateReportAsync(
        string reportId,
        string localPbirFolder,
        PbirVersionContext context,
        CancellationToken cancellationToken = default);

    Task<PbirReportVersionManifest> RestoreVersionAsync(
        string reportId,
        string versionId,
        PbirVersionContext context,
        CancellationToken cancellationToken = default);

    Task<DeleteVersionResult> DeleteVersionAsync(
        string reportId,
        string versionId,
        bool purgeNativeBlobVersions = false,
        CancellationToken cancellationToken = default);

    Task<IReadOnlyList<PbirReportVersionSummary>> ListVersionsAsync(
        string reportId,
        CancellationToken cancellationToken = default);

    Task<PbirReportVersionManifest> GetVersionAsync(
        string reportId,
        string versionId,
        CancellationToken cancellationToken = default);

    Task<PbirCurrentVersion?> GetCurrentVersionAsync(
        string reportId,
        CancellationToken cancellationToken = default);

    Task DownloadVersionAsync(
        string reportId,
        string versionId,
        string localDestination,
        bool overwrite = false,
        CancellationToken cancellationToken = default);

    Task DownloadVersionAsZipAsync(
        string reportId,
        string versionId,
        Stream destination,
        CancellationToken cancellationToken = default);

    Task DownloadFileVersionAsync(
        string reportId,
        string versionId,
        string relativeFilePath,
        Stream destination,
        CancellationToken cancellationToken = default);
}
