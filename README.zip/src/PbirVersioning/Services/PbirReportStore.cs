using System.Collections.Concurrent;
using System.IO.Compression;
using System.Text;
using System.Text.Json;
using Azure;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using PbirVersioning.Models;
using PbirVersioning.Options;
using PbirVersioning.Utilities;

namespace PbirVersioning.Services;

public sealed class PbirReportStore : IPbirReportStore
{
    private static readonly ConcurrentDictionary<string, SemaphoreSlim> ReportLocks = new(StringComparer.Ordinal);

    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web)
    {
        WriteIndented = true
    };

    private readonly BlobContainerClient _container;
    private readonly PbirReportStoreOptions _options;

    public PbirReportStore(
        BlobContainerClient container,
        PbirReportStoreOptions? options = null)
    {
        _container = container ?? throw new ArgumentNullException(nameof(container));
        _options = options ?? new PbirReportStoreOptions();
    }

    public async Task<PbirReportVersionManifest> AddReportAsync(
        string reportId,
        string localPbirFolder,
        PbirVersionContext context,
        CancellationToken cancellationToken = default)
    {
        reportId = ValidateReportId(reportId);
        ValidateContext(context);

        SemaphoreSlim gate = GetReportLock(reportId);
        await gate.WaitAsync(cancellationToken);
        try
        {
            CurrentPointerReadResult? existing = await TryReadCurrentPointerAsync(reportId, cancellationToken);
            if (existing is not null)
            {
                throw new InvalidOperationException(
                    $"Report '{reportId}' already exists. Use UpdateReportAsync instead.");
            }

            IReadOnlyList<LocalPbirFile> files = await PbirProjectScanner.ScanAsync(
                localPbirFolder,
                _options.ValidateJsonFiles,
                _options.RequirePbirDefinition,
                cancellationToken);

            return await SaveFolderVersionAsync(
                reportId,
                files,
                PbirVersionOperation.Created,
                parentVersionId: null,
                restoredFromVersionId: null,
                expectedPointerETag: null,
                context,
                deleteMissingCurrentFiles: false,
                cancellationToken);
        }
        finally
        {
            gate.Release();
        }
    }

    public async Task<PbirReportVersionManifest> UpdateReportAsync(
        string reportId,
        string localPbirFolder,
        PbirVersionContext context,
        CancellationToken cancellationToken = default)
    {
        reportId = ValidateReportId(reportId);
        ValidateContext(context);

        SemaphoreSlim gate = GetReportLock(reportId);
        await gate.WaitAsync(cancellationToken);
        try
        {
            CurrentPointerReadResult current = await ReadCurrentPointerAsync(reportId, cancellationToken);
            IReadOnlyList<LocalPbirFile> files = await PbirProjectScanner.ScanAsync(
                localPbirFolder,
                _options.ValidateJsonFiles,
                _options.RequirePbirDefinition,
                cancellationToken);

            return await SaveFolderVersionAsync(
                reportId,
                files,
                PbirVersionOperation.Updated,
                current.Pointer.VersionId,
                restoredFromVersionId: null,
                current.ETag,
                context,
                deleteMissingCurrentFiles: true,
                cancellationToken);
        }
        finally
        {
            gate.Release();
        }
    }

    public async Task<PbirReportVersionManifest> RestoreVersionAsync(
        string reportId,
        string versionId,
        PbirVersionContext context,
        CancellationToken cancellationToken = default)
    {
        reportId = ValidateReportId(reportId);
        versionId = ValidateVersionId(versionId);
        ValidateContext(context);

        SemaphoreSlim gate = GetReportLock(reportId);
        await gate.WaitAsync(cancellationToken);
        try
        {
            CurrentPointerReadResult current = await ReadCurrentPointerAsync(reportId, cancellationToken);
            PbirReportVersionManifest source = await GetVersionAsync(reportId, versionId, cancellationToken);

            if (string.Equals(current.Pointer.VersionId, versionId, StringComparison.Ordinal))
            {
                throw new InvalidOperationException($"Version '{versionId}' is already current.");
            }

            DateTimeOffset createdUtc = DateTimeOffset.UtcNow;
            string newVersionId = CreateLogicalVersionId(createdUtc);
            string contentPrefix = GetContentPrefix(reportId);
            var restoredFiles = new List<PbirVersionFile>(source.Files.Count);

            HashSet<string> sourceBlobPaths = source.Files
                .Select(file => file.BlobPath)
                .ToHashSet(StringComparer.Ordinal);

            await DeleteMissingCurrentBlobsAsync(
                contentPrefix,
                sourceBlobPaths,
                cancellationToken);

            foreach (PbirVersionFile sourceFile in source.Files)
            {
                cancellationToken.ThrowIfCancellationRequested();

                BlobClient sourceVersion = _container
                    .GetBlobClient(sourceFile.BlobPath)
                    .WithVersion(sourceFile.NativeBlobVersionId);

                BlobClient destination = _container.GetBlobClient(sourceFile.BlobPath);
                await using Stream sourceStream = await sourceVersion.OpenReadAsync(
                    new BlobOpenReadOptions(allowModifications: false),
                    cancellationToken);

                BlobContentInfo uploaded = await UploadCurrentBlobAsync(
                    destination,
                    sourceStream,
                    sourceFile.ContentType,
                    reportId,
                    newVersionId,
                    context,
                    createdUtc,
                    cancellationToken);

                string nativeVersionId = RequireNativeVersionId(uploaded, sourceFile.RelativePath);

                restoredFiles.Add(sourceFile with
                {
                    NativeBlobVersionId = nativeVersionId,
                    ETag = uploaded.ETag.ToString()
                });
            }

            PbirReportVersionManifest manifest = new()
            {
                ReportId = reportId,
                VersionId = newVersionId,
                CreatedUtc = createdUtc,
                CreatedBy = context.UserName.Trim(),
                CreatedByUserId = NullIfWhiteSpace(context.UserId),
                Operation = PbirVersionOperation.Restored,
                ParentVersionId = current.Pointer.VersionId,
                RestoredFromVersionId = source.VersionId,
                Description = NullIfWhiteSpace(context.Description) ?? $"Restored from version {source.VersionId}",
                CorrelationId = NullIfWhiteSpace(context.CorrelationId),
                Files = restoredFiles.OrderBy(file => file.RelativePath, StringComparer.Ordinal).ToArray()
            };

            await SaveManifestAsync(manifest, cancellationToken);
            await SaveCurrentPointerAsync(
                manifest,
                context,
                expectedETag: current.ETag,
                cancellationToken);

            return manifest;
        }
        finally
        {
            gate.Release();
        }
    }

    public async Task<DeleteVersionResult> DeleteVersionAsync(
        string reportId,
        string versionId,
        bool purgeNativeBlobVersions = false,
        CancellationToken cancellationToken = default)
    {
        reportId = ValidateReportId(reportId);
        versionId = ValidateVersionId(versionId);

        SemaphoreSlim gate = GetReportLock(reportId);
        await gate.WaitAsync(cancellationToken);
        try
        {
            CurrentPointerReadResult current = await ReadCurrentPointerAsync(reportId, cancellationToken);
            if (string.Equals(current.Pointer.VersionId, versionId, StringComparison.Ordinal))
            {
                throw new InvalidOperationException(
                    "The current report version cannot be deleted. Restore another version first.");
            }

            PbirReportVersionManifest target = await GetVersionAsync(reportId, versionId, cancellationToken);
            int nativeVersionsDeleted = 0;

            if (purgeNativeBlobVersions)
            {
                IReadOnlyList<PbirReportVersionSummary> summaries = await ListVersionsAsync(reportId, cancellationToken);
                var referencedNativeVersions = new HashSet<string>(StringComparer.Ordinal);

                foreach (PbirReportVersionSummary summary in summaries)
                {
                    if (string.Equals(summary.VersionId, versionId, StringComparison.Ordinal))
                    {
                        continue;
                    }

                    PbirReportVersionManifest manifest = await GetVersionAsync(
                        reportId,
                        summary.VersionId,
                        cancellationToken);

                    foreach (PbirVersionFile file in manifest.Files)
                    {
                        referencedNativeVersions.Add(CreateNativeVersionKey(
                            file.BlobPath,
                            file.NativeBlobVersionId));
                    }
                }

                foreach (PbirVersionFile file in target.Files)
                {
                    string key = CreateNativeVersionKey(file.BlobPath, file.NativeBlobVersionId);
                    if (referencedNativeVersions.Contains(key))
                    {
                        continue;
                    }

                    BlobClient historicalVersion = _container
                        .GetBlobClient(file.BlobPath)
                        .WithVersion(file.NativeBlobVersionId);

                    Response<bool> deleted = await historicalVersion.DeleteIfExistsAsync(
                        cancellationToken: cancellationToken);

                    if (deleted.Value)
                    {
                        nativeVersionsDeleted++;
                    }
                }
            }

            Response<bool> manifestDeleted = await _container
                .GetBlobClient(GetManifestPath(reportId, versionId))
                .DeleteIfExistsAsync(
                    DeleteSnapshotsOption.IncludeSnapshots,
                    cancellationToken: cancellationToken);

            return new DeleteVersionResult
            {
                ReportId = reportId,
                VersionId = versionId,
                ManifestDeleted = manifestDeleted.Value,
                NativeVersionsPurged = purgeNativeBlobVersions,
                NativeVersionsDeleted = nativeVersionsDeleted
            };
        }
        finally
        {
            gate.Release();
        }
    }

    public async Task<IReadOnlyList<PbirReportVersionSummary>> ListVersionsAsync(
        string reportId,
        CancellationToken cancellationToken = default)
    {
        reportId = ValidateReportId(reportId);
        CurrentPointerReadResult? current = await TryReadCurrentPointerAsync(reportId, cancellationToken);
        string manifestPrefix = GetManifestPrefix(reportId);
        var versions = new List<PbirReportVersionSummary>();

        await foreach (BlobItem item in _container.GetBlobsAsync(
            new GetBlobsOptions { Prefix = manifestPrefix },
            cancellationToken))
        {
            if (!item.Name.EndsWith(".json", StringComparison.OrdinalIgnoreCase))
            {
                continue;
            }

            PbirReportVersionManifest manifest = await DownloadJsonAsync<PbirReportVersionManifest>(
                _container.GetBlobClient(item.Name),
                cancellationToken);

            versions.Add(ToSummary(
                manifest,
                string.Equals(current?.Pointer.VersionId, manifest.VersionId, StringComparison.Ordinal)));
        }

        return versions
            .OrderByDescending(version => version.CreatedUtc)
            .ThenByDescending(version => version.VersionId, StringComparer.Ordinal)
            .ToArray();
    }

    public async Task<PbirReportVersionManifest> GetVersionAsync(
        string reportId,
        string versionId,
        CancellationToken cancellationToken = default)
    {
        reportId = ValidateReportId(reportId);
        versionId = ValidateVersionId(versionId);

        BlobClient manifestBlob = _container.GetBlobClient(GetManifestPath(reportId, versionId));
        if (!(await manifestBlob.ExistsAsync(cancellationToken)).Value)
        {
            throw new FileNotFoundException(
                $"Version '{versionId}' was not found for report '{reportId}'.");
        }

        return await DownloadJsonAsync<PbirReportVersionManifest>(manifestBlob, cancellationToken);
    }

    public async Task<PbirCurrentVersion?> GetCurrentVersionAsync(
        string reportId,
        CancellationToken cancellationToken = default)
    {
        reportId = ValidateReportId(reportId);
        CurrentPointerReadResult? current = await TryReadCurrentPointerAsync(reportId, cancellationToken);
        if (current is null)
        {
            return null;
        }

        return new PbirCurrentVersion
        {
            Pointer = current.Pointer,
            Manifest = await GetVersionAsync(reportId, current.Pointer.VersionId, cancellationToken)
        };
    }

    public async Task DownloadVersionAsync(
        string reportId,
        string versionId,
        string localDestination,
        bool overwrite = false,
        CancellationToken cancellationToken = default)
    {
        PbirReportVersionManifest manifest = await ResolveManifestAsync(
            reportId,
            versionId,
            cancellationToken);

        string destinationRoot = Path.GetFullPath(localDestination);
        Directory.CreateDirectory(destinationRoot);

        foreach (PbirVersionFile file in manifest.Files)
        {
            cancellationToken.ThrowIfCancellationRequested();
            string localPath = PbirPathUtilities.GetSafeLocalPath(destinationRoot, file.RelativePath);
            string? directory = Path.GetDirectoryName(localPath);
            if (!string.IsNullOrWhiteSpace(directory))
            {
                Directory.CreateDirectory(directory);
            }

            if (!overwrite && File.Exists(localPath))
            {
                throw new IOException($"The local file already exists: '{localPath}'.");
            }

            BlobClient versionBlob = _container
                .GetBlobClient(file.BlobPath)
                .WithVersion(file.NativeBlobVersionId);

            await versionBlob.DownloadToAsync(
                localPath,
                new BlobDownloadToOptions(),
                cancellationToken);
        }
    }

    public async Task DownloadVersionAsZipAsync(
        string reportId,
        string versionId,
        Stream destination,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(destination);
        if (!destination.CanWrite)
        {
            throw new ArgumentException("The destination stream must be writable.", nameof(destination));
        }

        PbirReportVersionManifest manifest = await ResolveManifestAsync(
            reportId,
            versionId,
            cancellationToken);

        using var archive = new ZipArchive(destination, ZipArchiveMode.Create, leaveOpen: true);
        foreach (PbirVersionFile file in manifest.Files)
        {
            cancellationToken.ThrowIfCancellationRequested();
            ZipArchiveEntry entry = archive.CreateEntry(
                file.RelativePath.Replace('\\', '/'),
                CompressionLevel.Fastest);

            BlobClient versionBlob = _container
                .GetBlobClient(file.BlobPath)
                .WithVersion(file.NativeBlobVersionId);

            await using Stream source = await versionBlob.OpenReadAsync(
                new BlobOpenReadOptions(allowModifications: false),
                cancellationToken);
            await using Stream target = entry.Open();
            await source.CopyToAsync(target, cancellationToken);
        }
    }

    public async Task DownloadFileVersionAsync(
        string reportId,
        string versionId,
        string relativeFilePath,
        Stream destination,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(destination);
        if (!destination.CanWrite)
        {
            throw new ArgumentException("The destination stream must be writable.", nameof(destination));
        }

        PbirReportVersionManifest manifest = await ResolveManifestAsync(
            reportId,
            versionId,
            cancellationToken);

        string normalizedPath = PbirPathUtilities.NormalizeRelativePath(relativeFilePath);
        PbirVersionFile file = manifest.Files.FirstOrDefault(candidate =>
                string.Equals(candidate.RelativePath, normalizedPath, StringComparison.Ordinal))
            ?? throw new FileNotFoundException(
                $"File '{normalizedPath}' is not part of report version '{manifest.VersionId}'.");

        BlobClient versionBlob = _container
            .GetBlobClient(file.BlobPath)
            .WithVersion(file.NativeBlobVersionId);

        await versionBlob.DownloadToAsync(
            destination,
            new BlobDownloadToOptions(),
            cancellationToken);
    }

    private async Task<PbirReportVersionManifest> SaveFolderVersionAsync(
        string reportId,
        IReadOnlyList<LocalPbirFile> localFiles,
        PbirVersionOperation operation,
        string? parentVersionId,
        string? restoredFromVersionId,
        ETag? expectedPointerETag,
        PbirVersionContext context,
        bool deleteMissingCurrentFiles,
        CancellationToken cancellationToken)
    {
        DateTimeOffset createdUtc = DateTimeOffset.UtcNow;
        string logicalVersionId = CreateLogicalVersionId(createdUtc);
        string contentPrefix = GetContentPrefix(reportId);
        var versionFiles = new List<PbirVersionFile>(localFiles.Count);

        foreach (LocalPbirFile localFile in localFiles)
        {
            cancellationToken.ThrowIfCancellationRequested();

            string blobPath = contentPrefix + localFile.RelativePath;
            BlobClient blob = _container.GetBlobClient(blobPath);
            await using FileStream content = new(
                localFile.LocalPath,
                FileMode.Open,
                FileAccess.Read,
                FileShare.Read,
                bufferSize: 81920,
                useAsync: true);

            BlobContentInfo uploaded = await UploadCurrentBlobAsync(
                blob,
                content,
                localFile.ContentType,
                reportId,
                logicalVersionId,
                context,
                createdUtc,
                cancellationToken);

            versionFiles.Add(new PbirVersionFile
            {
                RelativePath = localFile.RelativePath,
                BlobPath = blobPath,
                NativeBlobVersionId = RequireNativeVersionId(uploaded, localFile.RelativePath),
                ETag = uploaded.ETag.ToString(),
                Size = localFile.Size,
                ContentType = localFile.ContentType,
                Sha256 = localFile.Sha256
            });
        }

        if (deleteMissingCurrentFiles)
        {
            HashSet<string> expectedPaths = versionFiles
                .Select(file => file.BlobPath)
                .ToHashSet(StringComparer.Ordinal);

            await DeleteMissingCurrentBlobsAsync(contentPrefix, expectedPaths, cancellationToken);
        }

        PbirReportVersionManifest manifest = new()
        {
            ReportId = reportId,
            VersionId = logicalVersionId,
            CreatedUtc = createdUtc,
            CreatedBy = context.UserName.Trim(),
            CreatedByUserId = NullIfWhiteSpace(context.UserId),
            Operation = operation,
            ParentVersionId = parentVersionId,
            RestoredFromVersionId = restoredFromVersionId,
            Description = NullIfWhiteSpace(context.Description),
            CorrelationId = NullIfWhiteSpace(context.CorrelationId),
            Files = versionFiles.OrderBy(file => file.RelativePath, StringComparer.Ordinal).ToArray()
        };

        await SaveManifestAsync(manifest, cancellationToken);
        await SaveCurrentPointerAsync(manifest, context, expectedPointerETag, cancellationToken);
        return manifest;
    }

    private async Task<BlobContentInfo> UploadCurrentBlobAsync(
        BlobClient blob,
        Stream content,
        string contentType,
        string reportId,
        string logicalVersionId,
        PbirVersionContext context,
        DateTimeOffset createdUtc,
        CancellationToken cancellationToken)
    {
        var options = new BlobUploadOptions
        {
            HttpHeaders = new BlobHttpHeaders { ContentType = contentType },
            Metadata = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
            {
                ["pbirreportid"] = EncodeMetadataValue(reportId),
                ["pbirlogicalversion"] = EncodeMetadataValue(logicalVersionId),
                ["pbircreatedutc"] = createdUtc.ToString("O"),
                ["pbircreatedby"] = EncodeMetadataValue(context.UserName)
            },
            Tags = new Dictionary<string, string>(StringComparer.Ordinal)
            {
                ["pbirReportId"] = PbirPathUtilities.SanitizeTagValue(reportId),
                ["pbirVersionId"] = PbirPathUtilities.SanitizeTagValue(logicalVersionId),
                ["pbirCreatedBy"] = PbirPathUtilities.SanitizeTagValue(context.UserName)
            }
        };

        Response<BlobContentInfo> response = await blob.UploadAsync(content, options, cancellationToken);
        return response.Value;
    }

    private async Task DeleteMissingCurrentBlobsAsync(
        string contentPrefix,
        HashSet<string> expectedBlobPaths,
        CancellationToken cancellationToken)
    {
        var currentPaths = new List<string>();
        await foreach (BlobItem item in _container.GetBlobsAsync(
            new GetBlobsOptions { Prefix = contentPrefix },
            cancellationToken))
        {
            currentPaths.Add(item.Name);
        }

        foreach (string currentPath in currentPaths)
        {
            if (expectedBlobPaths.Contains(currentPath))
            {
                continue;
            }

            await _container
                .GetBlobClient(currentPath)
                .DeleteIfExistsAsync(
                    DeleteSnapshotsOption.IncludeSnapshots,
                    cancellationToken: cancellationToken);
        }
    }

    private async Task SaveManifestAsync(
        PbirReportVersionManifest manifest,
        CancellationToken cancellationToken)
    {
        BlobClient manifestBlob = _container.GetBlobClient(
            GetManifestPath(manifest.ReportId, manifest.VersionId));

        await UploadJsonAsync(
            manifestBlob,
            manifest,
            new BlobRequestConditions { IfNoneMatch = ETag.All },
            cancellationToken);
    }

    private async Task SaveCurrentPointerAsync(
        PbirReportVersionManifest manifest,
        PbirVersionContext context,
        ETag? expectedETag,
        CancellationToken cancellationToken)
    {
        PbirCurrentVersionPointer pointer = new()
        {
            ReportId = manifest.ReportId,
            VersionId = manifest.VersionId,
            UpdatedUtc = manifest.CreatedUtc,
            UpdatedBy = context.UserName.Trim(),
            UpdatedByUserId = NullIfWhiteSpace(context.UserId)
        };

        BlobRequestConditions conditions = expectedETag.HasValue
            ? new BlobRequestConditions { IfMatch = expectedETag.Value }
            : new BlobRequestConditions { IfNoneMatch = ETag.All };

        try
        {
            await UploadJsonAsync(
                _container.GetBlobClient(GetCurrentPointerPath(manifest.ReportId)),
                pointer,
                conditions,
                cancellationToken);
        }
        catch (RequestFailedException exception) when (exception.Status == 409 || exception.Status == 412)
        {
            throw new InvalidOperationException(
                "The report was changed by another writer while this version was being saved. " +
                "The manifest was retained for audit/recovery, but the current-version pointer was not changed.",
                exception);
        }
    }

    private async Task<CurrentPointerReadResult> ReadCurrentPointerAsync(
        string reportId,
        CancellationToken cancellationToken)
    {
        CurrentPointerReadResult? result = await TryReadCurrentPointerAsync(reportId, cancellationToken);
        return result ?? throw new FileNotFoundException(
            $"Report '{reportId}' does not exist. Use AddReportAsync first.");
    }

    private async Task<CurrentPointerReadResult?> TryReadCurrentPointerAsync(
        string reportId,
        CancellationToken cancellationToken)
    {
        BlobClient pointerBlob = _container.GetBlobClient(GetCurrentPointerPath(reportId));
        if (!(await pointerBlob.ExistsAsync(cancellationToken)).Value)
        {
            return null;
        }

        Response<BlobDownloadResult> response = await pointerBlob.DownloadContentAsync(cancellationToken);
        PbirCurrentVersionPointer pointer = DeserializeJson<PbirCurrentVersionPointer>(
            response.Value.Content.ToString(),
            pointerBlob.Name);

        return new CurrentPointerReadResult(pointer, response.Value.Details.ETag);
    }

    private async Task<PbirReportVersionManifest> ResolveManifestAsync(
        string reportId,
        string versionId,
        CancellationToken cancellationToken)
    {
        if (string.Equals(versionId, "current", StringComparison.OrdinalIgnoreCase))
        {
            PbirCurrentVersion current = await GetCurrentVersionAsync(reportId, cancellationToken)
                ?? throw new FileNotFoundException($"Report '{reportId}' does not exist.");
            return current.Manifest;
        }

        return await GetVersionAsync(reportId, versionId, cancellationToken);
    }

    private static PbirReportVersionSummary ToSummary(
        PbirReportVersionManifest manifest,
        bool isCurrent) => new()
    {
        ReportId = manifest.ReportId,
        VersionId = manifest.VersionId,
        CreatedUtc = manifest.CreatedUtc,
        CreatedBy = manifest.CreatedBy,
        CreatedByUserId = manifest.CreatedByUserId,
        Operation = manifest.Operation,
        ParentVersionId = manifest.ParentVersionId,
        RestoredFromVersionId = manifest.RestoredFromVersionId,
        Description = manifest.Description,
        CorrelationId = manifest.CorrelationId,
        FileCount = manifest.FileCount,
        TotalSizeBytes = manifest.TotalSizeBytes,
        IsCurrent = isCurrent
    };

    private async Task UploadJsonAsync<T>(
        BlobClient blob,
        T value,
        BlobRequestConditions conditions,
        CancellationToken cancellationToken)
    {
        byte[] bytes = JsonSerializer.SerializeToUtf8Bytes(value, JsonOptions);
        await using var stream = new MemoryStream(bytes, writable: false);

        var options = new BlobUploadOptions
        {
            HttpHeaders = new BlobHttpHeaders { ContentType = "application/json" },
            Conditions = conditions
        };

        await blob.UploadAsync(stream, options, cancellationToken);
    }

    private static async Task<T> DownloadJsonAsync<T>(
        BlobClient blob,
        CancellationToken cancellationToken)
    {
        Response<BlobDownloadResult> response = await blob.DownloadContentAsync(cancellationToken);
        return DeserializeJson<T>(response.Value.Content.ToString(), blob.Name);
    }

    private static T DeserializeJson<T>(string json, string sourceName) =>
        JsonSerializer.Deserialize<T>(json, JsonOptions)
        ?? throw new InvalidDataException($"JSON document '{sourceName}' could not be deserialized.");

    private SemaphoreSlim GetReportLock(string reportId)
    {
        string key = $"{_container.Uri}|{reportId}";
        return ReportLocks.GetOrAdd(key, static _ => new SemaphoreSlim(1, 1));
    }

    private string GetContentPrefix(string reportId) =>
        $"{_options.NormalizedReportsRoot}/{reportId}/content/";

    private string GetManifestPrefix(string reportId) =>
        $"{_options.NormalizedSystemRoot}/{reportId}/versions/";

    private string GetManifestPath(string reportId, string versionId) =>
        $"{GetManifestPrefix(reportId)}{versionId}.json";

    private string GetCurrentPointerPath(string reportId) =>
        $"{_options.NormalizedSystemRoot}/{reportId}/current.json";

    private static string CreateLogicalVersionId(DateTimeOffset createdUtc) =>
        $"{createdUtc:yyyyMMddTHHmmssfffZ}_{Guid.NewGuid().ToString("N")[..8]}";

    private static string RequireNativeVersionId(BlobContentInfo contentInfo, string relativePath) =>
        !string.IsNullOrWhiteSpace(contentInfo.VersionId)
            ? contentInfo.VersionId
            : throw new InvalidOperationException(
                $"Azure did not return a native blob version ID for '{relativePath}'. " +
                "Confirm that Blob Versioning is enabled and Hierarchical Namespace is disabled.");

    private static string ValidateReportId(string reportId) =>
        PbirPathUtilities.NormalizeIdentifier(reportId, nameof(reportId));

    private static string ValidateVersionId(string versionId) =>
        PbirPathUtilities.NormalizeIdentifier(versionId, nameof(versionId));

    private static void ValidateContext(PbirVersionContext context)
    {
        ArgumentNullException.ThrowIfNull(context);
        ArgumentException.ThrowIfNullOrWhiteSpace(context.UserName, nameof(context.UserName));
    }

    private static string? NullIfWhiteSpace(string? value) =>
        string.IsNullOrWhiteSpace(value) ? null : value.Trim();

    private static string EncodeMetadataValue(string value) =>
        Convert.ToBase64String(Encoding.UTF8.GetBytes(value));

    private static string CreateNativeVersionKey(string blobPath, string versionId) =>
        $"{blobPath}\u001f{versionId}";

    private sealed record CurrentPointerReadResult(
        PbirCurrentVersionPointer Pointer,
        ETag ETag);
}
