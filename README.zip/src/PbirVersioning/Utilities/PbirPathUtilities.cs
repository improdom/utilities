using System.Security.Cryptography;

namespace PbirVersioning.Utilities;

internal static class PbirPathUtilities
{
    public static string NormalizeIdentifier(string value, string parameterName)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(value, parameterName);

        string normalized = value.Trim();
        if (normalized is "." or ".." || normalized.IndexOfAny(['/', '\\']) >= 0)
        {
            throw new ArgumentException(
                $"'{value}' is not a valid identifier. Slashes and relative path segments are not allowed.",
                parameterName);
        }

        return normalized;
    }

    public static string NormalizeRelativePath(string value)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(value);

        string normalized = value.Replace('\\', '/').Trim('/');
        string[] segments = normalized.Split('/', StringSplitOptions.None);

        if (segments.Length == 0 || segments.Any(segment =>
                string.IsNullOrWhiteSpace(segment) || segment is "." or ".."))
        {
            throw new ArgumentException($"Invalid relative path: '{value}'.", nameof(value));
        }

        return normalized;
    }

    public static string GetSafeLocalPath(string destinationRoot, string relativePath)
    {
        string root = Path.GetFullPath(destinationRoot);
        string candidate = Path.GetFullPath(Path.Combine(
            root,
            NormalizeRelativePath(relativePath).Replace('/', Path.DirectorySeparatorChar)));

        string rootPrefix = root.TrimEnd(
                Path.DirectorySeparatorChar,
                Path.AltDirectorySeparatorChar)
            + Path.DirectorySeparatorChar;

        if (!candidate.StartsWith(rootPrefix, StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException(
                $"The path '{relativePath}' resolves outside the destination directory.");
        }

        return candidate;
    }

    public static string GetContentType(string path) =>
        Path.GetExtension(path).ToLowerInvariant() switch
        {
            ".json" => "application/json",
            ".pbir" => "application/json",
            ".pbip" => "application/json",
            ".tmdl" => "text/plain",
            ".yaml" or ".yml" => "application/yaml",
            ".svg" => "image/svg+xml",
            ".png" => "image/png",
            ".jpg" or ".jpeg" => "image/jpeg",
            ".gif" => "image/gif",
            _ => "application/octet-stream"
        };

    public static async Task<string> ComputeSha256Async(
        string path,
        CancellationToken cancellationToken)
    {
        await using FileStream stream = new(
            path,
            FileMode.Open,
            FileAccess.Read,
            FileShare.Read,
            bufferSize: 81920,
            useAsync: true);

        using SHA256 sha256 = SHA256.Create();
        byte[] hash = await sha256.ComputeHashAsync(stream, cancellationToken);
        return Convert.ToHexString(hash).ToLowerInvariant();
    }

    public static string SanitizeTagValue(string value)
    {
        char[] sanitized = value.Select(character =>
                char.IsLetterOrDigit(character) ||
                character is ' ' or '+' or '-' or '.' or '/' or ':' or '=' or '_'
                    ? character
                    : '_')
            .ToArray();

        string result = new(sanitized);
        return result.Length <= 256 ? result : result[..256];
    }
}
