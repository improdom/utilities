using System.Text.Json;

namespace PbirVersioning.Utilities;

internal static class PbirProjectScanner
{
    public static async Task<IReadOnlyList<LocalPbirFile>> ScanAsync(
        string sourceFolder,
        bool validateJson,
        bool requirePbirDefinition,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(sourceFolder) || !Directory.Exists(sourceFolder))
        {
            throw new DirectoryNotFoundException($"PBIR source directory '{sourceFolder}' was not found.");
        }

        string root = Path.GetFullPath(sourceFolder);
        var files = new List<LocalPbirFile>();

        foreach (string path in Directory.EnumerateFiles(root, "*", SearchOption.AllDirectories))
        {
            cancellationToken.ThrowIfCancellationRequested();

            FileAttributes attributes = File.GetAttributes(path);
            if ((attributes & FileAttributes.ReparsePoint) != 0)
            {
                throw new InvalidDataException($"Symbolic links are not supported: '{path}'.");
            }

            string relativePath = PbirPathUtilities.NormalizeRelativePath(Path.GetRelativePath(root, path));
            if (IsExcluded(relativePath))
            {
                continue;
            }

            if (validateJson && IsJsonDocument(relativePath))
            {
                await ValidateJsonAsync(path, cancellationToken);
            }

            FileInfo info = new(path);
            files.Add(new LocalPbirFile(
                relativePath,
                path,
                info.Length,
                PbirPathUtilities.GetContentType(relativePath),
                await PbirPathUtilities.ComputeSha256Async(path, cancellationToken)));
        }

        if (files.Count == 0)
        {
            throw new InvalidDataException("The PBIR source directory contains no files after exclusions.");
        }

        if (requirePbirDefinition &&
            !files.Any(file => file.RelativePath.EndsWith(".pbir", StringComparison.OrdinalIgnoreCase)) &&
            !files.Any(file => file.RelativePath.StartsWith("definition/", StringComparison.OrdinalIgnoreCase) ||
                               file.RelativePath.Contains("/definition/", StringComparison.OrdinalIgnoreCase)))
        {
            throw new InvalidDataException(
                "The directory does not appear to contain an enhanced PBIR report. " +
                "No .pbir file or definition folder was found.");
        }

        return files
            .OrderBy(file => file.RelativePath, StringComparer.Ordinal)
            .ToArray();
    }

    private static bool IsExcluded(string relativePath)
    {
        string path = relativePath.Replace('\\', '/');
        string[] segments = path.Split('/');

        if (segments.Any(segment =>
                segment.Equals(".git", StringComparison.OrdinalIgnoreCase) ||
                segment.Equals("bin", StringComparison.OrdinalIgnoreCase) ||
                segment.Equals("obj", StringComparison.OrdinalIgnoreCase)))
        {
            return true;
        }

        return path.Equals(".pbi/cache.abf", StringComparison.OrdinalIgnoreCase) ||
               path.EndsWith("/.pbi/cache.abf", StringComparison.OrdinalIgnoreCase) ||
               path.Equals(".pbi/localSettings.json", StringComparison.OrdinalIgnoreCase) ||
               path.EndsWith("/.pbi/localSettings.json", StringComparison.OrdinalIgnoreCase);
    }

    private static bool IsJsonDocument(string relativePath)
    {
        string extension = Path.GetExtension(relativePath);
        return extension.Equals(".json", StringComparison.OrdinalIgnoreCase) ||
               extension.Equals(".pbir", StringComparison.OrdinalIgnoreCase) ||
               extension.Equals(".pbip", StringComparison.OrdinalIgnoreCase);
    }

    private static async Task ValidateJsonAsync(string path, CancellationToken cancellationToken)
    {
        try
        {
            await using FileStream stream = new(
                path,
                FileMode.Open,
                FileAccess.Read,
                FileShare.Read,
                bufferSize: 81920,
                useAsync: true);

            using JsonDocument _ = await JsonDocument.ParseAsync(
                stream,
                cancellationToken: cancellationToken);
        }
        catch (JsonException exception)
        {
            throw new InvalidDataException($"Invalid JSON in PBIR file '{path}'.", exception);
        }
    }
}

internal sealed record LocalPbirFile(
    string RelativePath,
    string LocalPath,
    long Size,
    string ContentType,
    string Sha256);
