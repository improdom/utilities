using System.Data;
using System.Net;
using System.Text;
using System.Text.Json;
using RestQuery.Ado;

var handler = new FakeHandler();
using var http = new HttpClient(handler);
using var connection = new RestQueryConnection(http, new Uri("https://example.test/query"));
IDbConnection db = connection;
using var command = (RestQueryCommand)db.CreateCommand();
command.CommandText = "SELECT `CoB Date`, `Desk Name`, MEASURE(`Vega`) FROM example GROUP BY ALL";
var checks = 0;
void Check(bool ok) { if (!ok) throw new Exception("Check failed"); checks++; }
void Throws<T>(Action run) where T : Exception { try { run(); } catch (T) { checks++; return; } throw new Exception($"Expected {typeof(T).Name}"); }
Throws<InvalidOperationException>(() => command.ExecuteReader());
db.Open();
using (IDataReader reader = command.ExecuteReader())
{
    Check(reader.Read()); Check(reader.GetString(0) == "2026-08-03T00:00:00Z");
    Check(reader.GetString(2) == "-3848855.838796");
    Check(reader.Read() && reader.IsDBNull(1) && reader.IsDBNull(2));
    Check(reader.GetString(reader.GetOrdinal("Later")) == "column");
    Check(!reader.Read() && reader.NextResult() && reader.Read() && reader.GetInt64(0) == 9);
    Check(!reader.NextResult());
}
using (var request = JsonDocument.Parse(handler.Body!))
{
    var root = request.RootElement;
    Check(root.GetProperty("queries")[0].GetProperty("query").GetString() == command.CommandText);
    Check(root.GetProperty("queries")[0].GetProperty("id").GetString() == "55");
    Check(root.GetProperty("queries")[0].GetProperty("queryType").GetString() == "Databricks");
    Check(root.GetProperty("serializerSettings").GetProperty("includeNulls").GetBoolean());
}
command.ColumnTypes["CoB Date"] = typeof(DateTime);
command.ColumnTypes["Vega"] = typeof(decimal);
using (var reader = command.ExecuteReader(CommandBehavior.CloseConnection))
{
    reader.Read(); Check(reader.GetDateTime(0).Kind == DateTimeKind.Utc);
    Check(reader.GetDecimal(2) == -3848855.838796m);
}
Check(connection.State == ConnectionState.Closed);
db.Open(); command.ColumnTypes.Clear();
using (var reader = command.ExecuteReader()) { var table = new DataTable(); table.Load(reader); Check(table.Rows.Count == 2); }
foreach (var json in new[] {
    """{"error":{"message":"failure"}}""",
    """{"results":[{"id":"55","error":"failure"}]}""",
    """{"results":[{"id":"55","tables":[{"error":"failure"}]}]}""",
    """{"results":[{"id":"other","tables":[]}]}"""
}) { handler.Json = json; Throws<RestQueryException>(() => command.ExecuteReader()); }
handler.Status = HttpStatusCode.Unauthorized; Throws<RestQueryException>(() => command.ExecuteReader());
handler.Status = HttpStatusCode.OK; handler.Delay = true;
using (var cts = new CancellationTokenSource(50))
{ try { using var reader = await command.ExecuteReaderAsync(cts.Token); throw new Exception("Expected cancellation"); } catch (OperationCanceledException) { checks++; } }
handler.Delay = false; handler.Json = """{"results":[{"id":"55","tables":[{"rows":[],"error":null}]}]}""";
command.ColumnTypes["empty"] = typeof(decimal);
using (var reader = command.ExecuteReader()) { Check(reader.FieldCount == 1 && reader.GetFieldType(0) == typeof(decimal) && !reader.Read()); }
Throws<NotSupportedException>(() => command.CreateParameter());
connection.Dispose(); Check((await http.GetAsync("https://example.test/alive")).IsSuccessStatusCode);
Console.WriteLine($"Passed {checks} checks.");

sealed class FakeHandler : HttpMessageHandler
{
    public string? Body;
    public bool Delay;
    public HttpStatusCode Status = HttpStatusCode.OK;
    public string Json = """
    {"results":[{"id":"55","tables":[{"rows":[
    {"CoB Date":"2026-08-03T00:00:00Z","Desk Name":"EQ EU Structured Products","Vega":"-3848855.838796"},
    {"CoB Date":"2026-08-03T00:00:00Z","Desk Name":null,"Later":"column"}],"error":null},
    {"rows":[{"count":9}],"error":null}],"error":null}],"error":null,"InformationProtectionLabel":null}
    """;
    protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken ct)
    {
        if (request.Content is not null) Body = await request.Content.ReadAsStringAsync(ct);
        if (Delay) await Task.Delay(Timeout.Infinite, ct);
        return new HttpResponseMessage(Status) { Content = new StringContent(Json, Encoding.UTF8, "application/json") };
    }
}
