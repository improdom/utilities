# REST query ADO.NET wrapper

A dependency-free .NET 8 wrapper implementing `IDbConnection`, `IDbCommand`, and `IDataReader` through their `Db*` base classes. Uses the supplied REST payload and response shape, independently of the earlier Databricks client wrapper.

Add a project reference to `RestQuery.Ado.csproj`.

```csharp
using System.Data;
using System.Net.Http.Headers;
using RestQuery.Ado;

// Prefer a long-lived HttpClient supplied by your application / IHttpClientFactory.
// Configure authentication according to your API's requirements.
var http = new HttpClient();
http.DefaultRequestHeaders.Authorization =
    new AuthenticationHeaderValue("Bearer", accessToken);

using IDbConnection connection = new RestQueryConnection(
    http, new Uri("https://your-api.example/query"));
connection.Open();

using var command = (RestQueryCommand)connection.CreateCommand();
command.QueryId = "55";
command.QueryType = "Databricks";
command.CommandTimeout = 60;
command.CommandText = """
SELECT `CoB Date`, `Desk Name`,
       MEASURE(`EQ Vega ex Fund Slide Map - Index & ASX`)
           AS `EQ Vega ex Fund Slide Map - Index & ASX`
FROM neu_dev_at40482_mtrc.cubiq_semantic_layer.eq_vega_ex_fund_slide_map_dash_index_asx_d03fbc0904
WHERE `CoB Date` = DATE'2026-08-03' AND `Report Currency` = 'USD'
GROUP BY ALL
""";

const string measure = "EQ Vega ex Fund Slide Map - Index & ASX";
// Optional, because the REST response has no declared column types.
command.ColumnTypes["CoB Date"] = typeof(DateTime);
command.ColumnTypes[measure] = typeof(decimal);

using IDataReader reader = command.ExecuteReader();
while (reader.Read())
{
    DateTime date = reader.GetDateTime(reader.GetOrdinal("CoB Date"));
    int deskOrdinal = reader.GetOrdinal("Desk Name");
    string? desk = reader.IsDBNull(deskOrdinal) ? null : reader.GetString(deskOrdinal);
    int vegaOrdinal = reader.GetOrdinal(measure);
    decimal? vega = reader.IsDBNull(vegaOrdinal) ? null : reader.GetDecimal(vegaOrdinal);
    Console.WriteLine($"{date:yyyy-MM-dd} | {desk} | {vega}");
}
```

With no `ColumnTypes` configuration, use `GetString()` for all three example columns. JSON strings remain strings, including numbers and dates encoded as strings. No guessing based on column names or string contents occurs. Native JSON booleans become `bool`; native integers that fit `Int64` become `long`. Other native JSON numbers remain `JsonElement` to preserve precision; arrays and objects become raw JSON strings. Homogeneous columns receive the corresponding CLR schema type; mixed/all-null columns use `object`. Explicit types use invariant-culture conversion and throw on incompatible values. JSON null and missing properties become `DBNull.Value`.

Column order follows first appearance across all rows. Later rows can introduce new columns; earlier rows receive nulls. With empty rows, `ColumnTypes` supplies an optional schema; otherwise the reader has zero columns. The API must supply metadata separately if exact schema is needed for empty results.

Explicit `DateTime` columns normalize offsets to UTC and assume UTC when a timestamp has no offset. Use `DateTimeOffset` to preserve an explicit original offset.

## Request and response handling

Each execution posts one entry under `queries`, using `QueryId` (default `"55"`), `QueryType` (default `"Databricks"`), and `CommandText` as `query`. The request always sets `serializerSettings.includeNulls` to `true`. Responses are matched by the exact string ID; missing or duplicate matches fail. Each table becomes a result set, available through `NextResult()`. All tables are checked for errors before returning a reader. `InformationProtectionLabel` is currently not exposed; any associated policy must be handled by your application.

HTTP errors and non-null `error` fields at response, query, or table level raise `RestQueryException`. Its `Scope` identifies the layer. Server errors are included in the exception message; consider your logging policy for potentially sensitive API error details. Invalid JSON or invalid type conversions also fail rather than returning partial data.

## Lifecycle and limits

- `Open()` is local; the first command validates API connectivity and authentication. Disposing the connection does not dispose your `HttpClient`.
- The caller configures authentication, token refresh, default headers, HTTP timeout, and redirect behavior on the supplied client. Use a delegating handler for per-request token refresh. Use an `HttpClientHandler` with `AllowAutoRedirect = false` if redirects are not part of your API contract.
- `ExecuteReader` and `ExecuteScalar` support sync/async. `ExecuteReaderAsync(cancellationToken)` cancels the HTTP request and parsing. `Cancel()` does the same for the active command. No server cancellation endpoint was supplied, so backend execution may continue.
- `CommandTimeout` defaults to 30 seconds; zero disables the command timeout. `HttpClient.Timeout` can impose an earlier limit. Cancellation/timeout raises `OperationCanceledException` (or its subclass).
- JSON and all tables are buffered in memory. This wrapper has no automatic pagination, retries, or streaming protocol because none was specified. Use bounded result sets. Requests are not retried automatically.
- `CloseConnection`, `SingleResult`, `SingleRow`, and `SequentialAccess` are accepted. Data remains buffered; the latter is only a compatibility flag. Single-row/result limits apply after receiving and validating the whole response.
- Transactions, stored procedures, `ExecuteNonQuery`, `SchemaOnly`, `KeyInfo`, and parameters are unsupported. The supplied payload has no server-side parameter contract; the wrapper does not substitute values into SQL. Use trusted SQL, or extend the API with parameter binding before accepting untrusted input.
- Do not mutate or concurrently execute the same command. Connections and readers are not intended for concurrent mutation.

## Verification

```text
dotnet build RestQuery.Ado/RestQuery.Ado.csproj
dotnet run --project RestQuery.Ado.Tests/RestQuery.Ado.Tests.csproj
```

Tests use a fake `HttpMessageHandler` and verify the payload, strings and typed values, null/missing properties, later columns, multiple tables, error handling, cancellation, empty schemas, and client ownership. Live testing requires your endpoint and authentication configuration.
