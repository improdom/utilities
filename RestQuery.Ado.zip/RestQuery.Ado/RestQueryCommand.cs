using System.Data;
using System.Data.Common;
using System.Net.Http.Json;
using System.Text.Json;

namespace RestQuery.Ado;

public sealed class RestQueryCommand : DbCommand
{
    private RestQueryConnection? connection;
    private readonly object gate = new();
    private CancellationTokenSource? active;
    private bool disposed;
    private int timeout = 30;
    public string QueryId { get; set; } = "55";
    public string QueryType { get; set; } = "Databricks";
    /// <summary>Optional CLR types by exact column name. Unspecified JSON strings remain strings.</summary>
    public IDictionary<string, Type> ColumnTypes { get; } = new Dictionary<string, Type>(StringComparer.Ordinal);
    public override string CommandText { get; set; } = "";
    public override int CommandTimeout { get => timeout; set { if (value < 0) throw new ArgumentOutOfRangeException(nameof(value)); timeout = value; } }
    public override CommandType CommandType { get; set; } = CommandType.Text;
    public override bool DesignTimeVisible { get; set; }
    public override UpdateRowSource UpdatedRowSource { get; set; }
    protected override DbConnection? DbConnection { get => connection; set { if (value is not null and not RestQueryConnection) throw new ArgumentException("Use RestQueryConnection."); connection = (RestQueryConnection?)value; } }
    protected override DbTransaction? DbTransaction { get => null; set { if (value is not null) throw new NotSupportedException(); } }
    protected override DbParameterCollection DbParameterCollection => throw new NotSupportedException("This endpoint payload defines no parameter binding. SQL interpolation is not provided.");
    protected override DbParameter CreateDbParameter() => throw new NotSupportedException("The endpoint defines no parameter binding.");
    private RestQueryConnection Validate()
    {
        ObjectDisposedException.ThrowIf(disposed, this);
        if (CommandType != CommandType.Text) throw new NotSupportedException("Only SQL text is supported.");
        ArgumentException.ThrowIfNullOrWhiteSpace(CommandText);
        ArgumentException.ThrowIfNullOrWhiteSpace(QueryId);
        ArgumentException.ThrowIfNullOrWhiteSpace(QueryType);
        var conn = connection ?? throw new InvalidOperationException("Set Connection first."); conn.EnsureOpen(); return conn;
    }
    public override void Prepare() => Validate();
    public override void Cancel() { lock (gate) active?.Cancel(); }
    protected override DbDataReader ExecuteDbDataReader(CommandBehavior behavior) => Task.Run(() => ExecuteDbDataReaderAsync(behavior, CancellationToken.None)).GetAwaiter().GetResult();
    protected override async Task<DbDataReader> ExecuteDbDataReaderAsync(CommandBehavior behavior, CancellationToken cancellationToken)
    {
        const CommandBehavior supported = CommandBehavior.CloseConnection | CommandBehavior.SingleResult | CommandBehavior.SingleRow | CommandBehavior.SequentialAccess;
        if ((behavior & ~supported) != 0) throw new NotSupportedException("Unsupported command behavior.");
        var conn = Validate();
        var id = QueryId;
        var types = new Dictionary<string, Type>(ColumnTypes, StringComparer.Ordinal);
        using var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        lock (gate) { if (active is not null) throw new InvalidOperationException("Command is already executing."); active = cts; }
        try
        {
            if (CommandTimeout > 0) cts.CancelAfter(TimeSpan.FromSeconds(CommandTimeout));
            var ct = cts.Token;
            using var request = new HttpRequestMessage(HttpMethod.Post, conn.Endpoint)
            {
                Content = JsonContent.Create(new { queries = new[] { new { id, queryType = QueryType, query = CommandText } }, serializerSettings = new { includeNulls = true } })
            };
            using var response = await conn.Client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, ct).ConfigureAwait(false);
            if (!response.IsSuccessStatusCode) throw new RestQueryException("HTTP", $"REST query returned HTTP {(int)response.StatusCode} ({response.ReasonPhrase}).");
            await using var stream = await response.Content.ReadAsStreamAsync(ct).ConfigureAwait(false);
            using var document = await JsonDocument.ParseAsync(stream, cancellationToken: ct).ConfigureAwait(false);
            var root = document.RootElement;
            CheckError(root, "response");
            if (!root.TryGetProperty("results", out var results) || results.ValueKind != JsonValueKind.Array) throw new RestQueryException("response", "Missing results array.");
            var matches = results.EnumerateArray().Where(r => r.TryGetProperty("id", out var resultId) && resultId.ValueKind == JsonValueKind.String && resultId.GetString() == id).ToArray();
            if (matches.Length != 1) throw new RestQueryException("response", $"Expected exactly one result for query ID '{id}'.");
            var result = matches[0]; CheckError(result, "query");
            if (!result.TryGetProperty("tables", out var tables) || tables.ValueKind != JsonValueKind.Array) throw new RestQueryException("query", "Missing tables array.");
            var parsed = new List<DataTable>();
            try
            {
                foreach (var table in tables.EnumerateArray())
                {
                    ct.ThrowIfCancellationRequested(); CheckError(table, "table");
                    parsed.Add(RestQueryDataReader.ParseTable(table, types, ct));
                }
                if (parsed.Count == 0) parsed.Add(new DataTable());
                if ((behavior & (CommandBehavior.SingleResult | CommandBehavior.SingleRow)) != 0)
                    while (parsed.Count > 1) { parsed[^1].Dispose(); parsed.RemoveAt(parsed.Count - 1); }
                if ((behavior & CommandBehavior.SingleRow) != 0) while (parsed[0].Rows.Count > 1) parsed[0].Rows.RemoveAt(parsed[0].Rows.Count - 1);
                ct.ThrowIfCancellationRequested();
                return new RestQueryDataReader(parsed.ToArray(), (behavior & CommandBehavior.CloseConnection) != 0 ? conn : null);
            }
            catch { foreach (var table in parsed) table.Dispose(); throw; }
        }
        finally { lock (gate) active = null; }
    }
    private static void CheckError(JsonElement element, string scope)
    {
        if (element.ValueKind != JsonValueKind.Object) throw new RestQueryException(scope, "Expected a JSON object.");
        if (element.TryGetProperty("error", out var error) && error.ValueKind is not JsonValueKind.Null and not JsonValueKind.Undefined)
            throw new RestQueryException(scope, $"REST {scope} error: {(error.ValueKind == JsonValueKind.String ? error.GetString() : error.GetRawText())}");
    }
    public override object? ExecuteScalar() { using var r = ExecuteReader(); return r.Read() && r.FieldCount > 0 ? r.GetValue(0) : null; }
    public override async Task<object?> ExecuteScalarAsync(CancellationToken ct) { using var r = await ExecuteReaderAsync(ct).ConfigureAwait(false); return r.Read() && r.FieldCount > 0 ? r.GetValue(0) : null; }
    public override int ExecuteNonQuery() => throw new NotSupportedException("This wrapper is for queries.");
    public override Task<int> ExecuteNonQueryAsync(CancellationToken ct) => throw new NotSupportedException("This wrapper is for queries.");
    protected override void Dispose(bool disposing) { if (disposing) { Cancel(); disposed = true; } base.Dispose(disposing); }
}
