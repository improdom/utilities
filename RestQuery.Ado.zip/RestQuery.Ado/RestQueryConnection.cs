using System.Data;
using System.Data.Common;

namespace RestQuery.Ado;

/// <summary>Logical connection. The caller owns HttpClient and its authentication.</summary>
public sealed class RestQueryConnection : DbConnection
{
    private ConnectionState state;
    private bool disposed;
    internal HttpClient Client { get; }
    public Uri Endpoint { get; }
    public RestQueryConnection(HttpClient client, Uri endpoint)
    {
        Client = client ?? throw new ArgumentNullException(nameof(client));
        Endpoint = endpoint ?? throw new ArgumentNullException(nameof(endpoint));
        if (!endpoint.IsAbsoluteUri || endpoint.Scheme != "https" || endpoint.UserInfo.Length != 0)
            throw new ArgumentException("An absolute HTTPS endpoint is required.", nameof(endpoint));
    }
    public override string ConnectionString { get => Endpoint.AbsoluteUri; set => throw new NotSupportedException("Use the constructor."); }
    public override string Database => "";
    public override string DataSource => Endpoint.AbsoluteUri;
    public override string ServerVersion => throw new NotSupportedException();
    public override ConnectionState State => state;
    public override int ConnectionTimeout => 0;
    public override void Open() { ObjectDisposedException.ThrowIf(disposed, this); SetState(ConnectionState.Open); }
    public override Task OpenAsync(CancellationToken ct) { ct.ThrowIfCancellationRequested(); Open(); return Task.CompletedTask; }
    public override void Close() => SetState(ConnectionState.Closed);
    private void SetState(ConnectionState next) { var old = state; state = next; if (old != next) OnStateChange(new StateChangeEventArgs(old, next)); }
    internal void EnsureOpen() { ObjectDisposedException.ThrowIf(disposed, this); if (state != ConnectionState.Open) throw new InvalidOperationException("Open the connection first."); }
    public override void ChangeDatabase(string databaseName) => throw new NotSupportedException();
    protected override DbTransaction BeginDbTransaction(IsolationLevel isolationLevel) => throw new NotSupportedException();
    protected override DbCommand CreateDbCommand() { ObjectDisposedException.ThrowIf(disposed, this); return new RestQueryCommand { Connection = this }; }
    protected override void Dispose(bool disposing) { if (disposing) { Close(); disposed = true; } base.Dispose(disposing); }
}

public sealed class RestQueryException : DbException
{
    public string Scope { get; }
    public RestQueryException(string scope, string message) : base(message) => Scope = scope;
}
