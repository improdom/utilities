using System.Collections;
using System.Data;
using System.Data.Common;
using System.Globalization;
using System.Text.Json;

namespace RestQuery.Ado;

public sealed class RestQueryDataReader : DbDataReader
{
    private readonly DataTableReader reader;
    private readonly DataTable[] tables;
    private readonly RestQueryConnection? connection;
    internal RestQueryDataReader(DataTable[] tables, RestQueryConnection? connection)
    { this.tables = tables; reader = new DataTableReader(tables); this.connection = connection; }
    internal static DataTable ParseTable(JsonElement source, IDictionary<string, Type> types, CancellationToken ct)
    {
        if (!source.TryGetProperty("rows", out var rows) || rows.ValueKind != JsonValueKind.Array) throw new RestQueryException("table", "Missing rows array.");
        var table = new DataTable { Locale = CultureInfo.InvariantCulture };
        try
        {
            var names = new List<string>();
            var seen = new HashSet<string>(StringComparer.Ordinal);
            foreach (var row in rows.EnumerateArray())
            {
                ct.ThrowIfCancellationRequested();
                if (row.ValueKind != JsonValueKind.Object) throw new RestQueryException("row", "Expected a JSON object.");
                var unique = new HashSet<string>(StringComparer.Ordinal);
                foreach (var property in row.EnumerateObject())
                {
                    if (!unique.Add(property.Name)) throw new RestQueryException("row", $"Duplicate column '{property.Name}'.");
                    if (seen.Add(property.Name)) names.Add(property.Name);
                }
            }
            // Empty responses have no names: explicit types provide the optional schema.
            if (names.Count == 0) names.AddRange(types.Keys);
            foreach (var name in names)
            {
                var type = types.TryGetValue(name, out var specified) ? Nullable.GetUnderlyingType(specified) ?? specified : typeof(object);
                var column = table.Columns.Add(name, type);
                if (type == typeof(DateTime)) column.DateTimeMode = DataSetDateTime.Utc;
            }
            foreach (var row in rows.EnumerateArray())
            {
                ct.ThrowIfCancellationRequested();
                var values = new object[names.Count];
                for (var i = 0; i < names.Count; i++)
                {
                    var name = names[i];
                    if (!row.TryGetProperty(name, out var value) || value.ValueKind == JsonValueKind.Null) values[i] = DBNull.Value;
                    else values[i] = ConvertValue(value, table.Columns[i].DataType);
                }
                table.Rows.Add(values);
            }
            // Resolve homogeneous untyped columns to useful CLR metadata; mixed columns stay object.
            for (var i = 0; i < names.Count; i++)
            {
                var column = table.Columns[i];
                if (column.DataType != typeof(object)) continue;
                var distinct = table.Rows.Cast<DataRow>().Select(r => r[i]).Where(v => v is not DBNull).Select(v => v.GetType()).Distinct().ToArray();
                if (distinct.Length != 1) continue;
                var replacement = new DataColumn("__rest_" + Guid.NewGuid().ToString("N"), distinct[0]);
                table.Columns.Add(replacement);
                foreach (DataRow row in table.Rows) row[replacement] = row[column];
                table.Columns.Remove(column); replacement.ColumnName = names[i]; replacement.SetOrdinal(i);
            }
            return table;
        }
        catch { table.Dispose(); throw; }
    }
    private static object ConvertValue(JsonElement value, Type target)
    {
        if (target == typeof(object)) return value.ValueKind switch
        {
            JsonValueKind.String => value.GetString()!, JsonValueKind.True => true, JsonValueKind.False => false,
            JsonValueKind.Number when value.TryGetInt64(out var integer) => integer,
            JsonValueKind.Number => value.Clone(), // Preserve arbitrary JSON numbers exactly.
            _ => value.GetRawText()
        };
        var text = value.ValueKind == JsonValueKind.String ? value.GetString()! : value.GetRawText();
        if (target == typeof(string)) return text;
        if (target == typeof(DateTime)) return DateTime.Parse(text, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal);
        if (target == typeof(DateTimeOffset)) return DateTimeOffset.Parse(text, CultureInfo.InvariantCulture, DateTimeStyles.None);
        if (target == typeof(Guid)) return Guid.Parse(text);
        if (target == typeof(byte[])) return Convert.FromBase64String(text);
        return Convert.ChangeType(text, target, CultureInfo.InvariantCulture);
    }
    public override int FieldCount => reader.FieldCount;
    public override bool HasRows => reader.HasRows;
    public override bool IsClosed => reader.IsClosed;
    public override int Depth => reader.Depth;
    public override int RecordsAffected => -1;
    public override object this[int ordinal] => reader[ordinal];
    public override object this[string name] => reader[name];
    public override bool Read() => reader.Read();
    public override Task<bool> ReadAsync(CancellationToken ct) { ct.ThrowIfCancellationRequested(); return Task.FromResult(Read()); }
    public override bool NextResult() => reader.NextResult();
    public override Task<bool> NextResultAsync(CancellationToken ct) { ct.ThrowIfCancellationRequested(); return Task.FromResult(NextResult()); }
    public override void Close() { if (reader.IsClosed) return; reader.Close(); foreach (var table in tables) table.Dispose(); connection?.Close(); }
    protected override void Dispose(bool disposing) { if (disposing) Close(); base.Dispose(disposing); }
    public override string GetName(int ordinal) => reader.GetName(ordinal);
    public override string GetDataTypeName(int ordinal) => reader.GetDataTypeName(ordinal);
    public override Type GetFieldType(int ordinal) => reader.GetFieldType(ordinal);
    public override int GetOrdinal(string name) => reader.GetOrdinal(name);
    public override object GetValue(int ordinal) => reader.GetValue(ordinal);
    public override int GetValues(object[] values) => reader.GetValues(values);
    public override bool IsDBNull(int ordinal) => reader.IsDBNull(ordinal);
    public override bool GetBoolean(int ordinal) => reader.GetBoolean(ordinal);
    public override byte GetByte(int ordinal) => reader.GetByte(ordinal);
    public override short GetInt16(int ordinal) => reader.GetInt16(ordinal);
    public override int GetInt32(int ordinal) => reader.GetInt32(ordinal);
    public override long GetInt64(int ordinal) => reader.GetInt64(ordinal);
    public override float GetFloat(int ordinal) => reader.GetFloat(ordinal);
    public override double GetDouble(int ordinal) => reader.GetDouble(ordinal);
    public override decimal GetDecimal(int ordinal) => reader.GetDecimal(ordinal);
    public override DateTime GetDateTime(int ordinal) => reader.GetDateTime(ordinal);
    public override Guid GetGuid(int ordinal) => reader.GetGuid(ordinal);
    public override char GetChar(int ordinal) => reader.GetChar(ordinal);
    public override string GetString(int ordinal) => reader.GetString(ordinal);
    public override long GetBytes(int ordinal, long dataOffset, byte[]? buffer, int bufferOffset, int length) => reader.GetBytes(ordinal, dataOffset, buffer, bufferOffset, length);
    public override long GetChars(int ordinal, long dataOffset, char[]? buffer, int bufferOffset, int length) => reader.GetChars(ordinal, dataOffset, buffer, bufferOffset, length);
    public override DataTable? GetSchemaTable() => reader.GetSchemaTable();
    public override IEnumerator GetEnumerator() => new DbEnumerator(this, false);
}
