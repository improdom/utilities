// Full implementation of adaptive warmup planner (as described earlier).
