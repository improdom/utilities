# WarmupRunner v2 — Soft 10-Minute Target

This .NET 8 console app warms a Power BI dataset after refresh. It dynamically finds important columns and warms them.

See Program.cs for configuration.
