# WarmupRunner v4 — Adaptive Soft-10-Min Warm-up + Logging

- Dynamic column selection (DMVs + measure deps)
- Dictionary-only warm for dimensions
- Adaptive batched warm-up for facts (latest CoB × all run IDs)
- Soft 10-minute target (no hard stop) and structured logging

Build & Run:
```
dotnet build
dotnet run
```
