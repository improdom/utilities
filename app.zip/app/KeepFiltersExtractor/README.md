# KeepFiltersExtractor

C# console application that reads a TMSL/TSML-style model definition file and extracts the attributes and values used inside `KEEPFILTERS(...)` across all measures.

## Run

```powershell
dotnet run --project KeepFiltersExtractor -- C:\path\to\database.tmsl
```

You can also point it at a folder. It will scan all supported text files recursively:

```powershell
dotnet run --project KeepFiltersExtractor -- C:\path\to\models
```

To also export CSV:

```powershell
dotnet run --project KeepFiltersExtractor -- C:\path\to\database.tmsl C:\temp\keepfilters.csv
```

## Output

- Detailed rows: file, measure, attribute, operator, values
- Grouped summary: one row per attribute with all distinct values

## Supported input

- JSON/TMSL-style files where measures appear under a `measures` collection
- Text exports where measure expressions are stored in `"expression"` fields
- TMDL-like `measure ... =` blocks
