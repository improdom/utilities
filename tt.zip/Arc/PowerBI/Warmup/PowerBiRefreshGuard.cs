using System;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Threading.Tasks;

namespace Arc.PowerBI.Warmup
{
    public sealed class PowerBiRefreshGuard : IDisposable
    {
        private readonly Func<Task<string>> _acquireTokenAsync;
        private readonly HttpClient _http;

        public PowerBiRefreshGuard(Func<Task<string>> acquireTokenAsync, HttpClient? http = null)
        {
            _acquireTokenAsync = acquireTokenAsync ?? throw new ArgumentNullException(nameof(acquireTokenAsync));
            _http = http ?? new HttpClient();
        }

        public async Task<bool> IsRefreshInProgressAsync(Guid groupId, Guid datasetId)
        {
            var token = await _acquireTokenAsync();
            using var req = new HttpRequestMessage(
                HttpMethod.Get,
                $"https://api.powerbi.com/v1.0/myorg/groups/{groupId}/datasets/{datasetId}/refreshes?$top=1");

            req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

            using var resp = await _http.SendAsync(req);
            resp.EnsureSuccessStatusCode();

            using var stream = await resp.Content.ReadAsStreamAsync();
            using var doc = await JsonDocument.ParseAsync(stream);

            if (!doc.RootElement.TryGetProperty("value", out var arr) || arr.ValueKind != JsonValueKind.Array || arr.GetArrayLength() == 0)
                return false;

            var latest = arr.EnumerateArray().First();
            if (latest.TryGetProperty("status", out var statusProp))
            {
                var status = statusProp.GetString() ?? "";
                return status.Equals("InProgress", StringComparison.OrdinalIgnoreCase);
            }
            return false;
        }

        public void Dispose() => _http.Dispose();
    }
}
