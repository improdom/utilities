using System;
using System.Threading.Tasks;
using Microsoft.Identity.Client;

namespace Arc.PowerBI.Warmup
{
    public static class PowerBiTokenHelper
    {
        public static async Task<string> AcquireTokenForClientAsync(string tenantId, string clientId, string clientSecret)
        {
            var app = ConfidentialClientApplicationBuilder
                .Create(clientId)
                .WithClientSecret(clientSecret)
                .WithAuthority(new Uri($"https://login.microsoftonline.com/{tenantId}"))
                .Build();

            var scopes = new[] { "https://analysis.windows.net/powerbi/api/.default" };
            var result = await app.AcquireTokenForClient(scopes).ExecuteAsync();
            return result.AccessToken;
        }
    }
}
