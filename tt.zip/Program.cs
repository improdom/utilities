using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Arc.PowerBI.Warmup;
using Microsoft.Extensions.Logging;

namespace WarmupRunner
{
    internal static class Program
    {
        private static string WorkspaceId => GetEnv("PBI_WORKSPACE_ID", "<GUID>");
        private static string DatasetId   => GetEnv("PBI_DATASET_ID", "<GUID>");
        private static string XmlaConn    => GetEnv("XMLA_CONNECTION_STRING", "powerbi://api.powerbi.com/v1.0/myorg/<Workspace>;Initial Catalog=<Dataset>");
        private static string ModelName   => GetEnv("MODEL_NAME", "<Dataset Name>");
        private static string RecentPartitionColumn => GetEnv("RECENT_PARTITION_COLUMN", "'CoB Date'[COB Date]");
        private static string SecondaryKeyColumn => GetEnv("SECONDARY_KEY_COLUMN", "'pbi_fact_risk_results_aggregated_vw'[event_run_time_id]");
        private static string SkipTablesCsv => GetEnv("SKIP_TABLES", "");

        private static string GetEnv(string key, string fallback) =>
            Environment.GetEnvironmentVariable(key) ?? fallback;

        public static async Task Main(string[] args)
        {
            using var loggerFactory = LoggerFactory.Create(builder =>
            {
                builder
                    .SetMinimumLevel(LogLevel.Information)
                    .AddConsole(options =>
                    {
                        options.TimestampFormat = "yyyy-MM-dd HH:mm:ss.fff ";
                        options.IncludeScopes = false;
                    });
            });
            var logger = loggerFactory.CreateLogger("WarmupRunner");

            logger.LogInformation("=== ARC VertiPaq Warm-up Runner (Soft 10-min Target) ===");

            var planner = new VertiPaqWarmupPlanner_Perf(logger);
            var opts = new VertiPaqWarmupPlanner_Perf.Options
            {
                XmlaConnectionString = XmlaConn,
                ModelName = ModelName,

                RecentPartitionColumn = RecentPartitionColumn,
                RecentPartitionCount = 1,
                FactTables = new[] { "pbi_fact_risk_results_aggregated_vw" },

                WarmAllSecondaryKeys = true,
                SecondaryKeyColumn = SecondaryKeyColumn,
                SecondaryKeysBatchSize = 300,
                SecondaryKeysMaxBatches = int.MaxValue,

                UseSoftTimeTarget = true,
                SoftTimeTargetSeconds = 600,
                PilotBatchSize = 80,
                MinBatchSize = 50,
                MaxBatchSize = 800,
                BatchSizeSmoothing = 0.35,

                ResidentRatioThreshold = 0.25,
                MaxColumnsPerTable = 4,
                MaxColumnsTotal = 36,
                MaxTablesPerRun = 12,
                ColdScanTopK = 400,

                DimensionPrefixes = new[] { "Dim", "Lookup", "Ref" },
                VeryHighCardinalityThreshold = 1_000_000,
                ShouldSkipTable = t =>
                {
                    if (string.IsNullOrWhiteSpace(SkipTablesCsv)) return false;
                    foreach (var s in SkipTablesCsv.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
                        if (string.Equals(s, t, StringComparison.OrdinalIgnoreCase)) return true;
                    return false;
                },

                MaxParallel = 3,
                CommandTimeoutSeconds = 60,

                ExplicitAttributes = new List<(string, string)>()
            };

            var cts = new CancellationTokenSource();
            Console.CancelKeyPress += (_, e) => { e.Cancel = true; cts.Cancel(); };

            try
            {
                await planner.PlanAndExecuteWarmupAsync(opts, cts.Token);
                logger.LogInformation("Warm-up run finished.");
            }
            catch (OperationCanceledException)
            {
                logger.LogWarning("Warm-up canceled.");
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Warm-up failed.");
                Environment.ExitCode = -1;
            }
        }
    }
}
